# LIFE TIMELINE: Department of What If

The onboarding begins with profile creation, then the Life Stack. The five passport pages collect identity, resources, present life metrics, personality, and ranked values. Editable context can be expanded on the first page.

The visual direction draws from the spatial worlds, literary serif typography, tactile paper objects, and exploratory navigation on https://pearlinglim.com/, specifically Pearl’s Cove, The Builder, and The Thinker. No artwork or source code from that site was copied.

Original artwork was created with the built-in image-generation tool during development, once, without variants. Runtime does not use image generation or any LLM.

Asset: `public/art/department-of-what-if.png` (1536 × 1024).

Prompt: “Use case: illustration-story. Asset type: immersive illustrated web app background, landscape 1536x1024 or larger. A whimsical surreal analog observatory, a fantastical cabinet of possible lives: an intricate brass orbital astrolabe and tiny luminous portal doorways suspended among branching botanical stems, small moons and shimmering marbles. Literary storybook illustration mixed with engraved antique astronomy ephemera and sophisticated gouache; painterly paper grain, precisely rendered rich objects, restrained playful collage. Wide landscape; objects concentrated on the right half and outer edges. Left third quiet dark navy/teal open negative space for a heading. Center mostly uncluttered for an overlay card. More strange antique scientific cabinet than generic fantasy landscape. Luminous, tactile, quietly mysterious. Palette: deep midnight ocean blue #112e39, faded turquoise, warm parchment, burgundy #6e344a, muted antique gold, coral, tiny pink highlights. Illustration only. No text, lettering, numerals, words, logos, people, interface, cards, panels, buttons or watermark.”

Six rooms frame the simulation: The Origin Room, The Cabinet of Forks, The Time Machine, The Elsewhere Archive, The Looking Glass, and The Human Experiment. Direct text tabs remain available alongside the room map. Sound is opt-in and synthesized locally.
# Pocket self update

Rounded surfaces, clearer spacing, and a modular clay miniature workshop extend the original world. Miniature choices are decorative profile data, retained by saved universes, local backups, and timeline codes; they do not affect simulation outcomes. Existing profiles get a default miniature.

Original asset created using the built-in image-generation tool. Saved to `public/art/miniature-parts.png` (1254 × 1254, RGBA). Display crops follow transparent gutters and align the neck connection across all eight heads and eight bodies. No generated interface or text is used.

Final generation prompt:

Create one functional sprite atlas for a modular miniature-person builder, exactly FOUR columns by FOUR rows of 16 equal square cells in a SQUARE 1536x1536 PNG with genuinely transparent alpha background. No gridlines, text, numbers, labels, watermark, environment, props, or floor. Each separate piece centered within its own cell, with clear empty padding so no object crosses a cell boundary. Consistent same scale and soft studio light. Luxurious stop-motion clay collectible figurines, velvety matte ceramic, rounded cheeks, charming tiny dot eyes, sophisticated playful jewel colours. TOP TWO ROWS: eight separate human HEADS with short neck stubs ONLY (no torsos), each head occupies central 65 percent of its cell width and 65 percent height, all front facing. Row1 left to right: deep brown skin short black curls; medium tan skin short chestnut waves; light warm skin ginger bob; warm brown skin black twin buns. Row2: light warm skin long black hair ending at neck; deep brown skin silver cropped curls; tan bald head; light brown skin fluffy lavender hair. BOTTOM TWO ROWS: eight separate HEADLESS miniature BODIES from neck attachment to shoes, NO HEADS, each centered, fills central 65 percent cell width and 88 percent height, frontal stance, arms relaxed. Shoulder line just below top padding, hands small and neutral ivory ceramic. Row3 left to right: teal dungarees over cream shirt; burgundy oversized sweater cream trousers; golden raincoat blue trousers; cobalt artist smock pale trousers. Row4: plum jumpsuit; mint cardigan terracotta trousers; rose coat navy trousers; midnight star-patterned robe gold shoes. Body neck stubs and hands all neutral ivory ceramic. Heads and bodies are modular pieces that will overlap and join in code. Crisp isolated alpha edges, transparent background mandatory. This is a production sprite sheet, NOT a mockup or user interface.


## Expressive atelier update

The palette is black, white, navy, and burgundy. The original eight bodies now pair with sixteen distinct expression sprites. Original RGBA artwork is saved in public/art/expressive-faces.png (1254 × 1254). Built-in imagegen was used. The final prompt follows.

Use case: stylized-concept.
Asset type: LIFE TIMELINE miniature character sprite sheet for a web experience.
Create exactly ONE square PNG sprite sheet with a genuinely transparent alpha background, preferably 2048x2048 pixels. Exactly 16 miniature HUMAN HEADS arranged in a precise 4-column by 4-row grid of equal square cells. No drawn gridlines, no text, no bodies, no shoulders, no clothing, no props. Each head has only a short bare neck stub. Front view, same overall head height across the entire sheet. Place each head and neck completely within its cell's central 80 percent, with generous clear transparent margins; every neck connection point is horizontally centered in its cell. Nothing crosses cell edges. Transparent empty space between all heads and around outer perimeter. Do not paint black, white, grey or checkerboard as the background: use true transparent alpha.

Style/medium: sophisticated original stop-motion clay maquette character design, expressive handcrafted matte clay texture, subtle tactile fingerprints, high-quality miniature sculpture, family-friendly adults. Soft neutral studio illumination; rich natural skin tones, black/navy/burgundy/plum and specified red/silver hair. Faces must look like varied adult humans, not baby dolls. Keep anatomy, head silhouettes, nose shapes, eye styles, eyebrow shapes and mouths clearly DIFFERENT. Do not give everyone identical button eyes or round baby faces.

The first two rows show EIGHT different characters in calm/neutral expressions. Rows three and four repeat precisely the SAME EIGHT identities in precisely the same column order, changing ONLY expression, and preserving hair, age, skin tone, features and identity.

EXACT CELL LAYOUT:
Row 1 column 1: Character 1 neutral — long oval face, medium brown skin, short swept black hair, prominent long nose, thick straight brows.
Row 1 column 2: Character 2 neutral — round wide face, light freckled skin, bright red short curls, distinctive gap between front teeth.
Row 1 column 3: Character 3 neutral — square broad jaw, deep brown skin, shaved hair, strong brows, broad nose.
Row 1 column 4: Character 4 neutral — heart-shaped face, warm tan skin, black bob, large almond eyes, round black glasses.
Row 2 column 1: Character 5 neutral — narrow older face, light brown skin, silver hair and short grey beard, visible smile lines.
Row 2 column 2: Character 6 neutral — soft wide face, dark skin, two high textured hair puffs, button nose and full lips.
Row 2 column 3: Character 7 neutral — angular face, pale skin, long plum hair, small nose, sleepy half-lidded eyes.
Row 2 column 4: Character 8 neutral — oblong face, golden brown skin, bald, thick dark moustache and small ears.
Row 3 column 1: SAME Character 1 — exaggerated playful lopsided broad toothy grin.
Row 3 column 2: SAME Character 2 — exaggerated huge closed-eye laugh, showing gap teeth.
Row 3 column 3: SAME Character 3 — exaggerated amazed O-shaped mouth and raised brows.
Row 3 column 4: SAME Character 4 — exaggerated playful wink and sly smile.
Row 4 column 1: SAME Character 5 — exaggerated warm squinty laugh.
Row 4 column 2: SAME Character 6 — exaggerated raised eyebrow and cheeky tongue-out smile.
Row 4 column 3: SAME Character 7 — exaggerated delighted open-mouth grin.
Row 4 column 4: SAME Character 8 — exaggerated cheeky wink and asymmetric smile.

Composition: centered head in every cell, evenly spaced mathematically regular rows and columns; crown and neck endpoints at consistent heights within each cell, visible short neck bottoms aligned. Heads should fill approximately 70–80 percent of each cell height including hair and neck. Precisely 16 isolated heads, two matching expressions of each of 8 characters. No text, no title, no watermark, no frame, no background shadows or ground planes.


The puppet responds to pointer dragging, keyboard input, boops, dance, leap, and twirl. A five-spark collection game offers an untimed play loop. Motion respects reduced-motion preferences. Expression and proportions are saved with the profile.

The disclaimer is shown until acknowledged; the acknowledgement stays in browser local storage. Privacy and legal dialogs remain available in the footer. Privacy text describes the implemented local storage, exports, hosting, and optional assistant tools. Liability wording retains mandatory legal rights. Drafting references: https://www.gov.uk/guidance/writing-a-fair-contract-for-customers and https://www.ftc.gov/business-guidance/privacy-security/consumer-privacy. Hosting copy is now provider-neutral.


## Portable edition and soundtrack

The opening description uses the publisher’s exact revised sentence ending in “It is a tool for exploring ideas.” Hosting-specific references and integrations are removed. “Other Lives” is an original 16-bar, 96 BPM instrumental in D minor, rendered to a seamless 40-second 22050 Hz mono PCM wave. Its piano-like melody, arpeggios, warm chord pad, bass, and light shaker use synthesized waveforms with no external samples. Source: scripts/compose-soundtrack.py. Player: components/soundtrack.tsx. Asset: public/audio/other-lives.wav.
