import type { Metadata } from 'next';
import './globals.css';
import './experimental.css';
import './pocket-self.css';
import './atelier.css';
import './music.css';
export const metadata: Metadata = {title:'LIFE TIMELINE | Explore possible lives',description:'A replayable life simulation and decision laboratory. Explore the choices, tradeoffs, and unexpected connections that shape a life.'};
export default function RootLayout({children}:Readonly<{children:React.ReactNode}>){return <html lang="en" className="dark"><body>{children}</body></html>}
