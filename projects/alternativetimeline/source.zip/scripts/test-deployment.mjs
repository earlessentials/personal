import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';

const base=(process.env.NEXT_PUBLIC_BASE_PATH||'').replace(/\/$/,'');
const root=path.resolve('dist/client');
const app=path.join(root,base.slice(1));
const events={};
const deleted=[];
const cacheNamePrefix=`life-timeline-${base?base.slice(1).replaceAll('/','-'):'root'}-`;
const origin='https://pearlinglim.com';
const source=fs.readFileSync(path.join(app,'sw.js'),'utf8');
const context={URL,Response, self:{location:{origin},addEventListener:(name,fn)=>events[name]=fn,clients:{claim:async()=>{}},skipWaiting:async()=>{}},caches:{keys:async()=>[cacheNamePrefix+'old','another-app-cache','life-timeline-another-mount-old'],delete:async key=>deleted.push(key)}};
vm.runInNewContext(source,context);
const urls=JSON.parse(source.match(/const URLS=(\[[^;]*\]);/)[1]);
for(const url of urls){
 assert.ok(url.startsWith(base+'/'),`Resource escapes app directory: ${url}`);
 const file=path.join(root,url.endsWith('/')?url+'index.html':url);
 assert.ok(fs.statSync(file).isFile(),`Missing cache resource: ${url}`);
}
const html=fs.readFileSync(path.join(app,'index.html'),'utf8');
for(const [,url] of html.matchAll(/(?:src|href)="(\/[^"#]+)"/g)){
 assert.ok(url.startsWith(base+'/'),`HTML asset escapes app directory: ${url}`);
 assert.ok(fs.existsSync(path.join(root,url)),`Missing HTML asset: ${url}`);
}
const walk=d=>fs.readdirSync(d,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(path.join(d,e.name)):[path.join(d,e.name)]);
for(const file of walk(app).filter(f=>f.endsWith('.css'))){
 for(const [,url] of fs.readFileSync(file,'utf8').matchAll(/url\(["']?(\/[^)"']+)/g)){
  assert.ok(url.startsWith(base+'/'),`CSS asset escapes app directory: ${url}`);
  assert.ok(fs.existsSync(path.join(root,url)),`Missing CSS asset: ${url}`);
 }
}
let intercepted=false;
for(const url of [origin+'/',origin+'/fallowdiagnostic/',origin+'/alternativetimeline-other/',origin+'/unrelated.js','https://example.org'+base+'/']){
 events.fetch({request:{url,method:'GET',mode:'navigate'},respondWith:()=>intercepted=true});
}
assert.equal(intercepted,false,'Another page was intercepted');
let activation;
events.activate({waitUntil:p=>activation=p});
await activation;
assert.deepEqual(deleted,[cacheNamePrefix+'old']);
console.log(`${urls.length} scoped resources verified. Existing pages and other caches stay isolated.`);
