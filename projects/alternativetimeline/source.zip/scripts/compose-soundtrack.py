"""Render an original, seamless 40-second instrumental. No samples or services."""
import math, random, struct, wave
from pathlib import Path

RATE=22050
BEAT=60/96
BARS=16
SECONDS=BARS*4*BEAT
COUNT=round(SECONDS*RATE)
mix=[0.0]*COUNT
randomizer=random.Random(2026)

def note(midi,beat,length,gain=.12,kind='piano'):
    if midi is None:return
    frequency=440*2**((midi-69)/12)
    start=round(beat*BEAT*RATE)
    duration=length*BEAT
    tail=1.1 if kind=='piano' else .45
    for j in range(round((duration+tail)*RATE)):
        t=j/RATE
        attack=min(1,t/.008)
        release=math.exp(-max(0,t-duration)*5)
        phase=2*math.pi*frequency*t
        if kind=='bass':
            tone=math.sin(phase)+.15*math.sin(2*phase)
            envelope=attack*math.exp(-t*1.7)*release
        elif kind=='pad':
            tone=.7*math.sin(phase)+.15*math.sin(phase*1.002)+.1*math.sin(phase*2)
            envelope=min(1,t/.24)*min(1,max(0,(duration+.45-t)/.6))*.65
        else:
            tone=math.sin(phase)+.30*math.sin(2*phase)*math.exp(-t*3)+.12*math.sin(3*phase)*math.exp(-t*5)+.055*math.sin(4.01*phase)*math.exp(-t*9)
            envelope=attack*math.exp(-t*2.6)*release
        mix[(start+j)%COUNT]+=tone*envelope*gain

chords=[[50,57,60,64],[46,53,57,60],[41,53,57,60],[48,55,60,62],[43,53,58,62],[45,52,55,61],[50,57,60,64],[45,52,55,61]]
melody=[
 [(74,.5),(77,.5),(81,1),(79,.5),(77,.5),(76,1)],
 [(74,.75),(72,.25),(70,1),(74,1),(77,1)],
 [(72,.5),(69,.5),(72,1),(76,1),(77,1)],
 [(79,1.5),(76,.5),(74,1),(72,1)],
 [(74,1),(77,.5),(79,.5),(82,1),(81,1)],
 [(79,.5),(76,.5),(73,1),(76,.5),(79,.5),(81,1)],
 [(77,1),(76,.5),(74,.5),(72,1),(69,1)],
 [(73,1),(76,1),(69,1),(None,1)],
 [(81,.5),(84,.5),(86,1),(84,.5),(81,.5),(79,1)],
 [(77,.5),(74,.5),(77,1),(81,1),(79,1)],
 [(76,1),(72,.5),(69,.5),(72,1),(77,1)],
 [(79,.5),(81,.5),(79,1),(76,1),(72,1)],
 [(74,.5),(77,.5),(82,1),(81,1),(79,1)],
 [(76,.5),(73,.5),(76,1),(79,1),(81,1)],
 [(77,1),(74,1),(69,.5),(72,.5),(74,1)],
 [(76,1),(73,1),(69,1),(None,1)],
]
for bar in range(BARS):
    chord=chords[bar%8]
    for p in chord[1:]:note(p,bar*4,3.65,.023,'pad')
    note(chord[0]-12,bar*4,1.3,.13,'bass')
    note(chord[0]-5,bar*4+2,1,.075,'bass')
    for step,index in enumerate([1,2,3,2,1,3,2,3]):note(chord[index]+12,bar*4+step*.5,.34,.036)
    at=bar*4
    for pitch,duration in melody[bar]:
        note(pitch,at,duration*.85,.115 if bar<8 else .105)
        at+=duration
    for step in range(8):
        start=round((bar*4+step*.5)*BEAT*RATE)
        previous=0
        for j in range(round(.07*RATE)):
            noise=randomizer.uniform(-1,1)
            high=noise-previous;previous=noise
            mix[(start+j)%COUNT]+=high*math.exp(-j/RATE*65)*(.011 if step%2 else .007)

peak=max(abs(v) for v in mix)
gain=.76/peak
pcm=b''.join(struct.pack('<h',round(v*gain*32767)) for v in mix)
destination=Path(__file__).resolve().parents[1]/'public/audio/other-lives.wav'
destination.parent.mkdir(parents=True,exist_ok=True)
with wave.open(str(destination),'wb') as output:
    output.setnchannels(1);output.setsampwidth(2);output.setframerate(RATE);output.writeframes(pcm)
rms=math.sqrt(sum((v*gain)**2 for v in mix)/COUNT)
print(f'{destination.name}: {SECONDS:.1f}s, {RATE}Hz, peak .76, RMS {rms:.3f}, {destination.stat().st_size:,} bytes')
