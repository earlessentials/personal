import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
const basePath=(process.env.NEXT_PUBLIC_BASE_PATH||'').replace(/\/$/,'');
if(basePath && !/^\/[a-zA-Z0-9/_-]+$/.test(basePath))throw Error('Use a simple absolute path for NEXT_PUBLIC_BASE_PATH.');
const output='dist/client';
const walk=d=>fs.readdirSync(d,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(path.join(d,e.name)):[path.join(d,e.name)]);
const appDir=path.join(output,basePath.slice(1));
if(basePath){
 fs.mkdirSync(appDir,{recursive:true});
 // Vinext emits public files and the exported page beside its prefixed asset directory.
 for(const name of fs.readdirSync('public')){
  const from=path.join(output,name);
  if(fs.existsSync(from))fs.renameSync(from,path.join(appDir,name));
 }
 for(const name of ['index.html','index.rsc','404.html','404.rsc']){
  const from=path.join(output,name);
  if(fs.existsSync(from))fs.renameSync(from,path.join(appDir,name));
 }
 // Public artwork belongs inside this application, alongside its music and page.
 for(const file of walk(appDir).filter(f=>f.endsWith('.css'))){
  let css=fs.readFileSync(file,'utf8');
  css=css.replaceAll(`${basePath}/_next/static/art/`,`${basePath}/art/`);
  fs.writeFileSync(file,css);
 }
}
if(!fs.existsSync(path.join(appDir,'index.html')))throw Error('Static index.html was not emitted.');
const files=walk(appDir).filter(f=>!f.endsWith('.map')&&!f.endsWith('/sw.js')&&!f.endsWith('.br')&&!f.endsWith('.gz')&&!f.includes('/.openai/'));
const home=basePath+'/';
const urls=[home,...files.map(f=>home+path.relative(appDir,f).replaceAll(path.sep,'/'))];
const version=crypto.createHash('sha256');for(const file of files)version.update(fs.readFileSync(file));
const prefix='life-timeline-'+(basePath?basePath.slice(1).replaceAll('/','-'):'root')+'-';
const cache=prefix+version.digest('hex').slice(0,12);
const source=`const CACHE=${JSON.stringify(cache)};const PREFIX=${JSON.stringify(prefix)};const HOME=${JSON.stringify(home)};const URLS=${JSON.stringify(urls)};
self.addEventListener('install',event=>{event.waitUntil((async()=>{const cache=await caches.open(CACHE);await cache.addAll(URLS);await self.skipWaiting();})());});
self.addEventListener('activate',event=>{event.waitUntil((async()=>{for(const key of await caches.keys()){if(key.startsWith(PREFIX)&&key!==CACHE)await caches.delete(key)}await self.clients.claim();})());});
self.addEventListener('fetch',event=>{const url=new URL(event.request.url);if(event.request.method!=='GET'||url.origin!==self.location.origin||!URLS.includes(url.pathname))return;event.respondWith((async()=>{const cache=await caches.open(CACHE);if(event.request.mode==='navigate'){try{const response=await fetch(event.request);if(response.ok&&!response.redirected&&response.headers.get('content-type')?.includes('text/html'))await cache.put(HOME,response.clone());return response}catch{return await cache.match(HOME)||Response.error()}}return await cache.match(url.pathname)||fetch(event.request);})());});`;
fs.writeFileSync(path.join(appDir,'sw.js'),source);
console.log(`Offline cache includes ${urls.length} local resources in ${appDir}.`);
