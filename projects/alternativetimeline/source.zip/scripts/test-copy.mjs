import fs from 'node:fs';
import ts from 'typescript';
const pattern=/\b(?:not|no|never|nothing|without|cannot|can['’]t|don['’]t|doesn['’]t|won['’]t|isn['’]t|aren['’]t|wouldn['’]t|couldn['’]t|shouldn['’]t|didn['’]t|but|unlike|rather than|instead of)\b|—|;/i;
const errors=[];
function check(value,file,key=''){
 if(['id','homeOwnership'].includes(key)||value==='No'||value==='Yes')return;
 if(/^[a-z]+(?:-[a-z]+)+$/.test(value))return;
 if(pattern.test(value))errors.push({file,value});
}
function walk(value,file,key=''){
 if(Array.isArray(value))value.forEach(v=>walk(v,file,key));
 else if(value&&typeof value==='object')Object.entries(value).forEach(([k,v])=>walk(v,file,k));
 else if(typeof value==='string')check(value,file,key);
}
for(const name of fs.readdirSync('lib/content').filter(f=>f.endsWith('.json'))){const file='lib/content/'+name;walk(JSON.parse(fs.readFileSync(file,'utf8')),file)}
for(const file of ['app/page.tsx','app/layout.tsx',...fs.readdirSync('components').filter(f=>f.endsWith('.tsx')).map(f=>'components/'+f),'lib/engine.mjs','lib/model.mjs','lib/miniature.mjs','lib/reflection.mjs']){
 const source=ts.createSourceFile(file,fs.readFileSync(file,'utf8'),ts.ScriptTarget.Latest,true,file.endsWith('.tsx')?ts.ScriptKind.TSX:ts.ScriptKind.JS);
 function visit(node){
  if(ts.isStringLiteral(node)||ts.isNoSubstitutionTemplateLiteral(node)||ts.isJsxText(node)||ts.isTemplateHead(node)||ts.isTemplateMiddle(node)||ts.isTemplateTail(node))check(node.text.trim(),file);
  ts.forEachChild(node,visit);
 }
 visit(source);
}
if(errors.length){console.error(JSON.stringify(errors,null,2));process.exit(1)}
console.log('Authored UI and narrative copy passed the language and punctuation check.');
