"""Build-time expansion of authored content. Runtime reads only the emitted JSON."""
import json,pathlib,re,itertools,random
out=pathlib.Path('lib/content');out.mkdir(exist_ok=True)
def clean_copy(value,key=''):
 if isinstance(value,dict):return {k:clean_copy(v,k) for k,v in value.items()}
 if isinstance(value,list):return [clean_copy(v,key) for v in value]
 if isinstance(value,str) and key not in ('id','homeOwnership'):
  for a,b in copy_replacements.items():value=value.replace(a,b)
 return value
copy_replacements=json.loads(pathlib.Path('scripts/copy-replacements.json').read_text())
def write(name,data):(out/(name+'.json')).write_text(json.dumps(clean_copy(data),ensure_ascii=False,separators=(',',':')))
def slug(s):return re.sub(r'[^a-z0-9]+','-',s.lower()).strip('-')
groups={
'Career':'Quit job|Stay another year|Ask for promotion|Accept promotion|Reject promotion|Change company|Change industry|Change career|Become freelancer|Become consultant|Join startup|Join corporation|Reduce working hours|Become manager|Leave management|Move for work|Take overseas role|Accept lower salary for better lifestyle|Accept higher salary with heavier workload|Work remotely|Take second job|Continue working',
'Business':'Start business|Take over family business|Leave family business|Build side business|Become self employed|Open a local shop|Buy an existing business|Find a cofounder|Hire first employee|Close a business',
'Money':'Invest savings|Keep cash reserve|Increase lifestyle spending|Reduce lifestyle spending|Loan money to family|Give money to family|Combine finances|Keep finances separate|Start emergency fund|Spend savings on education|Spend savings on business|Negotiate household budget',
'Investing':'Build a diversified portfolio|Invest in a friend’s company|Buy bonds|Invest in a rental partnership|Increase pension contributions|Sell investments|Concentrate in one investment|Automate monthly investing',
'Housing':'Buy first home|Continue renting|Sell home|Buy larger home|Downsize|Buy investment property|Take mortgage|Pay mortgage early|Renovate a home|Share a home|Rent out a room|Build a home',
'Marriage':'Get married|Delay marriage|Plan a small wedding|Plan a large wedding|Renew commitment|Discuss a prenuptial agreement',
'Dating':'Start relationship|Stay single|Move in together|Live separately|Long distance relationship|Move for partner|Ask partner to move|Reconnect with ex|Choose between partners|Delay commitment',
'Breakups':'End relationship|Stay and repair relationship|Relationship break|Leave after betrayal|Attend relationship counseling|Have difficult conversation|Open relationship|Close relationship',
'Infidelity':'Have affair|End affair|Confess affair|Hide affair|Forgive betrayal|Rebuild trust after betrayal',
'Family':'Move near parents|Move away from parents|Support parents financially|Support sibling financially|Set stronger boundaries|Reconnect with family|Reduce family involvement|Take family business responsibility',
'Children':'Have first child|Have another child|Delay children|Remain childfree|Adopt|Become a foster parent|Change childcare arrangement|Take parental leave',
'Friendships':'Reconnect with an old friend|End a one-sided friendship|Make new friends|Plan a reunion|Live with friends|Support a friend in crisis',
'Education':'Bachelor’s degree|Master’s degree|PhD|Professional certification|Career retraining|Study abroad|Take gap year|Leave university|Change degree|Learn technical skill|Learn creative skill|Learn language|Self educate|Take apprenticeship|Return to school after 40|Return to school after 50',
'Relocation':'Move neighborhood|Move city|Move home|Move near family|Move away from family|Move somewhere cheaper|Move somewhere expensive|Move somewhere more exciting|Move to major city|Move to smaller city|Move to countryside|Become location independent',
'Migration':'Move country|Move abroad for work|Move abroad for partner|Move abroad alone|Return to home country|Seek permanent residency',
'Identity':'Explore a new identity|Come out to family|Change your name|Explore a faith community|Leave a faith community|Reconnect with cultural roots',
'Lifestyle':'Take sabbatical|Become digital nomad|Travel for a year|Simplify possessions|Adopt a pet|Build a fitness routine',
'Social life':'Join a community|Host regular gatherings|Volunteer locally|Join a sports club|Take a social media break|Make time for solitude',
'Public life':'Run for local office|Speak publicly about an issue|Build a public platform|Leave public life|Become a community organizer|Protect personal privacy',
'Retirement':'Retire early|Delay retirement|Work part time in retirement|Relocate for retirement|Create a retirement plan|Pursue an encore career',
'Caregiving':'Become caregiver|Care for aging parent|Arrange professional care|Share caregiving duties|Move in with a parent|Take caregiver leave',
'Personal development':'Begin therapy|Find a mentor|Develop a daily practice|Build better sleep habits|Learn to set boundaries|Commit to a creative practice',
'Major purchases':'Buy expensive car|Delay major purchase|Buy a practical vehicle|Purchase travel equipment|Buy tools for work|Finance a luxury purchase',
'Debt':'Pay debt aggressively|Refinance a loan|Consolidate debt|Borrow for education|Borrow for business|Ask for repayment support',
'Inheritance':'Accept an inheritance|Share inherited assets|Sell inherited property|Keep inherited property|Create a family estate plan|Decline a conditional gift',
'Entrepreneurship':'Launch a digital product|Seek external investment|Bootstrap a venture|Scale a small company|Pivot a business|Return to employment',
'Creative careers':'Become creator|Publish a book|Record an album|Pursue acting|Open an art studio|Teach a creative skill',
'Work life balance':'Prioritize career|Prioritize relationship|Take career break|Protect weekends|Request flexible hours|Stop working overtime',
'Moral dilemmas':'Report misconduct|Refuse unethical work|Return an accidental payment|Speak up for a colleague|Disclose a conflict of interest|Walk away from a lucrative deal',
'Social pressure':'Decline a costly celebration|Resist lifestyle comparison|Change social circles|Say no to a prestigious role|Share an unpopular choice|Stop seeking public approval',
'Family expectations':'Choose family expectation|Choose independent path|Negotiate family responsibilities|Choose a different profession|Decline an arranged introduction|Discuss intergenerational values',
'Risk taking':'Take a calculated career risk|Try a new city for a season|Enter a competition|Accept an uncertain opportunity|Test a small venture|Make a public commitment',
'Long term commitment':'Commit to a ten-year plan|Become a business partner|Sign a long lease|Commit to community leadership|Create a shared life plan|Renegotiate a long commitment',
'Starting over':'Start over at 40|Rebuild after job loss|Rebuild after separation|Restart after business closure|Return after a long break|Build a new support network'}
# Effects are in 0–100 metric points or multiples of monthly income/expenses.
category_rules={
'Career':(['careerTransition','highBandwidth'],{'career':10,'stress':8,'stability':-5},{'careerCapital':.35,'career':.10},.25,24,6),
'Business':(['businessLaunch','incomeRisk','capitalNeed','highBandwidth'],{'freedom':16,'meaning':12,'stress':18,'incomeRate':-.25},{'careerCapital':.4,'incomeGrowth':.004},3,40,4),
'Money':(['financialPlanning','liquiditySensitive'],{'financialSecurity':8,'freedom':-3,'stress':-4},{'financialSecurity':.12},.25,10,9),
'Investing':(['investment','liquidityHeavy','financialPlanning'],{'financialSecurity':4,'stress':3,'investRate':.25},{'financialSecurity':.12},.1,8,7),
'Housing':(['locationLock','liquidityHeavy','longCommitment','debtExposure'],{'stability':16,'freedom':-12,'stress':12,'assetMonths':24,'debtMonths':18,'expenseRate':.12},{'stability':.08},6,28,3),
'Marriage':(['relationshipImpact','longCommitment','highBandwidth'],{'love':17,'family':9,'freedom':-7,'stress':6},{'love':.10,'family':.07},2,20,4),
'Dating':(['relationshipImpact','socialGrowth'],{'love':13,'social':6,'freedom':-5,'adventure':5},{'love':.08},.25,16,7),
'Breakups':(['relationshipImpact','socialReset','autonomy'],{'love':-18,'freedom':17,'stress':15,'stability':-13},{'confidence':.15,'stress':-.08},.7,30,5),
'Infidelity':(['trustRisk','relationshipImpact','socialRisk'],{'love':-20,'stress':20,'stability':-12,'meaning':-8},{'love':-.08,'stress':.05},.2,25,2),
'Family':(['familySupport','relationshipImpact'],{'family':14,'freedom':-6,'meaning':8,'stress':3},{'family':.10},.6,20,6),
'Children':(['expenseIncrease','highBandwidth','longCommitment','relationshipImpact'],{'family':20,'meaning':16,'freedom':-20,'energy':-15,'stress':15,'expenseRate':.22},{'family':.14},2,45,1),
'Friendships':(['socialGrowth','relationshipImpact'],{'social':14,'meaning':5,'energy':4},{'socialCapital':.15},.15,10,9),
'Education':(['education','highBandwidth','capitalNeed'],{'skills':15,'meaning':10,'stress':10,'incomeRate':-.06},{'skills':.2,'careerCapital':.25,'incomeGrowth':.001},3,28,6),
'Relocation':(['relocation','socialReset','highBandwidth'],{'adventure':17,'social':-12,'family':-6,'stress':12,'freedom':8},{'social':.12,'confidence':.09},2,25,6),
'Migration':(['relocation','socialReset','highBandwidth','careerTransition'],{'adventure':23,'social':-20,'family':-12,'stress':19,'freedom':12},{'skills':.14,'social':.14},4,35,4),
'Identity':(['identity','autonomy','socialRisk'],{'freedom':14,'meaning':16,'stress':9,'confidence':10},{'meaning':.12},.3,20,7),
'Lifestyle':(['autonomy','novelty'],{'freedom':14,'adventure':12,'energy':7,'incomeRate':-.05},{'energy':.06},1,15,8),
'Social life':(['socialGrowth','community'],{'social':15,'meaning':8,'energy':3},{'socialCapital':.15},.2,12,9),
'Public life':(['socialGrowth','socialRisk','highBandwidth'],{'social':12,'meaning':12,'stress':13,'freedom':-5},{'socialCapital':.23},1,27,5),
'Retirement':(['incomeRisk','autonomy','longCommitment'],{'freedom':25,'energy':14,'career':-12,'incomeRate':-.6},{'meaning':.07},.5,15,3),
'Caregiving':(['familySupport','highBandwidth','expenseIncrease'],{'family':19,'meaning':12,'energy':-16,'stress':17,'incomeRate':-.1,'expenseRate':.08},{'family':.10},1,38,4),
'Personal development':(['recovery','education'],{'energy':10,'meaning':10,'stress':-10,'confidence':8},{'energy':.10,'confidence':.08},.3,12,9),
'Major purchases':(['liquidityHeavy','expenseIncrease'],{'adventure':8,'freedom':5,'financialSecurity':-10},{'financialSecurity':-.03},4,8,6),
'Debt':(['debtExposure','financialPlanning'],{'debtPayRate':.2,'financialSecurity':8,'freedom':-4},{'financialSecurity':.1},.4,10,7),
'Inheritance':(['assetTransfer','familySupport'],{'assetMonths':12,'family':5,'stress':5},{'financialSecurity':.1},.2,15,5),
'Entrepreneurship':(['businessLaunch','incomeRisk','capitalNeed','highBandwidth'],{'freedom':13,'meaning':12,'stress':15,'incomeRate':-.15},{'careerCapital':.35,'incomeGrowth':.003},2.5,35,5),
'Creative careers':(['autonomy','incomeRisk','education'],{'meaning':19,'freedom':13,'incomeRate':-.2,'stability':-10},{'skills':.25,'incomeGrowth':.002},1.5,27,7),
'Work life balance':(['recovery','autonomy'],{'freedom':13,'energy':12,'stress':-10,'incomeRate':-.08},{'energy':.08},.1,10,8),
'Moral dilemmas':(['socialRisk','meaningGain'],{'meaning':17,'confidence':10,'stress':13,'career':-6},{'meaning':.1},.1,19,6),
'Social pressure':(['autonomy','socialRisk'],{'freedom':12,'meaning':8,'social':-7,'stress':-4},{'confidence':.12},.1,12,8),
'Family expectations':(['familySupport','autonomy'],{'freedom':9,'family':-5,'meaning':10,'stress':9},{'confidence':.1},.1,17,7),
'Risk taking':(['novelty','incomeRisk'],{'adventure':18,'confidence':10,'stress':12,'stability':-8},{'careerCapital':.15},1,22,7),
'Long term commitment':(['longCommitment','locationLock'],{'stability':17,'meaning':10,'freedom':-14},{'stability':.12},2,25,3),
'Starting over':(['careerTransition','socialReset','recovery'],{'freedom':12,'stability':-14,'stress':15,'confidence':7},{'confidence':.18,'careerCapital':.15},1,30,7)}
# Individually authored overrides distinguish opposite choices and common decisions.
overrides={
'Quit job':(['incomeRisk','careerTransition','highBandwidth','liquiditySensitive'],{'incomeRate':-1,'freedom':24,'career':-6,'stress':16,'stability':-22},{'careerCapital':.08},.2,30,6),
'Stay another year':(['financialPlanning','stability'],{'stability':9,'career':-4,'freedom':-7,'incomeRate':.03},{'careerCapital':.15},0,4,9),
'Reject promotion':(['autonomy','recovery'],{'freedom':9,'energy':8,'career':-4,'stress':-5},{'energy':.06},0,3,8),
'Accept promotion':(['careerGrowth','highBandwidth'],{'incomeRate':.20,'career':13,'stress':11,'freedom':-8},{'careerCapital':.3},0,23,7),
'Ask for promotion':(['careerGrowth','socialRisk'],{'incomeRate':.08,'career':6,'confidence':8,'stress':4},{'careerCapital':.2},0,8,9),
'Become freelancer':(['incomeRisk','autonomy','careerTransition'],{'incomeRate':-.2,'freedom':22,'stress':12,'stability':-13},{'incomeGrowth':.003,'careerCapital':.25},.5,25,7),
'Accept lower salary for better lifestyle':(['autonomy','recovery'],{'incomeRate':-.18,'freedom':17,'energy':15,'stress':-12},{'energy':.1},.1,12,7),
'Accept higher salary with heavier workload':(['careerGrowth','highBandwidth'],{'incomeRate':.3,'career':10,'stress':20,'energy':-15,'freedom':-17},{'careerCapital':.2},.1,30,6),
'Continue renting':(['autonomy','liquiditySensitive'],{'freedom':8,'stability':-4},{'adventure':.02},0,3,10),
'Sell home':(['relocation','financialPlanning'],{'sellHome':1,'freedom':18,'stability':-10},{'adventure':.06},.2,23,5),
'Downsize':(['financialPlanning','recovery'],{'expenseRate':-.2,'savingsMonths':4,'stability':3,'freedom':10},{'financialSecurity':.12},1,20,6),
'Pay mortgage early':(['financialPlanning','liquiditySensitive'],{'debtPayRate':.7,'financialSecurity':15,'stress':-10},{'financialSecurity':.15},0,4,5),
'Keep cash reserve':(['financialPlanning','recovery'],{'financialSecurity':12,'stress':-6},{'financialSecurity':.1},0,2,10),
'Increase lifestyle spending':(['expenseIncrease','novelty'],{'expenseRate':.2,'adventure':10,'financialSecurity':-9},{'financialSecurity':-.1},.4,5,8),
'Reduce lifestyle spending':(['financialPlanning','recovery'],{'expenseRate':-.2,'financialSecurity':12,'adventure':-7},{'financialSecurity':.1},0,5,9),
'Start emergency fund':(['financialPlanning','recovery'],{'expenseRate':-.08,'financialSecurity':8,'stress':-5},{'financialSecurity':.15},0,4,10),
'Pay debt aggressively':(['financialPlanning','liquiditySensitive'],{'debtPayRate':.5,'expenseRate':-.1,'stress':-5},{'financialSecurity':.13},0,6,8),
'Borrow for education':(['education','debtExposure','capitalNeed'],{'debtMonths':8,'skills':18,'stress':12},{'careerCapital':.2},0,23,5),
'Borrow for business':(['businessLaunch','debtExposure','incomeRisk'],{'debtMonths':10,'assetMonths':6,'stress':16,'freedom':12},{'incomeGrowth':.002},0,34,4),
'Delay major purchase':(['financialPlanning','recovery'],{'financialSecurity':8,'adventure':-3},{'financialSecurity':.1},0,2,10),
'Stay single':(['autonomy','socialGrowth'],{'freedom':15,'love':-3,'social':7},{'socialCapital':.1},0,5,10),
'Delay marriage':(['autonomy','financialPlanning'],{'freedom':7,'love':-3,'stress':-4},{'financialSecurity':.08},0,5,9),
'Live separately':(['autonomy','relationshipImpact'],{'freedom':11,'love':3,'expenseRate':.06},{'love':.04},.3,8,9),
'Stay and repair relationship':(['relationshipImpact','recovery'],{'love':8,'stress':7,'meaning':8},{'love':.15,'stress':-.08},.25,20,7),
'Attend relationship counseling':(['relationshipImpact','recovery'],{'love':10,'stress':-7,'expenseRate':.03},{'love':.12},.2,12,9),
'End affair':(['relationshipImpact','recovery'],{'stress':-7,'love':-6,'meaning':12},{'love':.08,'stress':-.07},0,20,5),
'Confess affair':(['trustRisk','relationshipImpact'],{'love':-24,'stress':17,'meaning':7},{'stress':-.07,'love':.03},0,30,2),
'Hide affair':(['trustRisk','relationshipImpact'],{'love':-7,'stress':22,'meaning':-13},{'love':-.13,'stress':.09},0,20,2),
'Forgive betrayal':(['relationshipImpact','recovery'],{'love':5,'stress':12,'meaning':4},{'love':.10,'stress':-.06},.1,23,5),
'Delay children':(['autonomy','financialPlanning'],{'freedom':10,'family':-4,'stability':7},{'financialSecurity':.1},0,4,8),
'Remain childfree':(['autonomy','longCommitment'],{'freedom':20,'energy':8,'family':-6},{'freedom':.08},0,5,4),
'Set stronger boundaries':(['autonomy','recovery'],{'freedom':15,'family':-5,'stress':-7},{'energy':.1},0,12,9),
'Move near parents':(['relocation','familySupport'],{'family':18,'social':-4,'stress':6},{'family':.12},1.5,25,7),
'Move near family':(['relocation','familySupport'],{'family':18,'social':-4,'stress':6},{'family':.12},1.5,25,7),
'Move somewhere cheaper':(['relocation','financialPlanning'],{'expenseRate':-.25,'freedom':10,'social':-8,'stress':6},{'financialSecurity':.12},1.5,25,7),
'Move somewhere expensive':(['relocation','expenseIncrease'],{'expenseRate':.25,'adventure':19,'social':-7,'stress':14},{'careerCapital':.15},3,25,6),
'Leave university':(['autonomy','careerTransition'],{'freedom':14,'skills':-8,'stress':-6},{'careerCapital':.04},0,15,7),
'Leave family business':(['autonomy','incomeRisk','careerTransition'],{'freedom':20,'family':-13,'incomeRate':-.6,'stress':13},{'careerCapital':.16},.2,30,6),
'Take sabbatical':(['incomeRisk','autonomy','recovery'],{'incomeRate':-.75,'freedom':23,'energy':20,'stress':-14},{'meaning':.12},1,10,8),
'Work remotely':(['autonomy','recovery'],{'freedom':15,'energy':8,'social':-5,'expenseRate':-.07},{'energy':.06},.2,10,9),
'Protect weekends':(['recovery','familySupport'],{'freedom':12,'family':8,'stress':-11},{'energy':.12},0,3,10),
'Prioritize career':(['careerGrowth','highBandwidth'],{'incomeRate':.12,'career':14,'love':-9,'family':-6,'stress':10},{'careerCapital':.22},.2,23,7),
'Prioritize relationship':(['relationshipImpact','recovery'],{'love':16,'career':-5,'freedom':-3,'stress':-4},{'love':.1},.1,12,8),
'Continue working':(['careerGrowth','financialPlanning'],{'incomeRate':.04,'career':6,'freedom':-8},{'careerCapital':.15},0,5,9),
'Delay retirement':(['careerGrowth','financialPlanning'],{'financialSecurity':12,'freedom':-12,'energy':-5},{'careerCapital':.1},0,7,8),
'Decline a conditional gift':(['autonomy','familySupport'],{'freedom':13,'family':-6,'meaning':10},{'confidence':.08},0,6,9),
'Choose family expectation':(['familySupport','longCommitment'],{'family':15,'freedom':-13,'stress':7},{'family':.09},.5,18,5),
'Choose independent path':(['autonomy','socialRisk'],{'family':-9,'freedom':18,'meaning':13,'stress':9},{'confidence':.13},.5,19,7),
'Return to employment':(['careerGrowth','financialPlanning'],{'incomeRate':.4,'stability':18,'freedom':-15,'stress':-6},{'careerCapital':.2},.2,20,7)}
option_sets={
'careerTransition':[('Make the change now',1,0),('Build six months of runway',.85,6),('Test a smaller version first',.5,3),('Negotiate a gradual transition',.65,3)],
'businessLaunch':[('Launch with full commitment',1,0),('Start as a side business',.5,3),('Build a pilot with customers',.65,6),('Find a partner and share costs',.75,3)],
'relationshipImpact':[('Have the conversation and act',1,0),('Plan the change together',.8,3),('Try a temporary arrangement',.5,3),('Seek support before committing',.7,6)],
'education':[('Commit to full-time learning',1,0),('Study part time',.55,3),('Take a short course first',.35,0),('Save and apply next year',.85,12)],
'relocation':[('Move as soon as possible',1,0),('Visit and test the location',.55,3),('Secure work before moving',.8,6),('Try a temporary move',.65,3)],
'financialPlanning':[('Put the plan into action',1,0),('Make gradual monthly changes',.6,3),('Try a small first step',.35,0),('Build a buffer before acting',.8,6)],
'longCommitment':[('Commit now',1,0),('Prepare for six months',.8,6),('Try a smaller commitment',.5,3),('Agree on an exit plan first',.7,3)],
'default':[('Take the full step',1,0),('Prepare before acting',.8,6),('Try a reversible version',.45,3),('Ask for support and phase it in',.65,3)]}
scenarios=[]
for cat,titles in groups.items():
 for title in titles.split('|'):
  tags,immediate,long,cost,bw,rev=overrides.get(title,category_rules[cat]);tags=list(tags);immediate=dict(immediate);long=dict(long)
  # Variation follows scenario-specific descriptions while retaining explicit shared archetypes.
  opts=next((option_sets[t] for t in ['businessLaunch','education','relocation','careerTransition','relationshipImpact','financialPlanning','longCommitment'] if t in tags),option_sets['default'])
  if title=='Quit job':opts=[('Quit immediately',1,0),('Build six months additional savings',.85,6),('Start side income first',.65,3),('Negotiate reduced hours',.4,0),('Stay another year',0,12)]
  if cat=='Children' and title in ['Have first child','Have another child','Adopt']:
   opts=[('Begin the journey now',1,0),('Build savings and support first',.9,6),('Prepare together for next year',.85,12),('Wait and revisit the decision',0,24)]
  decisionOptions=[]
  for i,(text,strength,delay) in enumerate(opts):
   mod={'stress':-4 if i else 2,'confidence':2 if i==2 else 0}
   if title=='Quit job' and i==2:mod['incomeRate']=.35
   if title=='Quit job' and i==4:mod={'incomeRate':.03,'stability':7,'freedom':-5}
   decisionOptions.append({'id':str(i),'title':text,'strength':strength,'delayMonths':delay,'costMultiplier':[1,.65,.35,.6,0][i],'modifiers':mod,'tags':list(dict.fromkeys((['security','patience'] if i==1 else ['autonomy','learning'] if i==2 else ['family','security'] if i==3 else ['risk','ambition'])+[t for t in tags if t in ['autonomy','familySupport','financialPlanning','careerGrowth','community','meaningGain']]))})
  gains=[k for k,v in immediate.items() if v>0 and k not in ['stress','debtMonths'] and not k.endswith('Rate') and not k.endswith('Months')]
  costs=[k for k,v in immediate.items() if (v<0 and k not in ['stress']) or (v>0 and k=='stress')]
  desc={'Career':'Change your working life, earning power, and room to grow.','Business':'Build something of your own, with uncertainty along the way.','Housing':'Trade liquidity and flexibility for a different place to call home.','Marriage':'Make room for a shared future and the commitments it brings.','Children':'Explore how family, time, money, and identity grow together.','Relocation':'Change your surroundings and the connections that shape your days.','Migration':'Build a life across borders, with new possibilities and distance.','Infidelity':'Explore consequences for trust, honesty, and the people involved.'}.get(cat,f'Explore {title.lower()} and the resources this path asks of you.')
  req='partner' if title in ['Get married','End relationship','Relationship break','Stay and repair relationship','Open relationship','Close relationship','Confess affair','Hide affair','Have affair','Prioritize relationship'] else None
  scenarios.append({'id':slug(title),'category':cat,'title':title,'shortDescription':desc,'applicableProfileTags':[],'minimumAge':50 if 'after 50' in title else 40 if 'after 40' in title else 18,'maximumAge':100,'relationshipRequirement':req,'financialRequirement':{'savingsMonths':cost,'advisory':True},'decisionOptions':decisionOptions,'affectedVariables':list(set(immediate)|set(long)),'immediateEffects':immediate,'longTermEffects':long,'riskLevel':'High' if bw>=30 or rev<=3 else 'Moderate' if bw>=15 else 'Low','reversibility':{k:max(1,min(10,rev+d)) for k,d in [('financial',0),('career',1),('relationship',-1),('geographical',0),('time',-2)]},'bandwidthCost':bw,'financialCost':cost,'timeCost':round(bw*.3),'relationshipImpact':immediate.get('love',immediate.get('family',0)),'careerImpact':immediate.get('career',0),'possibleEvents':[],'interactionTags':tags,'insightTags':tags,'potentialGains':gains,'potentialCosts':costs,'recoveryPath':'Rebuild savings, restore your energy, and use support before adding another major change.'})
write('scenarios',scenarios)
# An authored tag collision matrix. Every pair has explicit additive effects and an explanation.
tag_effects={
'incomeRisk':('Income volatility',{'stress':5,'stability':-4},'Less predictable income makes the other commitment harder to fund.'),
'liquidityHeavy':('Liquidity pressure',{'stress':5,'financialSecurity':-4},'Upfront spending reduces the buffer available for the other change.'),
'highBandwidth':('Competing demands',{'bandwidth':-10,'energy':-4},'Both changes need attention at the same time.'),
'locationLock':('Geographical friction',{'freedom':-5,'stress':4},'A location commitment makes the other transition less flexible.'),
'careerTransition':('Career volatility',{'careerCapital':-3,'stress':4},'Changing work while adapting elsewhere stretches professional capacity.'),
'expenseIncrease':('Rising fixed costs',{'financialSecurity':-4,'stress':3},'New recurring costs shrink the room to recover.'),
'longCommitment':('Commitment overlap',{'freedom':-4,'stability':2},'Long commitments reinforce structure but reduce exit routes.'),
'socialReset':('Support gap',{'social':-5,'stress':4},'Familiar support is less available during the transition.'),
'familySupport':('Shared support',{'family':5,'stress':-3},'Family support can share some of the practical burden.'),
'education':('Learning transfer',{'skills':4,'careerCapital':3},'New skills give the second choice more ways to develop.'),
'autonomy':('Freedom dividend',{'freedom':4,'meaning':3},'More control makes it easier to align daily life with your priorities.'),
'recovery':('Recovery space',{'energy':5,'stress':-4},'Recovery time makes the demands of the other choice easier to absorb.'),
'debtExposure':('Debt pressure',{'financialSecurity':-4,'stress':5},'Repayment obligations keep drawing on resources during change.'),
'relationshipImpact':('Relationship load',{'love':-3,'stress':3},'The other change also draws on time and emotional availability.'),
'financialPlanning':('Buffer effect',{'financialSecurity':5,'stress':-3},'Preparation improves the resources available when uncertainty arrives.'),
'businessLaunch':('Execution pressure',{'stress':5,'bandwidth':-7},'A new venture competes for money and focused attention.'),
'community':('Community support',{'socialCapital':5,'meaning':3},'A wider community opens routes to practical help.'),
'socialRisk':('Social uncertainty',{'stress':4,'social':-3},'Visible change can unsettle existing expectations.'),
'capitalNeed':('Capital competition',{'financialSecurity':-5,'stress':4},'The same money is being asked to serve two commitments.'),
'novelty':('New horizons',{'adventure':4,'energy':-2},'Fresh experience creates possibilities while demanding adjustment.')}
interactions=[]
for i,(a,b) in enumerate(itertools.combinations(tag_effects,2)):
 na,ea,ta=tag_effects[a];nb,eb,tb=tag_effects[b];effects={k:ea.get(k,0)+eb.get(k,0) for k in set(ea)|set(eb)}
 interactions.append({'id':f'interaction-{i+1:03}','tags':[a,b],'distinctScenarios':True,'title':na+' × '+nb,'effects':effects,'narrative':ta+' '+tb,'overlapMonths':18,'orderedPenalty':1.18 if a in ['incomeRisk','liquidityHeavy','debtExposure'] else 1.06})
interactions.append({'id':'overload','tags':['highBandwidth']*3,'distinctScenarios':True,'title':'Overload risk','effects':{'stress':18,'bandwidth':-15,'energy':-10},'narrative':'Three demanding changes overlap. Their timing creates more pressure than any individual choice.','overlapMonths':12,'orderedPenalty':1.15})
interactions[0:0]=[
 {'id':'geographical-conflict','tags':['locationLock','relocation'],'distinctScenarios':True,'title':'Geographical conflict','effects':{'freedom':-12,'stress':10},'narrative':'A home or location commitment makes relocation harder to reverse. Timing changes how long you carry both obligations.','overlapMonths':36,'orderedPenalty':1.3},
 {'id':'career-volatility','tags':['careerTransition','careerTransition'],'distinctScenarios':True,'title':'Career volatility','effects':{'careerCapital':-7,'stress':10,'bandwidth':-8},'narrative':'Two professional transitions compete for the same network, confidence, and focused attention.','overlapMonths':18,'orderedPenalty':1.2},
 {'id':'financial-pressure','tags':['incomeRisk','liquidityHeavy'],'distinctScenarios':True,'title':'Financial pressure multiplier','effects':{'financialSecurity':-10,'stress':14,'bandwidth':-5},'narrative':'Less predictable income overlaps with a large cash commitment. A smaller buffer makes setbacks harder to absorb.','overlapMonths':24,'orderedPenalty':1.3}
]
write('interactions',interactions)
# 270 individually named event premises, with category-specific effects and decisions.
event_titles={
'Career':'Unexpected promotion|Layoff|New manager|Company restructuring|Recruiter contact|Former colleague opportunity|Major client arrives|Major client leaves|Industry slowdown|New skill becomes valuable|Leadership invitation|A project receives recognition|Team conflict|Mentor offers guidance|Contract renewed|Workload spikes|Flexible role opens|Training budget approved',
'Money':'Unexpected expense|Investment gain|Investment loss|Salary increase|Bonus arrives|Property expense|Family requests money|Debt pressure decreases|Cost of living rises|A refund arrives|Insurance excess due|Subscription costs creep up|Loan rate changes|A payment is delayed|A forgotten deposit returns|An old debt is repaid|A discount reduces costs|A repair exceeds its quote',
'Housing':'Lease renewal|A helpful neighbor|Urgent repair|A room becomes available|Landlord sells property|Mortgage payment review|Community garden opens|Building work begins|Home energy costs fall|A buyer makes an offer|A rental vacancy|Transport access improves|Maintenance overdue|Shared housing tension|A renovation pays off|A quieter home appears|Moving costs rise|A local service closes',
'Relationships':'Meet someone|Partner receives job offer|Partner changes career|Conflict increases|Relationship strengthens|Former partner reconnects|Friend introduces someone|Partner wants relocation|Partner wants commitment|A difficult conversation lands well|A shared tradition begins|Time together becomes scarce|A boundary is respected|Plans no longer align|A gesture restores connection|Household tasks cause tension|A shared goal emerges|Trust needs attention',
'Family':'Parent retires|Sibling needs support|Family business opportunity|Parent needs more assistance|Family moves|Inheritance event|Family conflict|Family reconciliation|A family celebration|Childcare help appears|A responsibility is shared|Family expectations intensify|An older relative shares advice|School routine changes|A family project grows|Distance complicates a visit|An important anniversary|An unexpected family expense',
'Friendships':'New friendship|Friend moves away|Join community|Lose touch with friend|Professional connection emerges|Invitation creates opportunity|A friend asks for help|An old friend returns|A regular gathering begins|A friendship becomes strained|A shared interest connects people|A friend celebrates a milestone|A misunderstanding clears|A group falls apart|A friend offers practical support|A weekend invitation arrives|A connection becomes a collaborator|A friend introduces a mentor',
'Opportunity':'Conference invitation|Local collaboration|A small grant opens|A mentor takes interest|A scholarship appears|An overseas opening|A chance to teach|A community role opens|A creative commission|A promising introduction|A partnership proposal|A subsidized workspace opens|An apprenticeship vacancy|A speaking invitation|A flexible contract|An unexpected referral|A trial project|A skill exchange',
'Education':'Course admission|Exam setback|Study group forms|Tuition increases|A skill clicks|A certificate is earned|A teacher offers feedback|A course changes direction|A practical project succeeds|Study fatigue|Learning materials become available|A research invitation|A language milestone|An internship opens|A qualification gains value|A deadline slips|A portfolio gets noticed|Peer support grows',
'Lifestyle':'Sleep improves|Routine becomes stale|A restorative break|A crowded schedule|A new hobby sticks|A habit fades|A quieter morning|Commute grows longer|Time outdoors helps|A pet needs extra care|A daily practice settles|Screen time crowds out rest|A new route saves time|A club offers a trial|An enjoyable ritual returns|Travel plans change|A simpler routine works|Energy runs low',
'Economic conditions':'Hiring slows|Local wages improve|Costs rise faster|Borrowing gets costlier|A local industry expands|Tourism demand falls|Demand for your skills rises|Rent pressure increases|Public transport improves|A large employer closes|A new business district opens|Household budgets tighten|Supplier prices fall|Contract work grows|A regional opportunity emerges|A market correction|Savings yields improve|Consumer confidence weakens',
'Social life':'Community invitation|A group project begins|An awkward introduction|A neighborhood gathering|A volunteer role opens|A local club closes|A shared meal reconnects people|A social commitment expands|A discussion changes perspective|An invitation is declined|An online connection becomes local|A celebration brings people together|Social fatigue|A cause draws people together|A new group welcomes you|A regular meetup pauses|A public contribution is noticed|A supportive circle forms',
'Business':'First repeat customer|Supplier delay|Client referral|Cash flow squeeze|A product finds its audience|A collaborator leaves|A useful partnership|A price increase works|A project exceeds budget|A returning client|A failed experiment|A steady contract|A competitor opens|An operational improvement|A team member grows|An invoice goes unpaid|Demand spikes|An idea becomes a prototype',
'Unexpected expenses':'Device replacement|Car repair|Home appliance breaks|Urgent travel|A bill needs correction|Insurance payment rises|A lost deposit|Professional fee due|Family support request|A canceled booking costs money|A service needs replacing|A move costs more|A course needs extra materials|A pet care bill|A delayed fee arrives|A tax estimate was low|Storage costs add up|A shared cost becomes yours',
'Unexpected income':'A small bonus|A gift without conditions|A refunded payment|A short contract|A sold possession|A referral payment|A side project pays|A grant is awarded|An overpayment is returned|An old client returns|A royalty arrives|A prize is awarded|A bill credit arrives|A deposit is returned|A teaching opportunity pays|A temporary role pays|A rebate arrives|A small inheritance arrives',
'Personal milestones':'A decade begins|A promise is kept|A goal changes|A project is completed|A meaningful anniversary|A boundary holds|A difficult year ends|A new chapter settles|A long effort is recognized|A fear becomes manageable|A skill becomes second nature|A community feels like home|A loss changes priorities|A small routine compounds|A personal record is set|An old ambition returns|A relationship deepens|A different definition of enough'}
negative_words=['layoff','loss','expense','conflict','scarce','tension','strain','slow','costlier','closes','squeeze','leaves','unpaid','fatigue','slips','rises','rise','overdue','lost','repair','breaks','urgent','fails','failed','setback','misalign','tighten','costs','declined','falls','fades','crowded','longer','low','delayed','delays','weakens','pressure','cease','correction','unpaid','needs attention','runs low']
event_metrics={'Career':'career','Money':'financialSecurity','Housing':'stability','Relationships':'love','Family':'family','Friendships':'social','Opportunity':'careerCapital','Education':'skills','Lifestyle':'energy','Economic conditions':'financialSecurity','Social life':'social','Business':'careerCapital','Unexpected expenses':'financialSecurity','Unexpected income':'financialSecurity','Personal milestones':'meaning'}
response_copy=json.loads(pathlib.Path('scripts/event-response-copy.json').read_text())
events=[]
for cat,titles in event_titles.items():
 for i,title in enumerate(titles.split('|')):
  negative=cat=='Unexpected expenses' or any(w in title.lower() for w in negative_words);sign=-1 if negative else 1;metric=event_metrics[cat]
  effects={metric:sign*(5+i%5),'stress':-sign*(3+i%4)}
  if cat in ['Money','Business','Unexpected expenses','Unexpected income','Economic conditions']:effects['savingsMonths']=sign*(.2+(i%5)*.15)
  if title=='Layoff':effects={'incomeRate':-.65,'career':-12,'stress':18,'stability':-15}
  if title in ['Salary increase','Unexpected promotion']:effects['incomeRate']=.12
  if title=='Partner receives job offer':effects.update(love=3,freedom=-4)
  req=['businessLaunch'] if cat=='Business' else []
  eligibility={'minAge':18,'maxAge':110,'partner':True if 'Partner ' in title or 'Relationship strengthens'==title else False,'employed':cat=='Career','homeOwner':title in ['Mortgage payment review','A buyer makes an offer'],'hasChildren':title in ['School routine changes','Childcare help appears']}
  options=[{'id':'engage','title':'Give this your attention','effects':{metric:3,'bandwidth':-6,'stress':2},'tags':['ambition','learning']},{'id':'support','title':'Work through it with support','effects':{metric:2,'social':3,'stress':-2,'savingsMonths':-.05},'tags':['family','community']},{'id':'protect','title':'Protect your time and resources','effects':{'energy':3,'stress':-3,metric:-2},'tags':['security','autonomy']}]
  response_titles=response_copy['events'].get(title,response_copy['categories'][cat]['negative' if negative else 'positive'])
  for option,response_title in zip(options,response_titles):option['title']=response_title
  if title in ['Recruiter contact','Former colleague opportunity','Flexible role opens','Job opportunity','A flexible contract','A temporary role pays']:
   options[0]['effects']['incomeFloorRate']=.75
   options[1]['effects']['incomeFloorRate']=.55
  events.append({'id':slug(cat+'-'+title),'category':cat,'title':title,'eligibilityConditions':eligibility,'probabilityWeight':1+(i%4)*.3,'ageRange':[18,110],'requiredTags':req,'excludedTags':[],'metricEffects':effects,'followUpEvents':[],'possibleDecisions':options,'narrativeTemplate':'{{firstName}}, '+title[0].lower()+title[1:]+'. '+({'Career':'Your working life asks for a response.','Money':'The change reaches your household budget.','Housing':'The place you call home asks for attention.','Relationships':'Your connection with another person enters a new chapter.','Family':'Your family rhythm shifts, changing how you share time and support.','Friendships':'The connections around you change shape.','Opportunity':'A possible new path appears beside the one you are already walking.','Education':'Your investment in learning reaches another turning point.','Lifestyle':'An ordinary week feels different.','Economic conditions':'The wider environment changes the resources available to you.','Social life':'Your place in the community begins to shift.','Business':'The venture meets another real-world test.','Unexpected expenses':'An unplanned cost uses part of your buffer.','Unexpected income':'An unplanned inflow creates a little room to breathe.','Personal milestones':'Something that once felt distant has arrived.'}[cat]),'negative':negative})
chains=[]
# 100 curated combinations drawn from ten causal pathways, each with ten distinct premises.
pathways=[(['education','careerTransition'],['Education','Opportunity','Career','Friendships']),(['socialGrowth','community'],['Social life','Friendships','Opportunity','Career']),(['businessLaunch'],['Business','Opportunity','Money','Personal milestones']),(['relocation'],['Housing','Social life','Friendships','Opportunity']),(['familySupport'],['Family','Relationships','Lifestyle','Personal milestones']),(['autonomy'],['Lifestyle','Education','Opportunity','Career']),(['financialPlanning'],['Money','Housing','Lifestyle','Personal milestones']),(['relationshipImpact'],['Relationships','Family','Housing','Personal milestones']),(['incomeRisk'],['Career','Education','Opportunity','Business']),(['recovery'],['Lifestyle','Social life','Friendships','Personal milestones'])]
for p,(tags,cats) in enumerate(pathways):
 for v in range(10):
  ids=[]
  for stage,cat in enumerate(cats):
   eligible=[e for e in events if e['category']==cat and not e['negative'] and not any(e['eligibilityConditions'][x] for x in ['partner','employed','homeOwner','hasChildren']) and not e['requiredTags']]
   if not eligible:eligible=[e for e in events if e['category']==cat and not e['negative']]
   ids.append(eligible[(v+stage*3)%len(eligible)]['id'])
  chains.append({'id':f'chain-{p*10+v+1:03}','title':cats[0]+' opens another door','triggerTags':tags,'eventIds':ids,'delayMonths':[3+v%3,6+v%4,12+v%6,18+v%9],'probability':.5+(v%4)*.1})
for c in chains:
 for a,b in zip(c['eventIds'],c['eventIds'][1:]):
  e=next(e for e in events if e['id']==a)
  if b not in e['followUpEvents']:e['followUpEvents'].append(b)
for s in scenarios:s['possibleEvents']=[e['id'] for e in events if (e['category']==s['category'] or (e['requiredTags'] and any(t in s['interactionTags'] for t in e['requiredTags'])))][:12]
write('scenarios',scenarios);write('events',events);write('eventChains',chains)
# Modular, authored sentence fragments expanded at build time into complete fixed templates.
leads={
'immediate':['The choice to {{decision}} starts changing your days.','{{firstName}}, a new chapter starts with {{decision}}.','Your decision is now part of your daily life.','The first effect of {{decision}} is becoming visible.','A plan has become a commitment.','Your next chapter begins with an exchange of resources.','Something shifts as {{decision}} becomes real.','You have stepped into one possible future.','The choice has moved from possibility to reality.','Your usual rhythm makes room for a new direction.','This decision creates a new set of demands.','You begin to see what {{decision}} asks of you.','Your life adjusts around a fresh commitment.','A new path starts taking shape.','The first part of the tradeoff arrives.'],
'delayed':['{{months}} months later, {{decision}} is still unfolding.','An earlier choice has become part of your routine.','What began as {{decision}} keeps shaping the available paths.','The quieter consequences are becoming easier to see.','Time brings another dimension to {{decision}}.','A decision from {{years}} years ago returns to the foreground.','The initial transition has become a recurring commitment.','Some of the effects only become visible with time.','Your earlier choice now has a longer history.','The rhythm of this life has settled around {{decision}}.','A change that once felt new has become familiar.','The effects of preparation continue into this chapter.','Time reveals another side of the same choice.','An old decision shapes a new possibility.','The cost and benefit keep arriving on different schedules.'],
'financial':['Your financial runway is now {{newRunway}} months.','You started with {{oldRunway}} months of runway.','Your monthly income is {{income}}.','Your liquid savings stand at {{savings}}.','Your recurring expenses are {{expenses}}.','The balance sheet reflects the choices so far.','Your debt now stands at {{debt}}.','Your financial position has entered another chapter.','Money continues to shape the room you have to change course.','The financial side of {{decision}} is becoming clearer.'],
'relationship':['Your relationship connection is {{love}} out of 100.','Daily commitments continue to shape your connection.','The way time is shared has become part of the tradeoff.','A relationship has to adapt alongside the rest of life.','{{decision}} has consequences for more than one person.','The emotional side of this choice keeps unfolding.','Shared plans face a different set of constraints.','Your connection has its own pace of change.','You see another effect on the life you share.','{{firstName}}, your commitments are becoming more interdependent.'],
'career':['Your career capital is {{careerCapital}}.','Your working life carries the history of {{decision}}.','Professional options depend on the skills you keep building.','A career change has become part of a longer story.','Your skill score is now {{skills}}.','The value of professional experience becomes clearer with time.','Your career satisfaction is {{career}}.','Work continues to shape the rest of your week.','Your network and skills form part of your safety net.','{{decision}} changes what the next professional move could be.'],
'family':['Your family connection is {{family}}.','The family rhythm keeps adjusting.','Responsibility and connection draw on the same limited time.','Your family resources are part of this timeline.','The people close to you also live with this choice.','{{decision}} reaches into the family calendar.','Care and practical support are part of the equation.','Family time has a different shape in this life.','A shared responsibility changes the available space.','Your family ties have their own trajectory.'],
'social':['Your social connection is {{social}}.','Friendships develop around the time you make available.','Your social capital now stands at {{socialCapital}}.','The people around you shape which doors become visible.','A social network is one of this life’s resources.','Your circle keeps adapting to {{decision}}.','Ordinary contact adds up over time.','Your community has become part of the timeline.','Connections outside work and family still matter here.','{{firstName}}, your support network has changed with you.'],
'emotional':['Your stress is {{stress}} out of 100.','Your energy is {{energy}}.','This path feels different from the inside.','Your confidence is {{confidence}}.','The emotional cost has its own timetable.','How this life feels depends partly on what you value.','Your sense of meaning stands at {{meaning}}.','The inner experience is another part of the outcome.','Your life satisfaction is {{satisfaction}}.','There is more to this chapter than its financial result.'],
'opportunity':['Your optionality is {{optionality}}.','The next available door depends on the resources you carry.','A possible new direction grows from {{decision}}.','Your existing commitments shape which opportunities are usable.','Preparation changes what an invitation can become.','Your resources determine how much room there is to experiment.','A new option arrives inside an already moving life.','There is more than one way to respond to this opening.','{{firstName}}, your next choice begins from here.','The shape of the next possibility is becoming visible.'],
'hiddenCost':['A less visible cost of {{decision}} has arrived.','The resources used here cannot be used elsewhere at the same time.','A commitment occupies more than the money spent on it.','The opportunity cost becomes clearer with time.','Attention is also part of the price.','The hidden demand is easier to see from inside this life.','A new constraint sits beside the original benefit.','This choice has a recurring cost as well as an initial one.','The tradeoff reaches beyond the first decision.','Your bandwidth is now {{bandwidth}}.'],
'unexpectedUpside':['An unexpected benefit enters the story.','One useful consequence was not the original goal.','A small advantage has room to compound.','The same choice has created another opening.','Your earlier preparation reaches beyond its first purpose.','An ordinary decision has gained another layer of value.','A connection between choices becomes useful.','The upside extends beyond the immediate result.','Resources built in one area can help in another.','A modest beginning has become a useful foundation.'],
'reflection':['{{firstName}}, pause at this point in the timeline.','You are now {{age}}.','This is one plausible life among many.','Look at what this chapter has asked you to protect.','Your life contains gains and costs at the same time.','A change in priorities would make this result feel different.','The question is what you would choose from here.','This future reflects both preparation and chance.','Consider which tradeoff you would willingly make again.','The life you imagined has become a set of ordinary days.'],
'futureSelf':['At {{age}}, you look back on {{decision}}.','{{firstName}}, this possible future has its own rhythm.','The person in this timeline carries your earlier priorities.','You have lived {{years}} years beyond the starting point.','Your future self has become familiar with this tradeoff.','Your day-to-day life reflects choices that once felt abstract.','Your sense of enough has been tested in this timeline.','This is one version of who you might become.','The next chapter begins with the resources built here.','You recognize parts of the person who made the original choice.'],
'butterfly':['This event traces back to {{decision}}.','A choice from {{years}} years ago reaches this moment.','An earlier action opened a path to this event.','This is a third-order consequence of {{decision}}.','A small beginning has traveled through several later events.','Your timeline reveals a causal connection across time.','The origin of this moment lies further back than it first appears.','One decision created conditions for another, then another.','The first choice still echoes through this life.','{{firstName}}, the past has opened a door in the present.']}
tails=['Your current freedom is {{freedom}}.','Stability stands at {{stability}}.','You have {{bandwidth}} points of bandwidth available.','Your recovery capacity is {{recovery}}.','Meaning stands at {{meaning}}.','Your current energy is {{energy}}.','The fit with your values is {{fit}} out of 100.','Your financial runway is {{newRunway}} months.','Stress stands at {{stress}}.','Your optionality is {{optionality}} out of 100.']
templates={k:[a+' '+b for a,b in itertools.product(v,tails)] for k,v in leads.items()};write('templates',templates)
# 324 distinct conditional insights: state thresholds paired with value priority / resource state.
metrics=['career','love','financialSecurity','freedom','family','social','meaning','energy','stability','adventure','satisfaction','optionality','bandwidth','careerCapital','skills','socialCapital','confidence','recovery']
insights=[]
for a,b in itertools.product(metrics,metrics):
 if a==b:conditions=[{'key':a,'op':'lt','value':35}];txt='Your {{metricA}} is under pressure. A smaller next step may leave more room to recover.'
 else:conditions=[{'key':a,'op':'gte','value':68},{'key':b,'op':'lt','value':45}];txt='Your {{metricA}} has grown while {{metricB}} remains constrained. This timeline asks whether that exchange fits the life you want.'
 insights.append({'id':f'insight-{len(insights)+1:03}','conditions':conditions,'metricA':a,'metricB':b,'template':txt,'priority':3 if a==b else 1})
insights.extend([{'id':'low-runway','conditions':[{'key':'runway','op':'lt','value':6}],'requiredTags':['incomeRisk'],'template':'Your current financial runway makes income volatility one of the strongest variables in this simulation.','priority':10},{'id':'overload-insight','conditions':[{'key':'bandwidth','op':'lt','value':25}],'template':'The individual choices may each be manageable. Their timing creates the larger pressure.','priority':10}]);write('insights',insights)
future=[]
for a,b in itertools.permutations(metrics[:16],2):future.append({'id':f'future-{a}-{b}','conditions':[{'key':a,'op':'gte','value':65},{'key':b,'op':'lt','value':50}],'template':'You built a life with considerable {{metricA}}. Maintaining {{metricB}} became one of its recurring challenges.','metricA':a,'metricB':b})
write('futureSelfTemplates',future)
rng=random.Random(73109);profiles=[]
for i in range(100):
 age=[23,37,44,55,29][i%5]+(i//5)%8;inc=[2400,6800,4300,7900,3100][i%5];exp=[1700,3400,3800,4500,2600][i%5];savings=[6000,90000,17000,210000,2400][i%5];debt=[0,18000,65000,24000,32000][i%5]
 profiles.append({'id':f'profile-{i+1:03}','firstName':'Explorer '+str(i+1),'age':age,'gender':'Prefer to skip','country':['Indonesia','Canada','United Kingdom','Australia','Singapore','India','Germany','Japan','Brazil','United States'][i%10],'cityType':['Large city','Small city','Countryside','Suburb'][i%4],'relationshipStatus':['Single','Married','Partnered','Divorced','Single'][i%5],'children':[0,1,2,0,0][i%5],'dependents':[0,0,1,1,0][i%5],'education':['Bachelor’s degree','Master’s degree','Professional certification','Secondary school'][i%4],'employment':['Employed','Self-employed','Employed','Employed','Freelance'][i%5],'careerCategory':['Technology','Education','Creative','Business','Healthcare'][i%5],'income':inc,'expenses':exp,'savings':savings,'debt':debt,'assets':300000 if i%5==3 else 0,'housing':'Owned with mortgage' if i%5==3 else 'Renting','homeOwnership':'Yes' if i%5==3 else 'No','experience':max(0,age-22),'currency':'USD','metrics':{k:rng.randint(25,85) for k in ['career','love','financialSecurity','freedom','family','social','meaning','energy','stress','stability','adventure','satisfaction']},'personality':{k:rng.randint(15,95) for k in ['risk','ambition','security','novelty','patience','impulsivity','socialOrientation','familyOrientation','conflict','adaptability','caution','autonomy','future']},'values':{k:round(rng.uniform(.2,1),2) for k in ['Love','Family','Money','Freedom','Peace','Achievement','Status','Creativity','Adventure','Security','Community','Health','Meaning','Learning','Legacy','Independence']},'description':['A young professional with family support','A mid-career saver with a strong buffer','A parent balancing three dependents','An experienced worker with substantial assets','A freelancer carrying debt'][i%5]})
write('profiles',profiles)
write('achievements',[{'id':i,'title':t,'description':d} for i,t,d in [('rewind','Time traveler','Rewind a decision.'),('multiverse','Multiverse','Keep five timelines.'),('butterfly','Butterfly effect','Reveal a third-order consequence.'),('longgame','The long game','Simulate thirty years.'),('third','Third door','Choose an alternative path.'),('recovery','Recovery','Recover from a major setback.'),('stack','Life stack','Simulate five changes.'),('dna','Know yourself','Record at least ten decisions.'),('years','One more year','Live through ten consecutive years.')]])
write('challenges',[{'id':'start-over','title':'Start over at 40','description':'A career collapses. Two dependents. Six months of savings. Rebuild your room to choose.','profileIndex':2,'overrides':{'age':40,'employment':'Unemployed','income':0,'expenses':3000,'savings':18000,'children':1,'dependents':1},'stack':['change-career','learn-technical-skill','start-emergency-fund'],'goal':'Reach 65 optionality in ten years.','metric':'optionality','target':65,'months':120},{'id':'golden','title':'The golden handcuffs','description':'A high salary, a large mortgage, and very little joy at work. Find freedom without losing your buffer.','profileIndex':3,'overrides':{'income':12000,'expenses':8000,'savings':48000,'debt':250000,'assets':400000,'homeOwnership':'Yes','metrics':{'career':20,'freedom':25}},'stack':['reduce-working-hours','pay-mortgage-early'],'goal':'Reach 65 freedom while keeping six months of runway.','metric':'freedom','target':65,'minRunway':6,'months':120},{'id':'love','title':'Love or location','description':'A strong relationship. A dream opportunity overseas. Make room for both over five years.','profileIndex':1,'overrides':{'relationshipStatus':'Partnered','metrics':{'love':85}},'stack':['move-abroad-for-work','prioritize-relationship'],'goal':'Keep relationship connection above 65 after five years.','metric':'love','target':65,'months':60},{'id':'five','title':'Five things at once','description':'Marriage, a home, a new career, a child, and a move. Timing becomes your most valuable resource.','profileIndex':1,'overrides':{'relationshipStatus':'Partnered'},'stack':['get-married','buy-first-home','change-career','have-first-child','move-city'],'goal':'Reach 60 bandwidth after five years.','metric':'bandwidth','target':60,'months':60},{'id':'zero','title':'From zero','description':'Low savings, moderate debt, strong skills, and high ambition. Create breathing room.','profileIndex':4,'overrides':{'savings':500,'debt':15000,'metrics':{'career':70},'personality':{'ambition':95}},'stack':['build-side-business','pay-debt-aggressively','start-emergency-fund'],'goal':'Reach 65 financial security after ten years.','metric':'financialSecurity','target':65,'months':120}])
print(json.dumps({'scenarios':len(scenarios),'events':len(events),'interactions':len(interactions),'eventChains':len(chains),'templates':{k:len(v) for k,v in templates.items()},'insights':len(insights),'futureSelfTemplates':len(future),'profiles':len(profiles)},indent=2))
