'use client';
import {publicPath} from '@/lib/paths';
import {useCallback,useEffect,useRef,useState} from 'react';
import {Music2,Pause,Play,Volume1} from 'lucide-react';
import {Slider} from '@/components/ui/slider';

const MUSIC_KEY='life-timeline.music.v1';
export function useSoundtrack(){
 const audioRef=useRef<HTMLAudioElement|null>(null),wantedRef=useRef(true),volumeRef=useRef(.24);
 const [playing,setPlaying]=useState(false),[volume,setVolumeState]=useState(.24),[error,setError]=useState('');
 const start=useCallback(()=>{const audio=audioRef.current;if(!audio||!wantedRef.current||document.hidden)return;void audio.play().catch(e=>{setPlaying(false);if(e?.name!=='NotAllowedError'&&e?.name!=='AbortError')setError('Music needs another try. Tap play to retry.');});},[]);
 const save=()=>{try{localStorage.setItem(MUSIC_KEY,JSON.stringify({enabled:wantedRef.current,volume:volumeRef.current}))}catch{}};
 useEffect(()=>{
  try{const stored=JSON.parse(localStorage.getItem(MUSIC_KEY)||'null');if(stored&&typeof stored.enabled==='boolean')wantedRef.current=stored.enabled;if(Number.isFinite(stored?.volume))volumeRef.current=Math.max(0,Math.min(.7,stored.volume))}catch{}
  setVolumeState(volumeRef.current);const audio=new Audio(publicPath('/audio/other-lives.wav'));audio.loop=true;audio.preload='auto';audio.volume=volumeRef.current;audioRef.current=audio;
  const onPlaying=()=>{setPlaying(true);setError('')},onPause=()=>setPlaying(false),onError=()=>{setPlaying(false);setError('Music needs another try. Tap play to retry.')};
  audio.addEventListener('playing',onPlaying);audio.addEventListener('pause',onPause);audio.addEventListener('error',onError);
  const unlock=(event:Event)=>{const target=event.target;if(target instanceof Element&&target.closest('[data-music-control]'))return;start()};
  const visibility=()=>{if(document.hidden)audio.pause();else start()};
  window.addEventListener('pointerdown',unlock);window.addEventListener('click',unlock);window.addEventListener('keydown',unlock);document.addEventListener('visibilitychange',visibility);start();
  return()=>{window.removeEventListener('pointerdown',unlock);window.removeEventListener('click',unlock);window.removeEventListener('keydown',unlock);document.removeEventListener('visibilitychange',visibility);audio.removeEventListener('playing',onPlaying);audio.removeEventListener('pause',onPause);audio.removeEventListener('error',onError);audio.pause();audio.removeAttribute('src');audio.load();audioRef.current=null};
 },[start]);
 const toggle=()=>{const audio=audioRef.current;if(!audio)return;if(!audio.paused){wantedRef.current=false;audio.pause()}else{wantedRef.current=true;if(volumeRef.current===0){volumeRef.current=.24;setVolumeState(.24);audio.volume=.24}if(audio.error){audio.load();setError('')}start()}save()};
 const setVolume=(amount:number)=>{const next=Math.max(0,Math.min(.7,amount));volumeRef.current=next;setVolumeState(next);if(audioRef.current)audioRef.current.volume=next;save()};
 return {playing,volume,error,start,toggle,setVolume};
}

export function SoundtrackControl({music}: {music:ReturnType<typeof useSoundtrack>}){
 return <div className="music-player" data-music-control="true"><button className="music-toggle" onClick={music.toggle} aria-label={music.playing?'Pause background music':'Play background music: Other Lives'} aria-pressed={music.playing} title={music.error||'Other Lives · original instrumental'}><span className={`music-disc ${music.playing?'is-playing':''}`}><Music2 size={16}/></span><span className="music-title"><strong>Other Lives</strong><small>{music.playing?'Now playing':'Play music'}</small></span>{music.playing?<Pause size={14}/>:<Play size={14}/>}</button><div className="music-volume"><Volume1 size={14}/><Slider aria-label="Music volume" min={0} max={70} value={[Math.round(music.volume*100)]} onValueChange={v=>music.setVolume((Array.isArray(v)?v[0]:v)/100)}/></div>{music.error&&<span className="music-error" role="status">{music.error}</span>}</div>;
}
