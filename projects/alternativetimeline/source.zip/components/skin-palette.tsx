'use client';
import {publicPath} from '@/lib/paths';
import {useEffect,useState} from 'react';

const originals={head:publicPath('/art/expressive-faces.png'),body:publicPath('/art/miniature-parts.png')};
const cache=new Map<string,Promise<typeof originals>>();
let source:Promise<{head:HTMLImageElement;body:HTMLImageElement;mask:HTMLImageElement}>|undefined;
function load(url:string){return new Promise<HTMLImageElement>((resolve,reject)=>{const image=new Image();image.onload=()=>resolve(image);image.onerror=reject;image.src=url})}
const clamp=(n:number,a=0,b=1)=>Math.max(a,Math.min(b,n));
const ramp=(a:number,b:number,x:number)=>{const t=clamp((x-a)/(b-a));return t*t*(3-2*t)};
// Runtime complexion material. Hue and luminance protect eyes, lips, hair and facial texture.
function recolour(image:HTMLImageElement,color:string,kind:'head'|'body',mask:HTMLImageElement){
 const canvas=document.createElement('canvas');canvas.width=canvas.height=768;
 const ctx=canvas.getContext('2d',{willReadFrequently:true});if(!ctx)throw Error('Canvas unavailable');
 ctx.drawImage(image,0,0,768,768);const pixels=ctx.getImageData(0,0,768,768),data=pixels.data;
 let matte:Uint8ClampedArray|undefined;
 if(kind==='body'){ctx.clearRect(0,0,768,768);ctx.drawImage(mask,0,0,768,768);matte=ctx.getImageData(0,0,768,768).data}
 const target=[1,3,5].map(i=>parseInt(color.slice(i,i+2),16));
 const refs=[[185,112,70],[234,174,141],[147,79,53],[221,150,88],[189,111,71],[177,93,56],[242,190,164],[210,123,70]];
 for(let i=0;i<data.length;i+=4){
  if(data[i+3]===0)continue;
  const [r,g,b]=[data[i],data[i+1],data[i+2]],max=Math.max(r,g,b),min=Math.min(r,g,b),delta=max-min;
  let amount=0,reference=215;
  if(kind==='body')amount=ramp(230,250,Math.min(matte![i],matte![i+1],matte![i+2]));
  else if(max===r&&delta>0){
   const hue=60*(g-b)/delta,saturation=delta/max;
   const luminance=r*.2126+g*.7152+b*.0722;
   amount=ramp(-4,3,hue)*(1-ramp(48,64,hue))*ramp(.05,.16,saturation)*ramp(26,57,luminance);
   const pixel=i/4,tile=(Math.floor(pixel/768/192)*4+Math.floor(pixel%768/192))%8;
   if(tile===1)amount*=1-ramp(.62,.82,saturation);
   reference=refs[tile][0]*.2126+refs[tile][1]*.7152+refs[tile][2]*.0722;
  }
  if(amount<=0)continue;
  const luminance=r*.2126+g*.7152+b*.0722,shading=(luminance-reference)*.55;
  for(let channel=0;channel<3;channel++){const toned=clamp(target[channel]+shading,0,255);data[i+channel]=Math.round(data[i+channel]*(1-amount)+toned*amount)}
 }
 ctx.putImageData(pixels,0,0);return canvas.toDataURL('image/png');
}
export function useSkinPalette(color:string){
 const [result,setResult]=useState<{color:string;urls:typeof originals}>({color:'original',urls:originals});
 useEffect(()=>{
  if(color==='original')return;
  let current=true;
  if(!cache.has(color)){
   source??=Promise.all([load(originals.head),load(originals.body),load(publicPath('/art/body-skin-material.png'))]).then(([head,body,mask])=>({head,body,mask}));
   const job=source.then(({head,body,mask})=>({head:recolour(head,color,'head',mask),body:recolour(body,color,'body',mask)}));
   cache.set(color,job);if(cache.size>12)cache.delete(cache.keys().next().value!);
  }
  cache.get(color)!.then(urls=>{if(current)setResult({color,urls})}).catch(()=>{cache.delete(color);source=undefined});
  return()=>{current=false};
 },[color]);
 return color==='original'?originals:result.color===color?result.urls:originals;
}
