import {Sparkles,Compass,Footprints} from 'lucide-react';
import {reflectionFor} from '@/lib/reflection.mjs';

export default function ReflectionSummary({result}:any){
 const reflection=reflectionFor(result);
 return <section className="reflection-summary" aria-label="Your reflection"><div className="reflection-heading"><Sparkles size={18}/><h3>A little clarity to take with you.</h3><span>FROM THIS SIMULATION</span></div><div className="reflection-points">{[
  {title:'What this life reveals',text:reflection.discovery,Icon:Sparkles},
  {title:'The tradeoff to notice',text:reflection.tradeoff,Icon:Compass},
  {title:'One small experiment',text:reflection.experiment,Icon:Footprints}
 ].map(({title,text,Icon})=><article key={title}><h4><Icon size={16}/>{title}</h4><p>{text}</p></article>)}</div></section>;
}
