# LIFE TIMELINE

A reusable, private-by-default browser life simulation with an experimental illustrated interface. Create a profile, assemble one to five decisions, respond to events, advance up to thirty years, rewind, and compare up to five universes.

## Run

Use Node 22.13+ and the package manager from the lockfile. `pnpm dev` serves the development app; `pnpm build` creates the static site and complete offline resource cache; `pnpm test` runs the pure-engine regression checks.

## Architecture

- `lib/engine.mjs`: deterministic monthly simulation, personality modifiers, weighted events, interaction rules, compounding, ancestry, insights, and import/export.
- `lib/model.mjs`: profile defaults and display labels.
- `lib/content/*.json`: 264 scenarios, 270 events, 194 interaction rules, 100 chains, 1,500 modular narrative templates, 326 insights, 240 conditional future-self templates, 100 fictional profiles, five challenges, and nine achievements.
- `scripts/build-content.py`: build-time expansion of authored scenario and narrative fragments. Adding content does not require changing the simulation loop.
- `scripts/build-offline.mjs`: precaches all static assets after the production build.
- `app/page.tsx` and `components`: profile-first game loop, browser-local saves, and optional WebMCP hooks.
- `docs/DESIGN.md`: visual direction and original artwork provenance.

No runtime AI, API keys, accounts, external fonts, or generative services are needed by the application. After the first complete online load, the static application is cached by a service worker and supports offline use in browsers that permit service workers and local storage. Clearing site data removes these local saves; JSON export provides a backup.

## Interpretation

This is an illustrative simulation and reflection game, not a calibrated predictor or financial, legal, medical, or relationship advice. Rules and probabilities are intentionally simplified. Currency amounts share common model assumptions rather than country-specific economic forecasts. Gender and country do not introduce stereotyped demographic penalties. Financial reversibility is simplified; scenario preparation intensity is a game abstraction.

## Validation

Eighteen regression groups exercise all authored scenarios and approaches, seeded replay, long horizons, sequence changes, responses, sharing, personal identity, and reflective takeaways. TypeScript and the production build are checked separately. Desktop and mobile browser checks cover setup, simulation, miniature controls, contextual replies, and expandable metrics. The deployment test checks subpath resources and service worker isolation.


## Portable hosting and music

See [HOSTING.md](HOSTING.md) for the independent static build, local preview, music controls, and moving browser saves to a new address. The hosting-specific plugin and deployment manifest have been removed. The original instrumental is bundled locally and loops during play; it can be paused, and the preference is remembered.
