# Hosting LIFE TIMELINE

This application is a portable static website. Its simulation runs in the browser and works with standard static hosting.

## Upload the ready-made site

Extract `life-timeline-site.zip` and upload its contents to the root of your HTTPS website. `index.html`, `_next/`, `art/`, `audio/`, and `sw.js` must retain their names and relative locations. The ZIP contains the finished website, ready for direct upload.

The default build uses the domain root. Set `NEXT_PUBLIC_BASE_PATH` to mount the application inside an existing website, as described below. The server should deliver `.js` as JavaScript, `.css` as CSS, and `.wav` as `audio/wav`. Standard static hosts normally do this automatically. Keep `index.html` and `sw.js` revalidating on subsequent visits so updates can be discovered. Allow the application’s scripts, styles, images, media, and service worker. Custom complexions use locally generated data images.

## Work with the source

Use Node.js 22.13 or newer and pnpm with the included lockfile:

```sh
pnpm install --frozen-lockfile
pnpm dev
```

To create and preview a production build:

```sh
pnpm build
pnpm start
```

The static output is `dist/client`. The included preview server listens on `127.0.0.1:3000` by default. `PORT` and `HOST` can change its listen address. It supports audio byte-range requests. The preview server is optional. Your own static host can serve the same files.

## Music

“Other Lives” is an original 40-second instrumental bundled at `audio/other-lives.wav`. It contains a melody, chord accompaniment, bass, and soft percussion. It loops locally from the included audio file. Music is enabled by default and starts when the browser permits playback, with an interaction fallback. Clicking “I understand. Let’s play.” also starts it. The player always offers pause/play, and volume is adjustable on larger screens. Music preference and volume are remembered on the device, and playback pauses while the tab is hidden.

Browsers may require a click or tap before audible playback. See [MDN’s autoplay guide](https://developer.mozilla.org/en-US/docs/Web/Media/Guides/Autoplay). A previously muted user can resume with the music button. The deterministic composition can be regenerated with `python3 scripts/compose-soundtrack.py`.

## Privacy and migration

Simulation data stays in browser local storage. Export a backup from the old address and import it at your new address: each origin keeps separate browser saves. A static host may keep ordinary request logs according to its policies. The privacy notice describes hosting in general terms. The app opens directly and saves progress locally.

Offline access requires HTTPS (or localhost), browser support, and one complete initial load. Open the site through a web server.

These files are ready for your chosen host. A previously published preview is separate from this export.

## Character and identity

The profile accepts self-described race, ethnicity, heritage, and gender. Choose among ten complexion presets or mix a custom colour. Facial expressions, proportions, outfits, display colours, and keepsakes travel with saved and shared lives. Identity and appearance serve as personal details. Numerical resources, preferences, and decisions drive the simulation.

## Quick entry and reflections

Start exploring from the first profile page using the visible starting amounts. Fine-tune the full profile at any point. Timeline results begin with a personal takeaway, a tradeoff to consider, and a small experiment. Expand the numbers and timeline map for additional detail. Strategy and God modes begin with these details expanded. Event responses use wording specific to their category, with additional wording for individual events.

## pearlinglim.com deployment

The application lives inside the existing `earlessentials/personal` repository at `public/alternativetimeline/`. The existing GitHub Pages workflow publishes it alongside the other pages.

Build for this address:

```sh
NEXT_PUBLIC_BASE_PATH=/alternativetimeline pnpm build
NEXT_PUBLIC_BASE_PATH=/alternativetimeline node scripts/test-deployment.mjs
```

The finished app is `dist/client/alternativetimeline/`. Copy this directory to `public/alternativetimeline/` in the personal website repository. Preserve every existing file outside that directory. The complete editable source is archived separately at `projects/alternativetimeline/source.zip` with its build instructions.

The music, artwork, scripts, styles, and offline cache all stay under `/alternativetimeline/`. The service worker handles this application's resource list and uses a separate cache name. Visitors open the application directly on pearlinglim.com. The domain's existing canonical address and deployment settings remain in place.
