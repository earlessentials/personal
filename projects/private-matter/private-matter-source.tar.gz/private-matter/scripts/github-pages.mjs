import { mkdir, copyFile, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';

// Deliberately separate from the private app: Pages has no authentication server.
// Only the empty public edition belongs in this output. Never copy .env or drafts.
const output = resolve(process.argv[2] || 'work/github-pages/privatematter');
await mkdir(output, { recursive: true });
const arrow = '<span aria-hidden="true">↗</span>';
const pages = [
  ['index.html', 'PRIVATE MATTER — An independent publication', `<main id="main" class="threshold wrap"><div class="threshold-top meta"><span>AN INDEPENDENT ARCHIVE OF THOUGHT</span><span>EST. 2026</span></div><h1>Private<br><em>Matter.</em></h1><div class="threshold-bottom"><p>A publication for<br>ideas worth sitting with.</p><div><a class="entrance-link" href="reading-room.html">Enter the reading room ${arrow}</a><p class="aside">The first page is still to be written.</p></div></div><div class="threshold-foot"><span>Independently curated.</span><span>Read deliberately.</span></div></main>`],
  ['reading-room.html', 'The reading room — PRIVATE MATTER', `<main id="main" class="room wrap"><div class="room-heading"><p class="meta">PRIVATE MATTER / THE READING ROOM</p><h1>A little room<br><em>for the words.</em></h1><p>Each piece in its own time.<br>Read at your own pace.</p></div><section class="unwritten" aria-label="Empty publication"><div class="unwritten-margin"><span class="meta">THE FIRST PAGE</span><span class="unwritten-mark" aria-hidden="true">pm.</span></div><div class="unwritten-copy"><h2>To be<br><em>written.</em></h2><p>No matters have been published yet.<br>The first words will appear here.</p></div><div class="unwritten-colophon meta"><span>CURATED BY PEARLING LIM</span><span>READ DELIBERATELY.</span></div></section></main>`],
  ['archive.html', 'The archive — PRIVATE MATTER', `<main id="main" class="archive wrap"><p class="meta">PRIVATE MATTER / THE ARCHIVE</p><h1>The <em>archive.</em></h1><p class="deck">A place for the words to stay.</p><section class="archive-empty"><p class="meta">NOTHING PUBLISHED YET</p><h2>Every archive begins<br>with a <em>first page.</em></h2><p>New publications will be collected here.</p><a class="text-link" href="reading-room.html">Return to the reading room ${arrow}</a></section></main>`],
  ['about.html', 'About — PRIVATE MATTER', `<main id="main" class="about wrap"><p class="meta">ABOUT PRIVATE MATTER</p><h1>The thought should<br>be worth <em>staying with.</em></h1><div class="about-text"><p>PRIVATE MATTER is an independent digital publication for essays, observations and inquiries that deserve more room than the internet usually gives them.</p><p>A space for considered words and unhurried reading. Each piece arrives in its own time.</p><p class="curator-note">Independently curated by Pearling Lim.</p><a class="text-link" href="reading-room.html">Enter the reading room ${arrow}</a></div></main>`],
];
for (const [file, title, main] of pages) {
  const nav = (href, text) => `<a href="${href}"${href === file ? ' aria-current="page"' : ''}>${text}</a>`;
  await writeFile(resolve(output, file), `<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="#090909"><title>${title}</title><meta name="description" content="An independent publication for ideas worth sitting with. Curated by Pearling Lim."><link rel="canonical" href="https://pearlinglim.com/privatematter/${file === 'index.html' ? '' : file}"><link rel="icon" href="favicon.svg"><link rel="stylesheet" href="style.css"><link rel="preload" href="editorial-regular.ttf" as="font" type="font/ttf" crossorigin></head><body><a class="skip-link" href="#main">Skip to content</a><header class="site-header wrap"><a href="./" class="brand">PRIVATE MATTER<span>AN INDEPENDENT PUBLICATION</span></a><nav aria-label="Primary navigation">${nav('about.html', 'About')}${nav('reading-room.html', 'Reading room')}</nav></header>${main}<footer class="site-footer wrap"><div><a class="footer-brand" href="./">PRIVATE MATTER</a><p>Curated independently by Pearling Lim.</p></div><nav aria-label="Footer navigation">${nav('reading-room.html', 'Reading room')}${nav('archive.html', 'Archive')}${nav('about.html', 'About')}</nav><span class="copyright">© 2026</span></footer></body></html>\n`);
}
await copyFile('github-pages/style.css', resolve(output, 'style.css'));
for (const name of ['editorial-regular.ttf', 'editorial-italic.ttf', 'OFL.txt']) {
  await copyFile(`public/fonts/${name}`, resolve(output, name));
}
await copyFile('public/favicon.svg', resolve(output, 'favicon.svg'));
await copyFile('github-pages/README.md', resolve(output, 'README.md'));
console.log(`Built the empty GitHub Pages edition: ${output}`);
