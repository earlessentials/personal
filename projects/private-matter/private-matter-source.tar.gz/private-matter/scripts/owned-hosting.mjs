import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { cpSync, mkdirSync } from 'node:fs';

const command = process.argv[2] || 'build';
if (!['build', 'dev', 'deploy'].includes(command)) throw Error('Expected build, dev or deploy.');
process.env.PRIVATE_MATTER_HOSTING = 'owned';
process.env.NEXT_PUBLIC_BASE_PATH = '/privatematter';
const databaseId = process.env.PRIVATE_MATTER_DATABASE_ID || '';
if (command === 'deploy' && (!/^[a-f0-9-]{36}$/i.test(databaseId) || databaseId === '00000000-0000-4000-8000-000000000000')) {
  throw Error('Set PRIVATE_MATTER_DATABASE_ID to the D1 database in your own Cloudflare account.');
}
function run(file, args) {
  const result = spawnSync(process.execPath, [fileURLToPath(new URL(file, import.meta.url)), ...args], { stdio: 'inherit', env: process.env });
  if (result.error) throw result.error;
  if (result.status !== 0) process.exit(result.status || 1);
}
run('./run-framework.mjs', [command === 'dev' ? 'dev' : 'build']);
if (command !== 'dev') {
  mkdirSync('dist/client/privatematter', { recursive: true });
  cpSync('public', 'dist/client/privatematter', { recursive: true });
}
if (command === 'deploy') run('../node_modules/wrangler/bin/wrangler.js', ['deploy', '--config', 'dist/server/wrangler.json']);
