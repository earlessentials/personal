"""Build the checkout-only country index from an official DB-IP Lite CSV gzip.

Usage: python3 scripts/build-country-data.py download.csv.gz YYYY-MM
The data remains on the server; visitor IP addresses are never sent to DB-IP.
"""
import csv, gzip, hashlib, ipaddress, json, re, sys
from pathlib import Path

source, release = Path(sys.argv[1]), sys.argv[2]
assert re.fullmatch(r'\d{4}-\d{2}', release)
ranges = {'indonesia4': [], 'indonesia6': [], 'unknown4': [], 'unknown6': []}
records = 0
with gzip.open(source, 'rt') as stream:
    for first, last, country in csv.reader(stream):
        records += 1
        if country not in ('ID', 'ZZ'): continue
        first, last = ipaddress.ip_address(first), ipaddress.ip_address(last)
        assert first.version == last.version and int(first) <= int(last)
        target = ranges[('indonesia' if country == 'ID' else 'unknown') + str(first.version)]
        start, end = int(first), int(last)
        if target and target[-1][1] + 1 == start: target[-1][1] = end
        else:
            assert not target or target[-1][1] < start
            target.append([start, end])

out = Path('supabase/functions/private-matter/country-data.mjs')
header = f'''// Derived from DB-IP IP to Country Lite, {release}.
// https://db-ip.com/db/download/ip-to-country-lite
// CC BY 4.0: https://creativecommons.org/licenses/by/4.0/
// Modified: retain Indonesian and unknown ranges; merge adjacent ranges.
// Source gzip SHA-256: {hashlib.sha256(source.read_bytes()).hexdigest()}
// Regenerate with scripts/build-country-data.py. Do not hand-edit.
export const countryDataRelease={json.dumps(release)};
'''
for key, values in ranges.items():
    header += 'export const ' + key + '=[' + ','.join('['+','.join(hex(n)+'n' for n in row)+']' for row in values) + '];\n'
out.write_text(header)
print(json.dumps({'release': release, 'sourceRecords': records, 'ranges': {k: len(v) for k,v in ranges.items()}, 'bytes': out.stat().st_size}))
