/** Keep whitespace outside Markdown delimiters, and preserve the editable selection. */
export function formatEmphasis(body: string, start: number, end: number, kind: 'bold' | 'italic'): {body:string;start:number;end:number} {
  const marker = kind === 'bold' ? '**' : '*';
  const selected = body.slice(start, end);
  if (!selected.trim()) {
    const text = marker + 'text' + marker;
    return {body: body.slice(0, start) + text + body.slice(end), start: start + marker.length, end: start + marker.length + 4};
  }
  start += selected.length - selected.trimStart().length;
  end -= selected.length - selected.trimEnd().length;
  const text = body.slice(start, end);
  const left = body.slice(0, start), right = body.slice(end);
  if (/\n[\t ]*\n/.test(text)) {
    const formatted = text.split(/(\n[\t ]*\n)/).map(part => part.trim() ? formatEmphasis(part, 0, part.length, kind).body : part).join('');
    return {body: left + formatted + right, start, end: start + formatted.length};
  }
  const inside = Math.min(text.match(/^\*+/)?.[0].length || 0, text.match(/\*+$/)?.[0].length || 0);
  if (text.length > inside * 2 && (kind === 'bold' ? inside >= 2 : inside % 2 === 1)) {
    const unwrapped = text.slice(marker.length, -marker.length);
    return {body: left + unwrapped + right, start, end: start + unwrapped.length};
  }
  const before = left.match(/\*+$/)?.[0].length || 0;
  const after = right.match(/^\*+/)?.[0].length || 0;
  const count = Math.min(before, after);
  const active = kind === 'bold' ? count >= 2 : count % 2 === 1;
  if (active) {
    return {body: left.slice(0, -marker.length) + text + right.slice(marker.length), start: start - marker.length, end: end - marker.length};
  }
  const formatted = marker + text + marker;
  return {body: left + formatted + right, start: start + marker.length, end: start + formatted.length - marker.length};
}
