import {sitePath} from './paths';

// Codes are sent only to the authentication service and are never persisted.
// Stored values are revocable opaque session tokens, never proof of a role.
export const publicationApiUrl=process.env.NEXT_PUBLIC_API_URL || '';
const scopes=['reader','contributor'] as const;
type Scope=typeof scopes[number];
const tokenKey=(scope:Scope)=>`private-matter.session.${scope}`;

function readToken(scope:Scope){
  try{return sessionStorage.getItem(tokenKey(scope))||''}catch{return ''}
}
function updateToken(scope:Scope,value:unknown){
  try{
    if(typeof value==='string'&&/^[a-f0-9]{64}$/.test(value))sessionStorage.setItem(tokenKey(scope),value);
    else sessionStorage.removeItem(tokenKey(scope));
  }catch{throw Error('Allow session storage in this tab to keep your access active.')}
}

export async function publicationApi(path:string,options?:RequestInit):Promise<any>{
  if(!path.startsWith('/api/'))throw Error('Invalid publication request.');
  const headers=new Headers(options?.headers);
  if(publicationApiUrl)for(const scope of scopes){
    const token=readToken(scope);
    if(token)headers.set(`X-PM-${scope}`,token);
  }
  const url=publicationApiUrl?publicationApiUrl+path.slice(4):sitePath(path);
  const response=await fetch(url,{cache:'no-store',...options,headers,credentials:publicationApiUrl?'omit':'same-origin'});
  let data:any;
  try{data=await response.json()}catch{throw Error('The publication service is not connected yet. Please try again later.')}
  if(!response.ok)throw Object.assign(Error(data.error||'Please try again.'),{status:response.status});
  if(publicationApiUrl&&path.split('?')[0]==='/api/session'){
    if(options?.method==='POST'){
      if(!data.tokens||!scopes.some(scope=>/^[a-f0-9]{64}$/.test(data.tokens[scope]||'')))throw Error('Access could not be established.');
      for(const scope of scopes)if(data.tokens[scope])updateToken(scope,data.tokens[scope]);
    }
    if(options?.method==='DELETE'){
      const scope=new URL(path,'https://publication.invalid').searchParams.get('scope');
      for(const item of scopes)if(!scope||scope===item)updateToken(item,null);
    }
  }
  return data;
}
