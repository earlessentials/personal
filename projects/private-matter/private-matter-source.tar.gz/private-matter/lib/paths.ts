// Store publication media paths independently of the deployment address.
export const basePath = process.env.NEXT_PUBLIC_BASE_PATH || '';
export function sitePath(path: string) {
  if (!path.startsWith('/') || path.startsWith('//') || !basePath) return path;
  if (path === basePath || path.startsWith(basePath + '/')) return path;
  return basePath + path;
}
