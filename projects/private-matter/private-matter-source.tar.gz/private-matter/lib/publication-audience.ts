export const publicationAudiences = {
  private: {label:'Readers with a code',description:'The full article and its media require reader access.'},
  excerpt: {label:'Public excerpt',description:'Anyone can read your chosen excerpt. The full article requires reader access.'},
  public: {label:'Everyone',description:'Anyone can read and share the full article without a code.'},
} as const;

export function publicationAudience(value:string|undefined){
  return publicationAudiences[value as keyof typeof publicationAudiences] || publicationAudiences.private;
}
