import {database} from './access';
export const fields='id,slug,title,subtitle,category,body,author,access_id,created_at,updated_at,published_at,status,matter_number,tags,cover,caption,image_alt,image_mode,references_text,seo_description,visibility,excerpt';
export function present(r:any,full=false){return {id:r.id,slug:r.slug,title:r.title,subtitle:r.subtitle,category:r.category,author:r.author,createdAt:r.published_at||r.created_at,updatedAt:r.updated_at,status:r.status,number:r.matter_number,tags:JSON.parse(r.tags||'[]'),minutes:Math.max(1,Math.ceil(r.body.trim().split(/\s+/).length/180)),cover:r.cover,caption:r.caption,imageAlt:r.image_alt,imageMode:r.image_mode,visibility:r.visibility,...(full?{body:r.body,references:r.references_text,seoDescription:r.seo_description,excerpt:r.excerpt}:{})};}
// Retire only the original generated examples. Reserved Matter numbers remain permanent.
export async function ensurePublication(){
  const db=database();
  if(await db.prepare("SELECT value FROM settings WHERE key='empty_publication_v1'").first())return;
  const exampleIds=['the-art-of-paying-attention','a-room-of-ones-own','in-praise-of-the-unfinished','the-things-we-keep'];
  await db.batch([
    ...exampleIds.map(id=>db.prepare("UPDATE posts SET status='archived' WHERE id=? AND access_id='editorial'").bind(id)),
    db.prepare("INSERT OR IGNORE INTO settings (key,value) VALUES ('empty_publication_v1','1')")
  ]);
}
export async function findMatter(id:string){await ensurePublication();return database().prepare(`SELECT ${fields} FROM posts WHERE status IN ('draft','published') AND (id=? OR slug=? OR matter_number=?)`).bind(id,id,/^\d+$/.test(id)?Number(id):-1).first<any>();}
export function validate(data:any){const text=(k:string,max:number)=>typeof data[k]==='string'&&data[k].length<=max;return text('title',120)&&text('subtitle',240)&&text('body',100000)&&text('category',100)&&Array.isArray(data.tags)&&data.tags.length<=12&&data.tags.every((x:any)=>typeof x==='string'&&x.length<=40)&&['private','excerpt','public'].includes(data.visibility)&&['inline','wide','full'].includes(data.imageMode)&&['cover','caption','imageAlt','references','seoDescription','excerpt'].every(k=>text(k,k==='references'?10000:k==='excerpt'?4000:1000))&&(!data.cover||/^\/api\/media\/[a-f0-9-]+$/.test(data.cover)||/^https:\/\//.test(data.cover)||data.cover==='/images/attention.jpg');}
