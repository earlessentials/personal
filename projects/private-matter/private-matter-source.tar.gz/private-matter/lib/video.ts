export const MAX_VIDEO_BYTES = 25 * 1024 * 1024;
export type VideoSource = {kind:'youtube';id:string;url:string;embed:string}|{kind:'upload';url:string};
export function videoSource(value:string):VideoSource|null {
  const input=value.trim();
  if(/^\/api\/media\/[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/.test(input))return{kind:'upload',url:input};
  try{
    const u=new URL(input.startsWith('www.')?'https://'+input:input);
    if(!['https:','http:'].includes(u.protocol)||u.username||u.password||u.port)return null;
    const host=u.hostname.toLowerCase(),parts=u.pathname.split('/').filter(Boolean);
    let id='';
    if(host==='youtu.be'&&parts.length===1)id=parts[0];
    else if(['youtube.com','www.youtube.com','m.youtube.com','youtube-nocookie.com','www.youtube-nocookie.com'].includes(host)){
      if(u.pathname==='/watch')id=u.searchParams.get('v')||'';
      else if(parts.length===2&&['embed','shorts','live'].includes(parts[0]))id=parts[1];
    }
    if(!/^[\w-]{11}$/.test(id))return null;
    return{kind:'youtube',id,url:'https://www.youtube.com/watch?v='+id,embed:'https://www.youtube-nocookie.com/embed/'+id+'?rel=0'};
  }catch{return null}
}
export function videoMarkdown(url:string,caption=''){
  const source=videoSource(url);if(!source)throw Error('Enter a YouTube video link.');
  const label=(caption.trim()||'Watch video').replace(/[\\[\]]/g,'\\$&').replace(/[\r\n]+/g,' ');
  return `\n\n[${label}](${source.url} "video")\n\n`;
}
export function byteRange(value:string|null,size:number):{offset:number;length:number}|null|false{
  if(!value)return null;
  const m=/^bytes=(\d*)-(\d*)$/.exec(value);
  if(!m||(!m[1]&&!m[2])||size<=0)return false;
  let start=m[1]?Number(m[1]):Math.max(0,size-Number(m[2]));
  let end=m[1]?(m[2]?Number(m[2]):size-1):size-1;
  if(!Number.isSafeInteger(start)||!Number.isSafeInteger(end)||start<0||end<start||start>=size||(!m[1]&&Number(m[2])===0))return false;
  end=Math.min(end,size-1);return{offset:start,length:end-start+1};
}
