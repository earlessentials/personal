'use client';
import type {ComponentProps} from 'react';
import NextLink from 'next/link';
import {basePath,sitePath} from '@/lib/paths';

// Native navigation keeps the isolated, subdirectory-hosted publication
// independent of the surrounding site's client router and route cache.
export default function PublicationLink({href,...props}:ComponentProps<'a'>&{href:string}) {
  return basePath ? <a href={sitePath(href)} {...props}/> : <NextLink href={href} {...props}/>;
}
