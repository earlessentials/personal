import {createHandler} from './handler.mjs';

const serviceUrl=Deno.env.get('SUPABASE_URL')!;
const serviceKey=Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
if(!serviceUrl||!serviceKey)throw Error('Backend configuration missing');
const auth={apikey:serviceKey,Authorization:`Bearer ${serviceKey}`};
async function backend(path:string,init:RequestInit={}){
  const response=await fetch(serviceUrl+path,{...init,headers:{...auth,...init.headers}});
  if(!response.ok)throw Error('Backend operation failed');
  return response;
}
const storagePath='/storage/v1/object';
Deno.serve(createHandler({
  codes:JSON.parse(Deno.env.get('FOLIO_CODES_JSON')||'null'),
  paymentUrl:Deno.env.get('FOLIO_PAYMENT_URL')||'',
  origins:['https://pearlinglim.com','https://www.pearlinglim.com'],
  rpc:async(op:string,data:unknown,user:unknown)=>
    (await backend('/rest/v1/rpc/pm_api',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({p_op:op,p_data:data,p_user:user})})).json(),
  storage:{
    upload:async(id:string,bytes:Uint8Array,type:string)=>{
      await backend(`${storagePath}/private-matter/${id}`,{method:'POST',headers:{'Content-Type':type,'Cache-Control':'private, max-age=0'},body:bytes});
    },
    remove:async(id:string)=>{await backend(`${storagePath}/private-matter`,{method:'DELETE',headers:{'Content-Type':'application/json'},body:JSON.stringify({prefixes:[id]})});},
    sign:async(id:string,seconds:number)=>{
      const data=await (await backend(`${storagePath}/sign/private-matter/${id}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({expiresIn:seconds})})).json();
      const url=new URL('/storage/v1'+data.signedURL,serviceUrl);
      if(url.origin!==new URL(serviceUrl).origin||!url.pathname.startsWith('/storage/v1/object/sign/private-matter/'))throw Error('Invalid media address');
      return url.toString();
    },
  },
}));
