import {isIP} from 'node:net';
import {indonesia4,indonesia6,unknown4,unknown6} from './country-data.mjs';

function contains(ranges,value){
  let low=0,high=ranges.length-1;
  while(low<=high){const middle=(low+high)>>>1,[first,last]=ranges[middle];
    if(value<first)high=middle-1;else if(value>last)low=middle+1;else return true;
  }
  return false;
}
function ipv4Value(ip){return ip.split('.').reduce((value,part)=>(value<<8n)+BigInt(part),0n);}
function ipv6Value(ip){
  if(ip.includes('.')){const split=ip.lastIndexOf(':'),v4=ipv4Value(ip.slice(split+1));ip=ip.slice(0,split+1)+(v4>>16n).toString(16)+':'+(v4&65535n).toString(16);}
  const halves=ip.split('::'),left=halves[0]?halves[0].split(':'):[],right=halves[1]?halves[1].split(':'):[];
  const parts=halves.length===2?[...left,...Array(8-left.length-right.length).fill('0'),...right]:left;
  return parts.reduce((value,part)=>(value<<16n)+BigInt('0x'+part),0n);
}
export function regionForIp(ip){
  if(typeof ip!=='string'||ip.length>45||ip.includes('%'))return null;
  let version=isIP(ip);if(!version)return null;
  let value=version===4?ipv4Value(ip):ipv6Value(ip);
  // Treat IPv4-mapped IPv6 exactly like its original IPv4 address.
  if(version===6&&value>>32n===65535n){version=4;value&=0xffffffffn;}
  if(contains(version===4?unknown4:unknown6,value))return null;
  return contains(version===4?indonesia4:indonesia6,value)?'indonesia':'international';
}
export function regionForRequest(request){
  // Supabase documents X-Forwarded-For as the original client address.
  // This suggestion is not a security boundary; readers may switch checkout.
  const forwarded=request.headers.get('x-forwarded-for')?.split(',')[0].trim();
  const ip=forwarded||request.headers.get('cf-connecting-ip')?.trim();
  return regionForIp(ip);
}
