alter table public.pm_reader_passes drop constraint pm_reader_passes_duration_days_check;
alter table public.pm_reader_passes add constraint pm_reader_passes_duration_days_check check (duration_days in (7,28,90,180));
create or replace function public.pm_api(p_op text, p_data jsonb default '{}', p_user jsonb default '{}')
returns jsonb language plpgsql security invoker set search_path = '' as $$
declare
  v_reader boolean := coalesce((p_user->>'reader')::boolean,false);
  v_admin boolean := coalesce((p_user->>'admin')::boolean,false);
  v_actor text := p_user->>'contributorId';
  v_post public.pm_posts;
  v_media public.pm_media;
  v_result jsonb;
  v_next jsonb;
  v_key text;
  v_count integer;
  v_number bigint;
  v_url text;
  v_media_id text;
  v_pass public.pm_reader_passes;
  v_expiry timestamptz;
  v_date date;
begin
  if p_op='passes' then
    if not v_admin then return '{"_status":403,"error":"Curator access required."}'; end if;
    select coalesce(jsonb_agg(to_jsonb(p) - 'code_hash' order by p.created_at desc),'[]') into v_result
      from (select * from public.pm_reader_passes order by created_at desc limit 200) p;
    return jsonb_build_object('passes',v_result);
  elsif p_op='pass_create' then
    if not v_admin then return '{"_status":403,"error":"Curator access required."}'; end if;
    if (p_data->>'days') not in ('7','28','90','180') or coalesce(length(p_data->>'label'),0)>80 then
      return '{"_status":400,"error":"Choose 7, 28, 90 or 180 days and a label of up to 80 characters."}'; end if;
    insert into public.pm_reader_passes(id,code_hash,suffix,label,duration_days,expires_at)
      values((p_data->>'id')::uuid,p_data->>'hash',p_data->>'suffix',coalesce(p_data->>'label',''),(p_data->>'days')::int,
        now()+make_interval(days=>(p_data->>'days')::int)) on conflict(code_hash) do nothing returning * into v_pass;
    if v_pass.id is null then return '{"collision":true}'; end if;
    return jsonb_build_object('pass',to_jsonb(v_pass)-'code_hash');
  elsif p_op='pass_revoke' then
    if not v_admin then return '{"_status":403,"error":"Curator access required."}'; end if;
    update public.pm_reader_passes set revoked_at=coalesce(revoked_at,now()) where id=(p_data->>'id')::uuid returning * into v_pass;
    if v_pass.id is null then return '{"_status":404,"error":"Reader code not found."}'; end if;
    delete from public.pm_sessions where access_id='temporary:'||v_pass.id::text;
    return '{"ok":true}';
  elsif p_op='pass_lookup' then
    select jsonb_build_object('id','temporary:'||id::text,'role','reader','name',null) into v_result
      from public.pm_reader_passes where code_hash=p_data->>'hash' and revoked_at is null and expires_at>now();
    return coalesce(v_result,'null'::jsonb);
  elsif p_op='session' then
    select jsonb_build_object('accessId',s.access_id,'name',p.name,'hasProfile',p.access_id is not null,'temporary',s.access_id like 'temporary:%','expiresAt',s.expires_at)
      into v_result from public.pm_sessions s left join public.pm_profiles p on p.access_id=s.access_id
      where s.token_hash=p_data->>'hash' and s.scope=p_data->>'scope' and s.expires_at>now()
      and (s.access_id not like 'temporary:%' or (s.scope='reader' and exists(
        select 1 from public.pm_reader_passes t where 'temporary:'||t.id::text=s.access_id and t.revoked_at is null and t.expires_at>now())));
    return coalesce(v_result,'null'::jsonb);
  elsif p_op='rate' then
    delete from public.pm_attempts where expires_at<now();
    delete from public.pm_sessions where expires_at<now();
    -- A global cap remains effective even if an attacker forges proxy headers.
    foreach v_key in array array['global:'||(floor(extract(epoch from now())/900))::text,
      'client:'||(p_data->>'key')||':'||(floor(extract(epoch from now())/900))::text] loop
      insert into public.pm_attempts values(v_key,1,now()+interval '30 minutes')
        on conflict(key) do update set hits=pm_attempts.hits+1 returning hits into v_count;
      if v_count > (case when v_key like 'global:%' then 200 else 20 end) then
        return jsonb_build_object('allowed',false);
      end if;
    end loop;
    return jsonb_build_object('allowed',true);
  elsif p_op='login' then
    v_expiry:=now()+interval '7 days';
    if p_data->>'accessId' like 'temporary:%' then
      select * into v_pass from public.pm_reader_passes where 'temporary:'||id::text=p_data->>'accessId' and revoked_at is null and expires_at>now() for share;
      if v_pass.id is null or exists(select 1 from jsonb_array_elements(p_data->'sessions') x where x->>'scope'<>'reader') then
        return '{"_status":401,"error":"Access not recognized."}'; end if;
      v_expiry:=least(v_expiry,v_pass.expires_at);
    end if;
    for v_result in select value from jsonb_array_elements(p_data->'sessions') loop
      insert into public.pm_sessions values(v_result->>'hash',p_data->>'accessId',v_result->>'scope',v_expiry);
    end loop;
    return '{"ok":true}';
  elsif p_op='logout' then
    delete from public.pm_sessions where token_hash in (select jsonb_array_elements_text(p_data->'hashes'));
    return '{"ok":true}';
  elsif p_op='stories' then
    if not coalesce((p_data->>'publicOnly')::boolean,false) and not(v_reader or v_admin) then
      return '{"_status":401,"error":"Your reading session has closed."}';
    end if;
    select coalesce(jsonb_agg(to_jsonb(p) order by matter_number desc),'[]') into v_result
      from public.pm_posts p where status='published'
      and (not (p_data->>'publicOnly')::boolean or visibility='public')
      and (coalesce(p_data->>'q','')='' or strpos(lower(title||' '||subtitle||' '||body||' '||author||' '||category||' '||tags::text),lower(p_data->>'q'))>0)
      and (coalesce(p_data->>'subject','')='' or tags ? (p_data->>'subject'));
    return jsonb_build_object('rows',v_result);
  elsif p_op='story' then
    select * into v_post from public.pm_posts where status in ('draft','published') and
      (id::text=p_data->>'id' or slug=p_data->>'id' or matter_number::text=ltrim(p_data->>'id','0')) limit 1;
    if v_post.id is null or (v_post.status<>'published' and not(v_admin or coalesce(v_actor=v_post.access_id,false))) then
      return '{"_status":404,"error":"This matter does not exist."}';
    end if;
    if not(v_reader or v_admin or coalesce(v_actor=v_post.access_id,false) or v_post.visibility='public') then
      if v_post.visibility='private' then return '{"_status":401,"error":"Your reading session has closed."}'; end if;
      return jsonb_build_object('row',to_jsonb(v_post),'locked',true,'next',null);
    end if;
    select jsonb_build_object('number',matter_number,'slug',slug) into v_next from public.pm_posts
      where status='published' and matter_number>v_post.matter_number and (v_reader or v_admin or visibility='public') order by matter_number limit 1;
    return jsonb_build_object('row',to_jsonb(v_post),'locked',false,'next',v_next);
  elsif p_op='studio' then
    if v_actor is null then return '{"_status":401,"error":"Invitation required."}'; end if;
    select coalesce(jsonb_agg(to_jsonb(p) order by updated_at desc),'[]') into v_result from public.pm_posts p
      where status in ('draft','published') and (v_admin or access_id=v_actor);
    return jsonb_build_object('rows',v_result);
  elsif p_op='save' then
    if p_data ? 'publicationDate' then
      if not v_admin then return '{"_status":403,"error":"Only Pearling can adjust publication dates."}'; end if;
      if jsonb_typeof(p_data->'publicationDate')<>'string' or (p_data->>'publicationDate'<>'' and p_data->>'publicationDate' !~ '^[0-9]{4}-[0-9]{2}-[0-9]{2}$') then
        return '{"_status":400,"error":"Choose a valid publication date."}'; end if;
      begin
        v_date:=nullif(p_data->>'publicationDate','')::date;
      exception when others then return '{"_status":400,"error":"Choose a valid publication date."}'; end;
    end if;
    if p_data ? 'author' and (jsonb_typeof(p_data->'author')<>'string' or char_length(p_data->>'author')>60 or p_data->>'author' ~ '[[:cntrl:]]') then
      return '{"_status":400,"error":"Use a writer name of up to 60 characters."}';
    end if;
    if v_actor is null then return '{"_status":401,"error":"Invitation required."}'; end if;
    -- Serialize edits to the same UUID, including simultaneous first publishes.
    perform pg_advisory_xact_lock(hashtextextended(p_data->>'id',0));
    select * into v_post from public.pm_posts where id=(p_data->>'id')::uuid for update;
    if v_post.id is not null and not(v_admin or v_post.access_id=v_actor) then
      return '{"_status":403,"error":"This matter is not yours to edit."}';
    end if;
    if v_post.status='published' and p_data->>'action'='draft' and v_post.visibility<>p_data->>'visibility' then
      return '{"_status":400,"error":"Use Publish revision to confirm a change to who can read this matter."}';
    end if;
    for v_media_id in select jsonb_array_elements_text(p_data->'mediaIds') loop
      select * into v_media from public.pm_media where id=v_media_id::uuid;
      if v_media.id is null then return '{"_status":400,"error":"An uploaded image or video is unavailable. Please upload it again."}'; end if;
      if not(v_admin or v_media.owner_id=v_actor) then return '{"_status":403,"error":"Use images and videos uploaded with your own contributor code."}'; end if;
    end loop;
    v_number:=v_post.matter_number;
    if v_number is null and p_data->>'action'='publish' then v_number:=nextval('public.pm_matter_number'); end if;
    insert into public.pm_posts(id,slug,title,subtitle,category,body,author,access_id,published_at,status,matter_number,tags,cover,caption,image_alt,image_mode,references_text,seo_description,visibility,excerpt,display_date)
      values((p_data->>'id')::uuid,
        case when v_post.matter_number is not null then v_post.slug else (p_data->>'slugBase')||'-'||coalesce(v_number::text,left(p_data->>'id',6)) end,
        coalesce(nullif(trim(p_data->>'title'),''),'Untitled matter'),trim(p_data->>'subtitle'),p_data->>'category',p_data->>'body',
        coalesce(nullif(trim(p_data->>'author'),''),v_post.author,nullif(p_user->>'name',''),'Contributor'),coalesce(v_post.access_id,v_actor),
        coalesce(v_post.published_at,case when p_data->>'action'='publish' then now() end),
        case when p_data->>'action'='publish' or v_post.status='published' then 'published' else 'draft' end,
        v_number,p_data->'tags',p_data->>'cover',p_data->>'caption',p_data->>'imageAlt',p_data->>'imageMode',p_data->>'references',p_data->>'seoDescription',p_data->>'visibility',p_data->>'excerpt',case when p_data ? 'publicationDate' then v_date else v_post.display_date end)
      on conflict(id) do update set slug=excluded.slug,title=excluded.title,subtitle=excluded.subtitle,category=excluded.category,body=excluded.body,author=excluded.author,
        updated_at=now(),display_date=excluded.display_date,published_at=excluded.published_at,status=excluded.status,matter_number=excluded.matter_number,tags=excluded.tags,
        cover=excluded.cover,caption=excluded.caption,image_alt=excluded.image_alt,image_mode=excluded.image_mode,references_text=excluded.references_text,
        seo_description=excluded.seo_description,visibility=excluded.visibility,excerpt=excluded.excerpt returning * into v_post;
    return jsonb_build_object('row',to_jsonb(v_post));
  elsif p_op='delete' then
    if v_actor is null then return '{"_status":401,"error":"Invitation required."}'; end if;
    if not v_admin then return '{"_status":403,"error":"Only Pearling can delete a matter."}'; end if;
    perform pg_advisory_xact_lock(hashtextextended(p_data->>'id',0));
    select * into v_post from public.pm_posts where id=(p_data->>'id')::uuid for update;
    if v_post.id is null then return '{"_status":404,"error":"This matter does not exist."}'; end if;
    delete from public.pm_posts where id=v_post.id;
    return '{"ok":true}';
  elsif p_op='settings' then
    select value into v_url from public.pm_settings where key='payment_url';
    v_result:=jsonb_build_object('paymentUrl',v_url);
    if v_admin then v_result:=v_result||jsonb_build_object('profiles',(select coalesce(jsonb_object_agg(access_id,name),'{}') from public.pm_profiles)); end if;
    return v_result;
  elsif p_op='settings_save' then
    if not v_admin then return '{"_status":403,"error":"Curator access required."}'; end if;
    if p_data ? 'paymentUrl' then
      insert into public.pm_settings values('payment_url',p_data->>'paymentUrl') on conflict(key) do update set value=excluded.value;
    end if;
    if p_data ? 'contributor' then
      if p_data->'contributor'->>'id'='contributor-1' then return '{"_status":400,"error":"This assignment cannot be changed."}'; end if;
      insert into public.pm_profiles values(p_data->'contributor'->>'id',nullif(trim(p_data->'contributor'->>'name'),'')) on conflict(access_id) do update set name=excluded.name;
    end if;
    return '{"ok":true}';
  elsif p_op='media_add' then
    if v_actor is null then return '{"_status":401,"error":"Invitation required."}'; end if;
    insert into public.pm_media(id,owner_id,content_type,size) values((p_data->>'id')::uuid,v_actor,p_data->>'contentType',(p_data->>'size')::integer);
    return '{"ok":true}';
  elsif p_op='media' then
    select * into v_media from public.pm_media where id=(p_data->>'id')::uuid;
    if v_media.id is null then return '{"_status":404,"error":"This media does not exist."}'; end if;
    v_url:='/api/media/'||v_media.id::text;
    if not(v_admin or coalesce(v_media.owner_id=v_actor,false)) and not exists (
      select 1 from public.pm_posts where status='published' and (
        ((v_reader or visibility='public') and (cover=v_url or strpos(body,v_url)>0 or strpos(references_text,v_url)>0)) or
        (visibility='excerpt' and (cover=v_url or strpos(excerpt,v_url)>0))
      )
    ) then return '{"_status":401,"error":"Reader access required."}'; end if;
    return jsonb_build_object('id',v_media.id,'size',v_media.size,'contentType',v_media.content_type);
  end if;
  return '{"_status":404,"error":"Not found."}';
end $$;
revoke all on function public.pm_api(text,jsonb,jsonb) from public,anon,authenticated;
grant execute on function public.pm_api(text,jsonb,jsonb) to service_role;
