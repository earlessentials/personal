-- PRIVATE MATTER has no public database API. Only the Edge Function's service
-- role can call pm_api; readers and contributors use revocable opaque sessions.
create table public.pm_sessions (
  token_hash text primary key check (token_hash ~ '^[a-f0-9]{64}$'),
  access_id text not null,
  scope text not null check (scope in ('reader','contributor')),
  expires_at timestamptz not null
);
create index pm_sessions_expiry on public.pm_sessions(expires_at);
create table public.pm_attempts (key text primary key, hits integer not null, expires_at timestamptz not null);
create table public.pm_profiles (access_id text primary key, name text);
create table public.pm_settings (key text primary key, value text not null);
create table public.pm_posts (
  id uuid primary key, slug text unique not null, title text not null,
  subtitle text not null default '', category text not null default '', body text not null default '',
  author text not null, access_id text not null,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now(), published_at timestamptz,
  status text not null check (status in ('draft','published','archived')),
  matter_number bigint unique,
  tags jsonb not null default '[]', cover text not null default '', caption text not null default '',
  image_alt text not null default '', image_mode text not null default 'wide',
  references_text text not null default '', seo_description text not null default '',
  visibility text not null default 'private' check (visibility in ('private','excerpt','public')),
  excerpt text not null default ''
);
create sequence public.pm_matter_number;
create table public.pm_media (
  id uuid primary key, owner_id text not null, content_type text not null,
  size integer not null check(size > 0 and size <= 26214400),
  created_at timestamptz not null default now()
);
create index pm_posts_published on public.pm_posts(status, matter_number);
alter table public.pm_sessions enable row level security;
alter table public.pm_attempts enable row level security;
alter table public.pm_profiles enable row level security;
alter table public.pm_settings enable row level security;
alter table public.pm_posts enable row level security;
alter table public.pm_media enable row level security;
revoke all on public.pm_sessions,public.pm_attempts,public.pm_profiles,public.pm_settings,public.pm_posts,public.pm_media from public,anon,authenticated;
revoke all on sequence public.pm_matter_number from public,anon,authenticated;
grant all on public.pm_sessions,public.pm_attempts,public.pm_profiles,public.pm_settings,public.pm_posts,public.pm_media to service_role;
grant usage,select on sequence public.pm_matter_number to service_role;

create function public.pm_api(p_op text, p_data jsonb default '{}', p_user jsonb default '{}')
returns jsonb language plpgsql security invoker set search_path = '' as $$
declare
  v_reader boolean := coalesce((p_user->>'reader')::boolean,false);
  v_admin boolean := coalesce((p_user->>'admin')::boolean,false);
  v_actor text := p_user->>'contributorId';
  v_post public.pm_posts;
  v_media public.pm_media;
  v_result jsonb;
  v_next jsonb;
  v_key text;
  v_count integer;
  v_number bigint;
  v_url text;
  v_media_id text;
begin
  if p_op='session' then
    select jsonb_build_object('accessId',s.access_id,'name',p.name,'hasProfile',p.access_id is not null)
      into v_result from public.pm_sessions s left join public.pm_profiles p on p.access_id=s.access_id
      where s.token_hash=p_data->>'hash' and s.scope=p_data->>'scope' and s.expires_at>now();
    return coalesce(v_result,'null'::jsonb);
  elsif p_op='rate' then
    delete from public.pm_attempts where expires_at<now();
    delete from public.pm_sessions where expires_at<now();
    -- A global cap remains effective even if an attacker forges proxy headers.
    foreach v_key in array array['global:'||(floor(extract(epoch from now())/900))::text,
      'client:'||(p_data->>'key')||':'||(floor(extract(epoch from now())/900))::text] loop
      insert into public.pm_attempts values(v_key,1,now()+interval '30 minutes')
        on conflict(key) do update set hits=pm_attempts.hits+1 returning hits into v_count;
      if v_count > (case when v_key like 'global:%' then 200 else 20 end) then
        return jsonb_build_object('allowed',false);
      end if;
    end loop;
    return jsonb_build_object('allowed',true);
  elsif p_op='login' then
    for v_result in select value from jsonb_array_elements(p_data->'sessions') loop
      insert into public.pm_sessions values(v_result->>'hash',p_data->>'accessId',v_result->>'scope',now()+interval '7 days');
    end loop;
    return '{"ok":true}';
  elsif p_op='logout' then
    delete from public.pm_sessions where token_hash in (select jsonb_array_elements_text(p_data->'hashes'));
    return '{"ok":true}';
  elsif p_op='stories' then
    if not coalesce((p_data->>'publicOnly')::boolean,false) and not(v_reader or v_admin) then
      return '{"_status":401,"error":"Your reading session has closed."}';
    end if;
    select coalesce(jsonb_agg(to_jsonb(p) order by matter_number desc),'[]') into v_result
      from public.pm_posts p where status='published'
      and (not (p_data->>'publicOnly')::boolean or visibility='public')
      and (coalesce(p_data->>'q','')='' or strpos(lower(title||' '||subtitle||' '||body||' '||author||' '||category||' '||tags::text),lower(p_data->>'q'))>0)
      and (coalesce(p_data->>'subject','')='' or tags ? (p_data->>'subject'));
    return jsonb_build_object('rows',v_result);
  elsif p_op='story' then
    select * into v_post from public.pm_posts where status in ('draft','published') and
      (id::text=p_data->>'id' or slug=p_data->>'id' or matter_number::text=ltrim(p_data->>'id','0')) limit 1;
    if v_post.id is null or (v_post.status<>'published' and not(v_admin or coalesce(v_actor=v_post.access_id,false))) then
      return '{"_status":404,"error":"This matter does not exist."}';
    end if;
    if not(v_reader or v_admin or coalesce(v_actor=v_post.access_id,false) or v_post.visibility='public') then
      if v_post.visibility='private' then return '{"_status":401,"error":"Your reading session has closed."}'; end if;
      return jsonb_build_object('row',to_jsonb(v_post),'locked',true,'next',null);
    end if;
    select jsonb_build_object('number',matter_number,'slug',slug) into v_next from public.pm_posts
      where status='published' and matter_number>v_post.matter_number and (v_reader or v_admin or visibility='public') order by matter_number limit 1;
    return jsonb_build_object('row',to_jsonb(v_post),'locked',false,'next',v_next);
  elsif p_op='studio' then
    if v_actor is null then return '{"_status":401,"error":"Invitation required."}'; end if;
    select coalesce(jsonb_agg(to_jsonb(p) order by updated_at desc),'[]') into v_result from public.pm_posts p
      where status in ('draft','published') and (v_admin or access_id=v_actor);
    return jsonb_build_object('rows',v_result);
  elsif p_op='save' then
    if v_actor is null then return '{"_status":401,"error":"Invitation required."}'; end if;
    -- Serialize edits to the same UUID, including simultaneous first publishes.
    perform pg_advisory_xact_lock(hashtextextended(p_data->>'id',0));
    select * into v_post from public.pm_posts where id=(p_data->>'id')::uuid for update;
    if v_post.id is not null and not(v_admin or v_post.access_id=v_actor) then
      return '{"_status":403,"error":"This matter is not yours to edit."}';
    end if;
    if v_post.status='published' and p_data->>'action'='draft' and v_post.visibility<>p_data->>'visibility' then
      return '{"_status":400,"error":"Use Publish revision to confirm a change to who can read this matter."}';
    end if;
    for v_media_id in select jsonb_array_elements_text(p_data->'mediaIds') loop
      select * into v_media from public.pm_media where id=v_media_id::uuid;
      if v_media.id is null then return '{"_status":400,"error":"An uploaded image or video is unavailable. Please upload it again."}'; end if;
      if not(v_admin or v_media.owner_id=v_actor) then return '{"_status":403,"error":"Use images and videos uploaded with your own contributor code."}'; end if;
    end loop;
    v_number:=v_post.matter_number;
    if v_number is null and p_data->>'action'='publish' then v_number:=nextval('public.pm_matter_number'); end if;
    insert into public.pm_posts(id,slug,title,subtitle,category,body,author,access_id,published_at,status,matter_number,tags,cover,caption,image_alt,image_mode,references_text,seo_description,visibility,excerpt)
      values((p_data->>'id')::uuid,
        case when v_post.matter_number is not null then v_post.slug else (p_data->>'slugBase')||'-'||coalesce(v_number::text,left(p_data->>'id',6)) end,
        coalesce(nullif(trim(p_data->>'title'),''),'Untitled matter'),trim(p_data->>'subtitle'),p_data->>'category',p_data->>'body',
        coalesce(v_post.author,nullif(p_user->>'name',''),'Contributor'),coalesce(v_post.access_id,v_actor),
        coalesce(v_post.published_at,case when p_data->>'action'='publish' then now() end),
        case when p_data->>'action'='publish' or v_post.status='published' then 'published' else 'draft' end,
        v_number,p_data->'tags',p_data->>'cover',p_data->>'caption',p_data->>'imageAlt',p_data->>'imageMode',p_data->>'references',p_data->>'seoDescription',p_data->>'visibility',p_data->>'excerpt')
      on conflict(id) do update set slug=excluded.slug,title=excluded.title,subtitle=excluded.subtitle,category=excluded.category,body=excluded.body,
        updated_at=now(),published_at=excluded.published_at,status=excluded.status,matter_number=excluded.matter_number,tags=excluded.tags,
        cover=excluded.cover,caption=excluded.caption,image_alt=excluded.image_alt,image_mode=excluded.image_mode,references_text=excluded.references_text,
        seo_description=excluded.seo_description,visibility=excluded.visibility,excerpt=excluded.excerpt returning * into v_post;
    return jsonb_build_object('row',to_jsonb(v_post));
  elsif p_op='delete' then
    if v_actor is null then return '{"_status":401,"error":"Invitation required."}'; end if;
    select * into v_post from public.pm_posts where id=(p_data->>'id')::uuid for update;
    if v_post.id is null then return '{"_status":404,"error":"This matter does not exist."}'; end if;
    if not(v_admin or v_post.access_id=v_actor) then return '{"_status":403,"error":"This matter is not yours to edit."}'; end if;
    if v_post.status<>'draft' then return '{"_status":400,"error":"Only drafts can be deleted here."}'; end if;
    delete from public.pm_posts where id=v_post.id;
    return '{"ok":true}';
  elsif p_op='settings' then
    select value into v_url from public.pm_settings where key='payment_url';
    v_result:=jsonb_build_object('paymentUrl',v_url);
    if v_admin then v_result:=v_result||jsonb_build_object('profiles',(select coalesce(jsonb_object_agg(access_id,name),'{}') from public.pm_profiles)); end if;
    return v_result;
  elsif p_op='settings_save' then
    if not v_admin then return '{"_status":403,"error":"Curator access required."}'; end if;
    if p_data ? 'paymentUrl' then
      insert into public.pm_settings values('payment_url',p_data->>'paymentUrl') on conflict(key) do update set value=excluded.value;
    end if;
    if p_data ? 'contributor' then
      if p_data->'contributor'->>'id'='contributor-1' then return '{"_status":400,"error":"This assignment cannot be changed."}'; end if;
      insert into public.pm_profiles values(p_data->'contributor'->>'id',nullif(trim(p_data->'contributor'->>'name'),'')) on conflict(access_id) do update set name=excluded.name;
    end if;
    return '{"ok":true}';
  elsif p_op='media_add' then
    if v_actor is null then return '{"_status":401,"error":"Invitation required."}'; end if;
    insert into public.pm_media(id,owner_id,content_type,size) values((p_data->>'id')::uuid,v_actor,p_data->>'contentType',(p_data->>'size')::integer);
    return '{"ok":true}';
  elsif p_op='media' then
    select * into v_media from public.pm_media where id=(p_data->>'id')::uuid;
    if v_media.id is null then return '{"_status":404,"error":"This media does not exist."}'; end if;
    v_url:='/api/media/'||v_media.id::text;
    if not(v_admin or coalesce(v_media.owner_id=v_actor,false)) and not exists (
      select 1 from public.pm_posts where status='published' and (
        ((v_reader or visibility='public') and (cover=v_url or strpos(body,v_url)>0 or strpos(references_text,v_url)>0)) or
        (visibility='excerpt' and (cover=v_url or strpos(excerpt,v_url)>0))
      )
    ) then return '{"_status":401,"error":"Reader access required."}'; end if;
    return jsonb_build_object('id',v_media.id,'size',v_media.size,'contentType',v_media.content_type);
  end if;
  return '{"_status":404,"error":"Not found."}';
end $$;
revoke all on function public.pm_api(text,jsonb,jsonb) from public,anon,authenticated;
grant execute on function public.pm_api(text,jsonb,jsonb) to service_role;
