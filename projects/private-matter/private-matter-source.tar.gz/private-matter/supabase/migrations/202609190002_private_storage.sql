-- No browser role receives an object policy. Uploads and time-limited downloads
-- are issued only after the Edge Function checks publication permissions.
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values('private-matter','private-matter',false,26214400,
  array['image/jpeg','image/png','image/webp','video/mp4','video/webm']);
