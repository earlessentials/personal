# PRIVATE MATTER backend

Deployed to the owner’s Free project `cdyzpgvamzeweiwyfzcm` on 24 September 2026.
All three migrations and server secrets are applied; `private-matter` uses custom
code/session authentication (`verify_jwt = false`).
The website remains at `pearlinglim.com/privatematter/` on GitHub Pages.
This service replaces the original hosted backend without redirecting readers.

## Deployment

1. Connect the owner's Supabase account and select a **Free** project. Do not
   activate paid services. Confirm the project belongs to the owner.
2. Apply all three timestamped migrations in order. Apply `dashboard-hardening.sql` if the
   dashboard created its automatic-RLS helper. They create an empty publication, six private
   tables, a service-role-only transactional function, and a private media bucket.
3. Set `FOLIO_CODES_JSON` and `FOLIO_PAYMENT_URL` as Edge Function secrets using
   the existing local secret configuration. Preserve all 15 existing entries.
   Never commit values, code hashes or service keys. No seed articles are added.
4. Deploy `functions/private-matter/index.ts` with `verify_jwt = false` as set in
   `config.toml`. This function uses its own code/session authentication;
   disabling the Supabase JWT check does not remove its internal access checks.
5. Verify live role boundaries, failed logins, revocation, public/private/excerpt
   reads, contributor ownership, image/video upload and signed media downloads.
   Test storage byte-range responses with a real uploaded video.
6. Build the frontend with `PRIVATE_MATTER_API_URL` set to the deployed function
   endpoint. Replace only `public/privatematter/` in `earlessentials/personal`.
   Keep the main site, GitHub workflow and domain configuration unchanged.
7. Check the real website and direct article links after GitHub Pages deploys.

## Access and media

Code hashes stay in the server secret, with exactly ten reader identities and
five contributors. The existing Pearling identity opens both gates. Sessions are
random 256-bit tokens; only their hashes are stored in PostgreSQL. Session
tokens expire after seven days and can be revoked. Browser tokens are limited
to the current tab. Successful sign-in never stores the submitted code.

No browser role can query tables or call the database function directly. The
Edge Function checks sessions, then makes service-role calls. It restricts
browser origins to the apex and www versions of the owner's domain. Code
attempts have per-client and global limits; the global limit also protects
against forged client headers.

Uploads are private by default. The service checks contributor ownership before
attaching an uploaded file to a matter. It checks article visibility before
issuing a URL for one object, valid for fifteen minutes. A URL already issued
remains usable until it expires even after logout or an audience change.
Uploaded videos are limited to 25 MiB; YouTube embeds remain available.
YouTube's own visibility and embedding settings still apply to those videos.

## Local verification

`tests/private-matter-backend.test.mjs` runs the actual migration and handler on
PostgreSQL via PGlite, with temporary storage doubles and test-only codes. The
test database exists only in memory and never contacts a hosted project.

From the repository root:

```sh
npm --prefix tests ci
npm run test:backend
```

These tests verify database grants/RLS, both code roles, admin dual access,
public/private/excerpt/draft visibility, edits and numbering, uploaded media
authorization, validation, CORS, session expiry/revocation and brute-force
limits. Hosted integration was verified with 115 checks on 24 September 2026,
including all original codes and Storage byte ranges. Temporary verification
records and uploads were removed. Supabase Free project limits and inactivity
pausing still apply; code distribution and payment collection remain external.

## Writer names, publication dates and deletion

The 20260926021733 migration adds editable per-matter bylines and restricts
deletion to the server-verified administrator. A byline is display text and never
changes article ownership. Both the HTTP handler and database function reject
nonadmin deletion. Published and draft matters can be deleted by the admin.
`publishedAt` is assigned on first publication and preserved by every revision;
the frontend formats dates in Asia/Jakarta. Ten local PostgreSQL test groups
and 47 targeted live checks passed on 27 September 2026. Temporary test matters
were deleted and their test sessions revoked.

## Country-based checkout

Deploy all four files in `functions/private-matter/`, including the bundled
country index. `settings.checkout` returns the suggested region and both public
checkout URLs. The service resolves the gateway-provided client IP against
DB-IP country ranges without storing it or forwarding it to another provider.
The Indonesia URL uses the existing `payment_url` setting (set to the owner's
HTTPS Lynk checkout); the international URL is configured in `index.ts`.
Unknown/private/invalid addresses return no suggestion. The frontend always
allows an explicit country choice. See `COUNTRY-DATA.md` for the data license.
