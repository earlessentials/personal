# Checkout country data

Country suggestions use DB-IP IP to Country Lite, September 2026, licensed
under Creative Commons Attribution 4.0 International.

- Source: https://db-ip.com/db/download/ip-to-country-lite
- License: https://creativecommons.org/licenses/by/4.0/
- Download: https://download.db-ip.com/free/dbip-country-lite-2026-09.csv.gz

The derived `country-data.mjs` retains only Indonesian and unknown address
ranges and merges adjacent ranges. The checkout displays a DB-IP attribution
link as required by the source. Country lookup runs inside the existing service;
the application does not store IPs or send them to a geolocation provider.

IP location is approximate and reflects a VPN or proxy when used. Both checkout
choices remain available, and unknown locations keep the international checkout available.
Reader/contributor permissions never depend on location. The original data is
updated monthly; refresh the bundled snapshot with `scripts/build-country-data.py`
when maintaining the publication. The script records the source hash and release.
