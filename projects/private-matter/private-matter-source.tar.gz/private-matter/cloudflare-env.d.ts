declare namespace Cloudflare {
  interface Env {
    DB?: D1Database;
    FOLIO_CODES_JSON?: string;
    FOLIO_PAYMENT_URL?: string;
    BUCKET?: R2Bucket;
  }
}
