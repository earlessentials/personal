import {sitePath} from '@/lib/paths';
import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "PRIVATE MATTER — A private publication",
  description: "A private publication for ideas worth sitting with. Independently curated by Pearling Lim.",
  icons: {
    icon: sitePath("/favicon.svg"),
    shortcut: sitePath("/favicon.svg"),
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
