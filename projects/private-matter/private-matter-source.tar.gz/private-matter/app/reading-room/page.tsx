'use client';
import {sitePath} from '@/lib/paths';
import {useEffect,useState} from 'react';
import Link from '@/components/publication-link';
import {ArrowRight,ArrowUpRight} from 'lucide-react';
import {Header,Footer,Loading,Closed,Story,api,number,matterUrl} from '../publication';
export default function Room(){
  const[stories,setStories]=useState<Story[]|null>(null);
  const[error,setError]=useState('');
  useEffect(()=>{api('/api/stories').then(d=>setStories(d.stories)).catch(e=>setError(e.status===401?'closed':e.message))},[]);
  const featured=stories?.[0];
  return <><Header/><main className="room wrap">
    {error==='closed'?<Closed/>:error?<div className="quiet-state" role="alert">{error}</div>:!stories?<Loading/>:<>
      <div className="room-heading"><p className="eyebrow">PRIVATE MATTER / THE READING ROOM</p><h1>A little room<br/><em>for the words.</em></h1><p>A private publication.<br/>Read at your own pace.</p></div>
      {featured?<>
        <section className={'featured-matter '+(!featured.cover?'type-only':'')}><div className="featured-writing"><p className="eyebrow">THE LATEST MATTER<span>NO. {number(featured.number)}</span></p><Link href={matterUrl(featured)}><h2>{featured.title}</h2></Link><p className="deck">{featured.subtitle}</p><div className="matter-meta"><span>BY {featured.author}</span><span>{featured.minutes} MIN READ</span></div><Link className="text-link" href={matterUrl(featured)}>Read matter<ArrowUpRight size={19}/></Link></div>{featured.cover&&<Link className="room-image" href={matterUrl(featured)}><img src={sitePath(featured.cover)} alt={featured.imageAlt||featured.title}/><span>MATTER {number(featured.number)}</span></Link>}</section>
        {stories.length>1&&<section className="recent"><p className="eyebrow">RECENTLY PUBLISHED</p>{stories.slice(1,5).map(s=><Link href={matterUrl(s)} className="matter-row" key={s.id}><span className="matter-no">{number(s.number)}</span><div><span className="eyebrow">BY {s.author}</span><h3>{s.title}</h3><p>{s.subtitle}</p></div><span className="row-time">{s.minutes} MIN</span><ArrowUpRight size={23}/></Link>)}</section>}
        <div className="room-closing"><p>Published privately.<br/><em>Read deliberately.</em></p><Link className="text-link" href="/archive">Enter the archive<ArrowRight size={20}/></Link></div>
      </>:<section className="unwritten" aria-label="Empty publication"><div className="unwritten-margin"><span className="eyebrow">THE FIRST PAGE</span><span className="unwritten-mark" aria-hidden="true">pm.</span></div><div className="unwritten-copy"><h2>To be<br/><em>written.</em></h2><p>No matters have been published yet.<br/>The first words will appear here.</p></div><div className="unwritten-colophon"><span>CURATED BY PEARLING LIM</span><span>PUBLISHED PRIVATELY.</span></div></section>}
    </>}
  </main><Footer/></>;
}
