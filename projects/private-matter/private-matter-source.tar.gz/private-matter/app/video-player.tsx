'use client';
import {sitePath} from '@/lib/paths';
import {useState} from 'react';
import {videoSource} from '@/lib/video';
export function VideoPlayer({url,caption}:{url:string;caption?:string}){
  const source=videoSource(url);const[failed,setFailed]=useState(false);
  if(!source)return null;
  return <figure className="publication-video"><div className="video-frame">{source.kind==='youtube'?<iframe src={source.embed} title={caption||'YouTube video'} loading="lazy" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerPolicy="strict-origin-when-cross-origin" allowFullScreen/>:<video src={sitePath(source.url)} controls playsInline preload="metadata" aria-label={caption||'Publication video'} onError={()=>setFailed(true)} />}</div><figcaption>{caption&&caption!=='Watch video'&&<span>{caption}</span>}{source.kind==='youtube'?<a href={sitePath(source.url)} target="_blank" rel="noopener noreferrer">Watch on YouTube ↗</a>:failed&&<span>This video could not play. <a href={sitePath(source.url)} target="_blank" rel="noopener noreferrer">Open video ↗</a></span>}</figcaption></figure>;
}
