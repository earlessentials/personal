'use client';
import {useEffect,useRef,useState} from 'react';
import {videoSource} from '@/lib/video';
import {usePublicationMedia} from './publication-media';
export function VideoPlayer({url,caption}:{url:string;caption?:string}){
  const source=videoSource(url);
  const[failed,setFailed]=useState(false);
  const resume=useRef({time:0,playing:false});
  const videoRef=useRef<HTMLVideoElement|null>(null);
  const media=usePublicationMedia(source?.kind==='upload'?source.url:'');
  useEffect(()=>{resume.current={time:0,playing:false};setFailed(false)},[url]);
  if(!source)return null;
  const recover=(automatic:boolean)=>{
    const video=videoRef.current;
    if(video&&Number.isFinite(video.currentTime)&&video.currentTime>0)resume.current.time=video.currentTime;
    if(media.retry(automatic)){setFailed(false);return true}
    setFailed(true);return false;
  };
  return <figure className="publication-video"><div className="video-frame">{source.kind==='youtube'?<iframe key={source.id} src={source.embed} title={caption||'YouTube video'} loading="lazy" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerPolicy="strict-origin-when-cross-origin" allowFullScreen/>:<><video ref={videoRef} src={media.url} controls playsInline preload="metadata" aria-label={caption||'Publication video'} onLoadedMetadata={event=>{
    const video=event.currentTarget;
    if(resume.current.time&&Number.isFinite(video.duration))video.currentTime=Math.min(resume.current.time,Math.max(0,video.duration-.1));
    setFailed(false);
    if(resume.current.playing)video.play().catch(()=>{});
  }} onPlay={()=>{resume.current.playing=true;if(media.expiresAt&&Date.now()>=media.expiresAt-2000)recover(false)}} onPause={event=>{if(!event.currentTarget.error&&event.currentTarget.readyState>0)resume.current.playing=false}} onTimeUpdate={event=>{if(event.currentTarget.currentTime>0)resume.current.time=event.currentTarget.currentTime}} onEnded={()=>{resume.current={time:0,playing:false}}} onError={()=>recover(true)}/>{media.loading&&<span className="video-loading" role="status">Loading video…</span>}</>}</div><figcaption>{caption&&caption!=='Watch video'&&<span>{caption}</span>}{source.kind==='youtube'?<a href={source.url} target="_blank" rel="noopener noreferrer">Watch on YouTube ↗</a>:(failed||media.failed)&&<span role="status">This video could not play. <button type="button" onClick={()=>recover(false)}>Retry video</button>{media.url&&<> · <a href={media.url} target="_blank" rel="noopener noreferrer">Open video ↗</a></>}</span>}</figcaption></figure>;
}
