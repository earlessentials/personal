'use client';
import {useCallback,useEffect,useRef,useState,type ImgHTMLAttributes} from 'react';
import {publicationApi,publicationApiUrl} from '@/lib/publication-api';
import {sitePath} from '@/lib/paths';

// Canonical /api/media IDs remain in saved articles. A session is checked before
// resolving a private object to a short-lived URL; tokens never appear in URLs.
export function usePublicationMedia(source:string){
  const remote=!!publicationApiUrl&&/^\/api\/media\/[a-f0-9-]{36}$/.test(source);
  const [result,setResult]=useState<{source:string;url?:string;failed?:boolean}>({source:''});
  const [revision,setRevision]=useState(0);
  const lastRetry=useRef(0);
  useEffect(()=>{
    if(!remote)return;
    let active=true;
    const resolve=()=>{
      setResult({source});
      publicationApi(source+'/url').then(data=>{
        const url=new URL(data.url),backend=new URL(publicationApiUrl);
        if(url.origin!==backend.origin||!url.pathname.startsWith('/storage/v1/object/sign/private-matter/'))throw Error('Invalid media address.');
        if(active)setResult({source,url:url.href});
      }).catch(()=>{if(active)setResult({source,failed:true});});
    };
    resolve();window.addEventListener('folio-session',resolve);
    return()=>{active=false;window.removeEventListener('folio-session',resolve);};
  },[source,remote,revision]);
  const retry=useCallback(()=>{
    if(remote&&Date.now()-lastRetry.current>60000){lastRetry.current=Date.now();setRevision(v=>v+1);return true;}
    return false;
  },[remote]);
  return {url:remote?(result.source===source?result.url:undefined):sitePath(source),failed:remote&&result.source===source&&result.failed,retry};
}

export function PublicationImage({src,...props}:Omit<ImgHTMLAttributes<HTMLImageElement>,'src'>&{src:string}){
  const media=usePublicationMedia(src);
  return <img {...props} src={media.url} referrerPolicy="no-referrer" onError={event=>{media.retry();props.onError?.(event)}}/>;
}
