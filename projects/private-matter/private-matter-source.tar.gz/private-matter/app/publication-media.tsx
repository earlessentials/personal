'use client';
import {useCallback,useEffect,useRef,useState,type ImgHTMLAttributes} from 'react';
import {publicationApi,publicationApiUrl} from '@/lib/publication-api';
import {sitePath} from '@/lib/paths';

// Saved articles retain stable media IDs, never expiring URLs or session tokens.
export function usePublicationMedia(source:string){
  const remote=!!publicationApiUrl&&/^\/api\/media\/[a-f0-9-]{36}$/.test(source);
  const [result,setResult]=useState<{source:string;url?:string;failed?:boolean;expiresAt?:number}>({source:''});
  const [revision,setRevision]=useState(0);
  const lastRetry=useRef({source:'',at:0});
  useEffect(()=>{
    if(!remote)return;
    let active=true,requestId=0;
    const resolve=()=>{
      const id=++requestId;
      setResult({source});
      publicationApi(source+'/url').then(data=>{
        const url=new URL(data.url),backend=new URL(publicationApiUrl);
        if(url.origin!==backend.origin||!url.pathname.startsWith('/storage/v1/object/sign/private-matter/'))throw Error('Invalid media address.');
        if(active&&id===requestId)setResult({source,url:url.href,expiresAt:Date.now()+Math.max(1,Number(data.expiresIn)||900)*1000});
      }).catch(()=>{if(active&&id===requestId)setResult({source,failed:true});});
    };
    resolve();window.addEventListener('folio-session',resolve);
    return()=>{active=false;window.removeEventListener('folio-session',resolve);};
  },[source,remote,revision]);
  const retry=useCallback((automatic=false)=>{
    if(automatic&&(!remote||(lastRetry.current.source===source&&Date.now()-lastRetry.current.at<60000)))return false;
    lastRetry.current={source,at:Date.now()};setRevision(v=>v+1);return true;
  },[source,remote]);
  const current=result.source===source?result:undefined;
  return {url:remote?current?.url:source?sitePath(source):undefined,failed:!!(remote&&current?.failed),loading:remote&&!current?.url&&!current?.failed,expiresAt:current?.expiresAt,revision,retry};
}

export function PublicationImage({src,alt='',...props}:Omit<ImgHTMLAttributes<HTMLImageElement>,'src'>&{src:string}){
  const media=usePublicationMedia(src);
  const [broken,setBroken]=useState('');
  const identity=src+':'+media.revision;
  if(media.failed||broken===identity)return <span className="publication-media-status" role="status"><span>{alt||'Image'} could not load.</span><button type="button" onClick={()=>{setBroken('');media.retry()}}>Retry image</button></span>;
  if(media.loading)return <span className="publication-media-status" role="status">Loading image…</span>;
  return <img {...props} key={identity} alt={alt} src={media.url} decoding="async" referrerPolicy="no-referrer" onError={event=>{if(!media.retry(true))setBroken(identity);props.onError?.(event)}}/>;
}
