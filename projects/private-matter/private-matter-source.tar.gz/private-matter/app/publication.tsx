'use client';
import {basePath,sitePath} from '@/lib/paths';
import {publicationApi} from '@/lib/publication-api';
import {useEffect,useState} from 'react';
import Link from '@/components/publication-link';
import {useRouter} from 'next/navigation';
import {ArrowUpRight,ArrowRight} from 'lucide-react';
import {InputOTP,InputOTPGroup,InputOTPSlot} from '@/components/ui/input-otp';
import {Button} from '@/components/ui/button';
export type Member={name:string|null;role:'reader'|'contributor';admin?:boolean};
export type Session={reader:Member|null;contributor:Member|null;admin:boolean};
export type Story={id:string;slug:string;title:string;subtitle:string;category:string;author:string;createdAt:string;publishedAt?:string|null;publicationDate?:string;updatedAt?:string;number:number;minutes:number;body?:string;cover?:string;caption?:string;imageAlt?:string;imageMode?:string;locked?:boolean;tags:string[];references?:string;excerpt?:string;status?:string;visibility?:string;seoDescription?:string};
export const number=(n:number)=>String(n).padStart(3,'0');
export const matterUrl=(s:{number:number;slug:string})=>process.env.NEXT_PUBLIC_GITHUB_APP?'/read/?id='+encodeURIComponent(s.number||s.slug):'/matter/'+number(s.number)+'/'+s.slug;
export const api=publicationApi;
export function PublicationDate({date}:{date:string}){return <time dateTime={date}>{new Date(date).toLocaleDateString('en-GB',{day:'numeric',month:'long',year:'numeric',timeZone:'Asia/Jakarta'})}</time>}
export function useSession(){const[session,setSession]=useState<Session>({reader:null,contributor:null,admin:false});const[ready,setReady]=useState(false);useEffect(()=>{const refresh=()=>api('/api/session').then(setSession).catch(()=>{}).finally(()=>setReady(true));refresh();window.addEventListener('folio-session',refresh);return()=>window.removeEventListener('folio-session',refresh)},[]);return{...session,ready};}
export function Brand(){return <Link href="/" className="brand">PRIVATE MATTER<span>AN INDEPENDENT PUBLICATION</span></Link>}
export function Header(){const session=useSession();return <header className="site-header wrap"><Brand/><nav aria-label="Primary navigation"><Link href="/publications">Publications</Link>{session.reader?<><Link href="/reading-room">Reading room</Link><Link href="/archive">Archive</Link></>:<Link href="/about">About</Link>}<Link href="/access">{session.reader?'Reader access':'Enter the edition'}<ArrowUpRight size={14}/></Link></nav></header>}
export function Footer(){const s=useSession();const[error,setError]=useState('');async function leave(){try{await api('/api/session?scope=reader',{method:'DELETE'});window.dispatchEvent(new Event('folio-session'));window.location.href=sitePath('/')}catch{setError('Unable to leave. Please try again.')}}return <footer className="site-footer wrap"><div><Link className="footer-brand" href="/">PRIVATE MATTER</Link><p>Curated independently by Pearling Lim.</p></div><nav aria-label="Footer navigation"><Link href="/publications">Publications</Link><Link href="/archive">Archive</Link><Link href="/about">About</Link><Link href="/access">Reader access</Link><Link href="/contributor-access">Contributor entrance</Link>{s.reader&&<button onClick={leave}>Leave reading room</button>}</nav><span className="copyright">© 2026</span>{error&&<p role="alert">{error}</p>}</footer>}
type CheckoutRegion='indonesia'|'international';
const checkoutFallback={indonesiaUrl:'https://lynk.id/pearling/xemxp2kpjool/checkout',internationalUrl:'https://heypearling.gumroad.com/l/privatematter'};
export function PaymentLink(){
  const[links,setLinks]=useState(checkoutFallback);
  const[detected,setDetected]=useState<CheckoutRegion|null>(null);
  const[choice,setChoice]=useState<CheckoutRegion|null>(null);
  
  useEffect(()=>{let active=true;api('/api/settings').then(d=>{
    if(!active)return;
    const checkout=d.checkout;
    if(checkout){
      setLinks({indonesiaUrl:checkout.indonesiaUrl||checkoutFallback.indonesiaUrl,internationalUrl:checkout.internationalUrl||checkoutFallback.internationalUrl});
      setDetected(checkout.region==='indonesia'||checkout.region==='international'?checkout.region:null);
    }
  }).catch(()=>{});return()=>{active=false}},[]);
  const region=choice||detected;
  const url=region==='indonesia'?links.indonesiaUrl:links.internationalUrl;
  return <div className="checkout-options">
    <div className="checkout-regions" role="group" aria-label="Checkout region">
      <button type="button" aria-pressed={region==='indonesia'} onClick={()=>setChoice('indonesia')}>Indonesia</button>
      <button type="button" aria-pressed={region==='international'} onClick={()=>setChoice('international')}>International</button>
    </div>
    <a className="text-link" href={url} target="_blank" rel="noopener noreferrer">Acquire access<ArrowUpRight size={15}/></a>
  </div>
}
export function Loading(){return <div className="quiet-state" role="status"><p className="eyebrow">PRIVATE MATTER</p><span className="loading-dot">·</span></div>}
export function Closed({contributor=false}:{contributor?:boolean}){return <div className="quiet-state"><p className="eyebrow">{contributor?'INVITATION REQUIRED':'YOUR READING SESSION HAS CLOSED.'}</p><h1>{contributor?'A room of your own.':'Enter quietly.'}</h1><Link className="text-link" href={contributor?'/contributor-access':'/access'}>{contributor?'Contributor entrance':'Re-enter the edition'}<ArrowRight size={17}/></Link></div>}
export function Home(){return <><Header/><main className="threshold wrap"><div className="threshold-top"><span className="eyebrow">AN INDEPENDENT ARCHIVE OF THOUGHT</span><span className="eyebrow">EST. 2026</span></div><h1>Private<br/><em>Matter.</em></h1><div className="threshold-bottom"><p>A private publication for<br/>ideas worth sitting with.</p><div><Link className="entrance-link" href="/access">Enter the edition<ArrowUpRight size={22}/></Link><p className="access-aside">Already have access? <Link href="/access">Enter reader code</Link></p></div></div><div className="threshold-foot"><span>Published privately.</span><span>Read deliberately.</span></div></main><Footer/></>}
export function AccessScreen({contributor=false}:{contributor?:boolean}){const router=useRouter();const session=useSession();const[code,setCode]=useState('');const[error,setError]=useState('');const[busy,setBusy]=useState(false);const[granted,setGranted]=useState(false);async function enter(e:React.FormEvent){e.preventDefault();setBusy(true);setError('');try{await api('/api/session',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({code,intent:contributor?'contributor':'reader'})});setCode('');setGranted(true);window.dispatchEvent(new Event('folio-session'));basePath?window.location.assign(sitePath(contributor?'/studio':'/reading-room')):router.push(contributor?'/studio':'/reading-room')}catch(e){setError(e instanceof Error?e.message:'Access not recognized.');setBusy(false)}}const existing=contributor?session.contributor:session.reader;return <><header className="site-header wrap"><Brand/><Link className="return-link" href="/">Return</Link></header><main className="access-screen"><span className="access-index">{contributor?'II':'I'}</span><p className="eyebrow">{contributor?'CONTRIBUTOR ACCESS':'READER ACCESS'}</p><h1>{granted?'Access granted.':contributor?'Invitation required.':'Enter your edition.'}</h1><p className="access-description">{contributor?'A private space for your perspective.':'Some ideas deserve more than a feed.'}</p>{existing?<><p className="muted">Your {contributor?'contributor':'reader'} access is active.</p><Link href={contributor?'/studio':'/reading-room'} className="entrance-link">{contributor?'Enter the writing room':'Enter the reading room'}<ArrowRight size={20}/></Link></>:<form onSubmit={enter}><label htmlFor="edition-code" className="field-label">{contributor?'ENTER CONTRIBUTOR CODE':'ENTER YOUR EDITION CODE'}</label><InputOTP id="edition-code" aria-label={contributor?'Contributor code':'Reader code'} maxLength={6} pattern="^[0-9]*$" inputMode="numeric" value={code} onChange={setCode} autoComplete="off" containerClassName="code-container"><InputOTPGroup>{[0,1,2,3,4,5].map(i=><InputOTPSlot key={i} index={i} className="code-slot"/>)}</InputOTPGroup></InputOTP>{error&&<p className="form-error" role="alert">{error.toUpperCase()}<span>Try again.</span></p>}<Button className="enter-button" disabled={busy||code.length!==6}>{busy?'Entering…':'Enter'}<ArrowRight size={20}/></Button></form>}{!contributor&&<div className="acquire"><span>Need access?</span><PaymentLink/></div>}<p className="access-bottom">{contributor?'Ideas are intimate.':'Published privately. Read deliberately.'}</p></main></>}
