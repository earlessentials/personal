'use client';
import {useEffect,useState} from 'react';
import Link from '@/components/publication-link';
import {ArrowLeft,ArrowUpRight,Search} from 'lucide-react';
import {Input} from '@/components/ui/input';
import {Header,Footer,Story,Loading,Closed,api,matterUrl,number} from '../publication';
export default function Archive(){
  const[stories,setStories]=useState<Story[]|null>(null);
  const[q,setQ]=useState('');
  const[error,setError]=useState('');
  const[busy,setBusy]=useState(false);
  useEffect(()=>{let current=true;setBusy(true);const timer=setTimeout(()=>api('/api/stories?q='+encodeURIComponent(q)).then(d=>{if(current){setStories(d.stories);setError('')}}).catch(e=>{if(current)setError(e.status===401?'closed':e.message)}).finally(()=>{if(current)setBusy(false)}),q?250:0);return()=>{current=false;clearTimeout(timer)}},[q]);
  return <><Header/><main className="archive wrap">{error==='closed'?<Closed/>:<>
    <div className="archive-heading"><p className="eyebrow">PRIVATE MATTER / THE COLLECTION</p><h1>The <em>Archive.</em></h1><p>A place to return to.</p></div>
    {(!!stories?.length||!!q)&&<div className="archive-search"><label className="eyebrow" htmlFor="archive-query">SEARCH THE ARCHIVE</label><div><Input id="archive-query" value={q} onChange={e=>setQ(e.target.value)} placeholder="Find a word, a line, a matter…"/><Search size={19}/></div></div>}
    <section className="archive-results" aria-busy={busy}>{error?<p role="alert">{error}</p>:!stories?<Loading/>:stories.length?<><div className="archive-label"><p className="eyebrow">{q?'SEARCH RESULTS':'ALL MATTERS'}</p><span>{busy?'Searching…':stories.length===1?'1 MATTER':`${stories.length} MATTERS`}</span></div>{stories.map(s=><Link key={s.id} className="archive-row" href={matterUrl(s)}><span className="matter-no">{number(s.number)}</span><h2>{s.title}</h2><time>{new Date(s.createdAt).toLocaleDateString('en-GB',{day:'numeric',month:'short',year:'numeric'})}</time><ArrowUpRight size={19}/></Link>)}</>:q?<p className="empty-note" role="status">No matters found. Try another word.</p>:<div className="archive-empty"><span className="eyebrow">THE COLLECTION BEGINS HERE</span><h2>Every word,<br/><em>in its own time.</em></h2><p>No matters have been published yet.</p><Link className="text-link" href="/reading-room"><ArrowLeft size={17}/>Return to the reading room</Link></div>}</section>
  </>}</main><Footer/></>;
}
