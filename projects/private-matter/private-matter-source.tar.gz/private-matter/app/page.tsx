import { Home } from './publication';
export default function Page() { return <Home />; }
