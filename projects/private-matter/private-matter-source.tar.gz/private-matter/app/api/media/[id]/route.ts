import {env} from 'cloudflare:workers';
import {database,identity,reply,unavailable} from '@/lib/access';
import {byteRange} from '@/lib/video';
type Context={params:Promise<{id:string}>};
async function serve(request:Request,{params}:Context){
  try{
    const{id}=await params;if(!/^[a-f0-9-]{36}$/.test(id))return new Response(null,{status:404});
    const user=await identity(request);const bucket=env.BUCKET;if(!bucket)throw Error('Media storage unavailable');const object=await bucket.head(id);
    if(!object)return new Response(null,{status:404});
    const url='/api/media/'+id;
    if(!user.admin&&!(user.contributor&&object.customMetadata?.owner===user.contributor.id)){
      const allowed=await database().prepare(`SELECT id FROM posts WHERE status IN ('draft','published') AND (
        (status='published' AND (((?=1 OR visibility='public') AND (cover=? OR instr(body,?)>0)) OR
        (visibility='excerpt' AND (cover=? OR instr(excerpt,?)>0))))
      ) LIMIT 1`).bind(user.reader?1:0,url,url,url,url).first();
      if(!allowed)return reply({error:'Reader access required.'},401);
    }
    const headers=new Headers({'Content-Type':object.httpMetadata?.contentType||'application/octet-stream','Cache-Control':'private, no-store','Vary':'Cookie','X-Content-Type-Options':'nosniff','Accept-Ranges':'bytes','ETag':object.httpEtag});
    const range=byteRange(request.method==='HEAD'?null:request.headers.get('range'),object.size);
    if(range===false){headers.set('Content-Range','bytes */'+object.size);return new Response(null,{status:416,headers})}
    headers.set('Content-Length',String(range?range.length:object.size));
    if(range)headers.set('Content-Range',`bytes ${range.offset}-${range.offset+range.length-1}/${object.size}`);
    if(request.method==='HEAD')return new Response(null,{headers});
    const data=await bucket.get(id,range?{range}:undefined);if(!data||!('body'in data))return new Response(null,{status:404});
    return new Response(data.body,{status:range?206:200,headers});
  }catch(e){return unavailable(e)}
}
export const GET=serve;
export const HEAD=serve;
