import {env} from 'cloudflare:workers';
import {identity,reply,safeOrigin,unavailable} from '@/lib/access';
import {MAX_VIDEO_BYTES} from '@/lib/video';
export async function POST(request:Request){
  if(!safeOrigin(request))return reply({error:'Invalid request.'},403);
  try{
    const user=await identity(request);if(!user.contributor)return reply({error:'Invitation required.'},401);
    const type=request.headers.get('content-type')?.split(';')[0];
    if(type!=='video/mp4'&&type!=='video/webm')return reply({error:'Choose an MP4 or WebM video.'},400);
    if(Number(request.headers.get('content-length')||0)>MAX_VIDEO_BYTES)return reply({error:'Choose a video up to 25 MB, or use a YouTube link.'},413);
    const reader=request.body?.getReader();if(!reader)return reply({error:'Choose a video.'},400);
    const chunks:Uint8Array[]=[];let length=0;
    while(true){const{done,value}=await reader.read();if(done)break;length+=value.length;if(length>MAX_VIDEO_BYTES){await reader.cancel();return reply({error:'Choose a video up to 25 MB, or use a YouTube link.'},413)}chunks.push(value)}
    const bytes=new Uint8Array(length);let offset=0;for(const chunk of chunks){bytes.set(chunk,offset);offset+=chunk.length}
    const head=new TextDecoder('latin1').decode(bytes.slice(0,4096));
    const mp4=length>16&&head.slice(4,8)==='ftyp'&&/^(isom|iso[2-9]|mp4[12]|avc1|M4V |dash)/.test(head.slice(8,12));
    const webm=length>16&&bytes[0]===0x1a&&bytes[1]===0x45&&bytes[2]===0xdf&&bytes[3]===0xa3&&head.includes('webm');
    if(!(type==='video/mp4'?mp4:webm))return reply({error:'This file is not a supported MP4 or WebM video.'},400);
    if(!env.BUCKET)throw Error('Video storage unavailable');
    const id=crypto.randomUUID();await env.BUCKET.put(id,bytes,{httpMetadata:{contentType:type},customMetadata:{owner:user.contributor.id,kind:'video'}});
    return reply({url:'/api/media/'+id});
  }catch(e){return unavailable(e)}
}
