import {database,identity,reply,unavailable} from '@/lib/access';
import {ensurePublication,fields,present} from '@/lib/matters';
export const dynamic='force-dynamic';
export async function GET(request:Request){
  try{
    await ensurePublication();
    const url=new URL(request.url);
    const publicOnly=url.searchParams.get('scope')==='public';
    if(!publicOnly){
      const user=await identity(request);
      if(!user.reader&&!user.admin)return reply({error:'Your reading session has closed.'},401);
    }
    const q=(url.searchParams.get('q')||'').slice(0,200);
    const subject=(url.searchParams.get('subject')||'').slice(0,40);
    const rows=await database().prepare(`SELECT ${fields} FROM posts
      WHERE status='published' AND (?=0 OR visibility='public')
      AND (?='' OR instr(lower(title||' '||subtitle||' '||body||' '||author||' '||category||' '||tags),lower(?))>0)
      AND (?='' OR instr(tags,?)>0) ORDER BY matter_number DESC`)
      .bind(publicOnly?1:0,q,q,subject,JSON.stringify(subject)).all();
    return reply({stories:rows.results.map(r=>present(r))});
  }catch(e){return unavailable(e)}
}
