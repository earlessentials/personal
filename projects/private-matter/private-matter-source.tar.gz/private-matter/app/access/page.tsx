import {AccessScreen} from '../publication';
export default function Page(){return <AccessScreen/>}
