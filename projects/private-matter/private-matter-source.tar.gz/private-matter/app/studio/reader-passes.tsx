'use client';
import {useEffect,useState} from 'react';
import {api} from '../publication';
import {Input} from '@/components/ui/input';
import {Button} from '@/components/ui/button';
type Pass={id:string;label:string;suffix:string;duration_days:number;created_at:string;expires_at:string;revoked_at:string|null};
const when=(value:string)=>new Intl.DateTimeFormat('en-GB',{dateStyle:'medium',timeStyle:'short',timeZone:'Asia/Jakarta'}).format(new Date(value));
export function ReaderPasses(){
  const[passes,setPasses]=useState<Pass[]>([]),[label,setLabel]=useState(''),[days,setDays]=useState(7),[busy,setBusy]=useState(false),[error,setError]=useState(''),[loaded,setLoaded]=useState(false);
  const[created,setCreated]=useState<{code:string;pass:Pass}|null>(null),[copied,setCopied]=useState(false);
  const[clock,setClock]=useState(Date.now());
  const load=()=>api('/api/reader-passes').then(d=>{setPasses(d.passes);setLoaded(true)});
  useEffect(()=>{load().catch(e=>setError(e.message));const timer=setInterval(()=>setClock(Date.now()),30000);return()=>clearInterval(timer)},[]);
  async function create(){setBusy(true);setError('');setCopied(false);try{const result=await api('/api/reader-passes',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'create',days,label})});setCreated(result);setLabel('');await load()}catch(e){setError((e as Error).message)}finally{setBusy(false)}}
  async function revoke(id:string){setBusy(true);setError('');try{await api('/api/reader-passes',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'revoke',id})});if(created?.pass.id===id)setCreated(null);await load()}catch(e){setError((e as Error).message)}finally{setBusy(false)}}
  return <section className="reader-passes" aria-labelledby="reader-passes-heading"><h2 id="reader-passes-heading">Temporary reader access</h2><p className="editor-note">Create a six-digit invitation for 7, 28, 90 or 180 days, starting now. Your original 10 reader codes remain permanent. All times below are Jakarta time (WIB).</p>
    <label className="field-label" htmlFor="pass-label">LABEL / RECIPIENT (OPTIONAL)</label><Input id="pass-label" value={label} onChange={e=>setLabel(e.target.value)} maxLength={80} placeholder="A name to remember this invitation"/>
    <div className="pass-duration" role="group" aria-label="Access duration">{[7,28,90,180].map(value=><button type="button" key={value} aria-pressed={days===value} onClick={()=>setDays(value)}>{value} days</button>)}</div>
    <Button className="ink-button" disabled={busy||!!created} onClick={create}>Create reader code</Button>
    {created&&<div className="created-pass" role="status"><p className="eyebrow">YOUR NEW READER CODE</p><strong className="pass-code">{created.code}</strong><p>Expires {when(created.pass.expires_at)} WIB.</p><p>Copy this code now. For privacy, only its last two digits appear in the history.</p><div className="row-actions"><button onClick={async()=>{try{await navigator.clipboard.writeText(created.code);setCopied(true)}catch{setError('Select the code above and copy it manually.')}}}>{copied?'Copied':'Copy code'}</button><button onClick={()=>setCreated(null)}>I’ve saved it</button></div></div>}
    {error&&<p className="form-error" role="alert">{error}</p>}
    <h3>Invitation history</h3>{!loaded?<p className="editor-note">Loading invitations…</p>:passes.length===0?<p className="editor-note">No temporary invitations yet.</p>:<ul className="pass-history">{passes.map(pass=>{const active=!pass.revoked_at&&Date.parse(pass.expires_at)>clock;return <li key={pass.id}><div><h4>{pass.label||'Reader invitation'} <span>••••{pass.suffix}</span></h4><p>{pass.duration_days} days · {pass.revoked_at?'Revoked':active?'Active':'Expired'}</p><p>Created {when(pass.created_at)} · Expires {when(pass.expires_at)} WIB</p></div>{active&&<button className="text-link" disabled={busy} onClick={()=>revoke(pass.id)}>Revoke access</button>}</li>})}</ul>}
  </section>
}
