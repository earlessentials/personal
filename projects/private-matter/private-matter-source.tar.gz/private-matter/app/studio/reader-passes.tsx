'use client';
import {useEffect,useState} from 'react';
import {api} from '../publication';
import {Input} from '@/components/ui/input';
import {Search,ArrowUpRight,Copy,Check,KeyRound} from 'lucide-react';
import {Button} from '@/components/ui/button';
type Pass={id:string;label:string;suffix:string;duration_days:number;created_at:string;expires_at:string;revoked_at:string|null};
const when=(value:string)=>new Intl.DateTimeFormat('en-GB',{dateStyle:'medium',timeStyle:'short',timeZone:'Asia/Jakarta'}).format(new Date(value));
export function ReaderPasses(){
  const[passes,setPasses]=useState<Pass[]>([]),[label,setLabel]=useState(''),[days,setDays]=useState(7),[busy,setBusy]=useState(false),[error,setError]=useState(''),[loaded,setLoaded]=useState(false);
  const[created,setCreated]=useState<{code:string;pass:Pass}|null>(null),[copied,setCopied]=useState(false);
  const[custom,setCustom]=useState(false),[customDays,setCustomDays]=useState('');
  const selectedDays=custom?Number(customDays):days;
  const validDays=Number.isInteger(selectedDays)&&selectedDays>=1&&selectedDays<=3650;
  const[query,setQuery]=useState(''),[filter,setFilter]=useState('all'),[revoking,setRevoking]=useState<string|null>(null);
  const[clock,setClock]=useState(Date.now());
  const load=()=>api('/api/reader-passes').then(d=>{setPasses(d.passes);setLoaded(true)});
  useEffect(()=>{load().catch(e=>setError(e.message));const timer=setInterval(()=>setClock(Date.now()),30000);return()=>clearInterval(timer)},[]);
  async function create(){if(!validDays){setError('Choose a whole number from 1 to 3650 days.');return}setBusy(true);setError('');setCopied(false);try{const result=await api('/api/reader-passes',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'create',days:selectedDays,label})});setCreated(result);setLabel('');await load()}catch(e){setError((e as Error).message)}finally{setBusy(false)}}
  async function revoke(id:string){setBusy(true);setError('');try{await api('/api/reader-passes',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'revoke',id})});if(created?.pass.id===id)setCreated(null);await load()}catch(e){setError((e as Error).message)}finally{setBusy(false)}}
  const status=(p:Pass)=>p.revoked_at?'revoked':Date.parse(p.expires_at)>clock?'active':'expired';
  const activeCount=passes.filter(p=>status(p)==='active').length;
  const shown=passes.filter(p=>(filter==='all'||status(p)===filter)&&`${p.label} ${p.suffix}`.toLowerCase().includes(query.toLowerCase()));
  return <section className="reader-passes curator-panel" aria-labelledby="reader-passes-heading"><div className="curator-panel-heading"><span className="eyebrow">01 / READER ACCESS</span><h2 id="reader-passes-heading">An invitation <em>to stay.</em></h2><p>Create personal reader invitations, and decide how long each one lasts.</p></div>
    <div className="invitation-summary"><span><strong>{loaded?activeCount:'—'}</strong> Active temporary invitations</span><span><strong>10</strong> Permanent reader codes</span></div>
    <div className="invitation-composer"><div className="invitation-composer-heading"><KeyRound size={18}/><h3>Create an invitation</h3><span className="curator-pill">READER ONLY</span></div><p className="editor-note">A private six-digit code. Access starts when you create it.</p>
    <label className="field-label" htmlFor="pass-label">LABEL / RECIPIENT (OPTIONAL)</label><Input id="pass-label" value={label} onChange={e=>setLabel(e.target.value)} maxLength={80} placeholder="A name to remember this invitation"/>
    <div className="pass-duration" role="group" aria-label="Access duration">{[7,28,90,180].map(value=><button type="button" key={value} aria-pressed={!custom&&days===value} onClick={()=>{setCustom(false);setDays(value)}}>{value} days</button>)}<button type="button" aria-pressed={custom} onClick={()=>setCustom(true)}>Custom</button></div>
    {custom&&<div><label className="field-label" htmlFor="pass-custom-days">CUSTOM DURATION (DAYS)</label><Input id="pass-custom-days" type="number" min={1} max={3650} step={1} value={customDays} onChange={e=>setCustomDays(e.target.value)} placeholder="Number of days"/><p className="editor-note">Choose 1–3650 whole days. Access begins when the code is created.</p></div>}
    <Button className="ink-button" disabled={busy||!!created||!validDays} onClick={create}>{busy?'Please wait…':'Create reader code'}<ArrowUpRight size={16}/></Button></div>
    {created&&<div className="created-pass" role="status"><p className="eyebrow">YOUR NEW READER CODE</p><strong className="pass-code">{created.code}</strong><p>Expires {when(created.pass.expires_at)} WIB.</p><p>Copy this code now. For privacy, only its last two digits appear in the history.</p><div className="row-actions"><button onClick={async()=>{try{await navigator.clipboard.writeText(created.code);setCopied(true)}catch{setError('Select the code above and copy it manually.')}}}>{copied?'Copied':'Copy code'}</button><button onClick={()=>setCreated(null)}>I’ve saved it</button></div></div>}
    {error&&<p className="form-error" role="alert">{error}</p>}
    <div className="invitation-ledger-heading"><div><span className="eyebrow">THE ACCESS REGISTER</span><h3>Invitation history</h3></div><span>{loaded?passes.length:'—'} INVITATIONS</span></div>
    <div className="invitation-filters"><div role="group" aria-label="Filter invitations">{['all','active','expired','revoked'].map(value=><button key={value} aria-pressed={filter===value} onClick={()=>setFilter(value)}>{value}</button>)}</div><label className="invitation-search"><Search size={16}/><span className="sr-only">Search invitations</span><Input placeholder="Find a name or code ending…" value={query} onChange={e=>setQuery(e.target.value)}/></label></div>
    {!loaded?<p className="editor-note">{error?'Invitations could not be loaded.':'Loading invitations…'}</p>:!shown.length?<div className="invitation-empty"><KeyRound size={23}/><h4>{passes.length?'No matching invitations.':'The next reader starts here.'}</h4><p>{passes.length?'Try a different name or filter.':'Create your first temporary invitation above.'}</p></div>:<div className="invitation-table-wrap"><table className="invitation-table"><thead><tr><th>Recipient / code</th><th>Access</th><th>Expires · WIB</th><th><span className="sr-only">Actions</span></th></tr></thead><tbody>{shown.map(pass=><tr key={pass.id}><td><strong>{pass.label||'Reader invitation'}</strong><span>••••{pass.suffix} · {pass.duration_days} days</span><small>Created {when(pass.created_at)}</small></td><td><span className={'invitation-status '+status(pass)}>{status(pass)}</span></td><td><time dateTime={pass.expires_at}>{when(pass.expires_at)}</time></td><td>{status(pass)==='active'&&(revoking===pass.id?<div className="revoke-confirm"><span>End this access now?</span><button disabled={busy} onClick={async()=>{await revoke(pass.id);setRevoking(null)}}>Yes, revoke</button><button disabled={busy} onClick={()=>setRevoking(null)}>Cancel</button></div>:<button className="invitation-revoke" disabled={busy} onClick={()=>setRevoking(pass.id)}>Revoke<span className="sr-only"> access for {pass.label||'reader invitation'} ending {pass.suffix}</span></button>)}</td></tr>)}</tbody></table></div>}
    <p className="curator-footnote">Latest 200 invitations. Original reader codes never expire. Temporary codes are shown in full only when created.</p>
  </section>
}
