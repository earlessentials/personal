'use client';
import {useEffect,useState} from 'react';
import Link from '@/components/publication-link';
import {ArrowUpRight} from 'lucide-react';
import {Header,Footer,Loading,Story,api,matterUrl,number,PublicationDate} from '../publication';

export default function Publications(){
  const[stories,setStories]=useState<Story[]|null>(null);
  const[error,setError]=useState('');
  useEffect(()=>{
    let active=true;
    api('/api/stories?scope=catalog').then(d=>{if(active)setStories(d.stories)})
      .catch(e=>{if(active)setError(e.message)});
    return()=>{active=false};
  },[]);
  return <><Header/><main className="archive wrap">
    <div className="archive-heading"><p className="eyebrow">PRIVATE MATTER / PUBLICATIONS</p>
      <h1>Collected <em>matters.</em></h1><p>Every published matter. Some open, others reserved for readers with access.</p></div>
    <section className="archive-results">
      {error?<p role="alert">{error}</p>:!stories?<Loading/>:stories.length?<>
        <div className="archive-label"><p className="eyebrow">ALL MATTERS</p><span>{stories.length} {stories.length===1?'MATTER':'MATTERS'}</span></div>
        {stories.map(s=><Link key={s.id} className="archive-row" href={matterUrl(s)}>
          <span className="matter-no">{number(s.number)}</span><div><h2>{s.title}</h2><p className="eyebrow">{s.visibility==='public'?'OPEN ACCESS':s.visibility==='excerpt'?'PREVIEW / READER ACCESS':'READER ACCESS'}</p></div>
          <PublicationDate date={s.publishedAt||s.createdAt}/><ArrowUpRight size={19}/>
        </Link>)}
      </>:<div className="archive-empty"><span className="eyebrow">THE FIRST PAGE</span>
        <h2>To be<br/><em>written.</em></h2><p>No matters have been published yet.</p></div>}
    </section>
  </main><Footer/></>;
}
