'use client';
import {useEffect,useState} from 'react';
import Link from '@/components/publication-link';
import {ArrowUpRight} from 'lucide-react';
import {Header,Footer,Loading,Story,api,matterUrl,number} from '../publication';

export default function Publications(){
  const[stories,setStories]=useState<Story[]|null>(null);
  const[error,setError]=useState('');
  useEffect(()=>{
    let active=true;
    api('/api/stories?scope=public').then(d=>{if(active)setStories(d.stories)})
      .catch(e=>{if(active)setError(e.message)});
    return()=>{active=false};
  },[]);
  return <><Header/><main className="archive wrap">
    <div className="archive-heading"><p className="eyebrow">PRIVATE MATTER / PUBLICATIONS</p>
      <h1>Open <em>pages.</em></h1><p>Selected matters, open to everyone.</p></div>
    <section className="archive-results">
      {error?<p role="alert">{error}</p>:!stories?<Loading/>:stories.length?<>
        <div className="archive-label"><p className="eyebrow">PUBLIC ARTICLES</p><span>{stories.length} {stories.length===1?'MATTER':'MATTERS'}</span></div>
        {stories.map(s=><Link key={s.id} className="archive-row" href={matterUrl(s)}>
          <span className="matter-no">{number(s.number)}</span><h2>{s.title}</h2>
          <time>{new Date(s.createdAt).toLocaleDateString('en-GB',{day:'numeric',month:'short',year:'numeric'})}</time><ArrowUpRight size={19}/>
        </Link>)}
      </>:<div className="archive-empty"><span className="eyebrow">THE FIRST PUBLIC PAGE</span>
        <h2>To be<br/><em>written.</em></h2><p>No public articles have been published yet.</p></div>}
    </section>
  </main><Footer/></>;
}
