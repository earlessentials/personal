import Link from '@/components/publication-link';
import {Header,Footer} from './publication';
export default function NotFound(){return <><Header/><main className="quiet-state"><p className="eyebrow">THIS MATTER DOESN’T EXIST.</p><Link href="/archive" className="text-link">Return to the archive →</Link></main><Footer/></>}
