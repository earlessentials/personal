import {Reader} from '../../../reader';
export const metadata={robots:{index:false,follow:false}};
export default async function Page({params}:{params:Promise<{number:string;slug:string}>}){const p=await params;return <Reader id={p.number}/>}
