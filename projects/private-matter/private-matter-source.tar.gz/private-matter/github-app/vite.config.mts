import {defineConfig} from 'vite';
import react from '@vitejs/plugin-react';
import tailwind from '@tailwindcss/postcss';
import {resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {mkdir,readFile,writeFile} from 'node:fs/promises';

const workspace=fileURLToPath(new URL('..',import.meta.url));
const output=resolve(workspace,'dist/github-app');
export default defineConfig(({mode})=>{
  const preview=mode==='preview';
  const endpoint=process.env.PRIVATE_MATTER_API_URL||'';
  if(!preview&&endpoint!=='https://private-matter-api.pearling-private-matter.workers.dev/private-matter'&&!/^https:\/\/[a-z0-9]+\.supabase\.co\/functions\/v1\/private-matter$/.test(endpoint)){
    throw Error('Set PRIVATE_MATTER_API_URL to the configured publication backend before building the live GitHub application.');
  }
  return{
    root:resolve(workspace,'github-app'),base:'/privatematter/',publicDir:resolve(workspace,'public'),
    resolve:{alias:{'@':workspace,'next/navigation':resolve(workspace,'github-app/navigation.tsx'),'next/link':resolve(workspace,'github-app/navigation.tsx')}},
    define:{'process.env.NEXT_PUBLIC_BASE_PATH':JSON.stringify('/privatematter'),'process.env.NEXT_PUBLIC_GITHUB_APP':'true','process.env.NEXT_PUBLIC_API_URL':JSON.stringify(endpoint)},
    css:{postcss:{plugins:[tailwind()]}},
    build:{outDir:output,emptyOutDir:true},
    server:{host:'127.0.0.1',port:5185,strictPort:true,...(preview?{proxy:{'/privatematter/api':{target:'http://localhost:5173',changeOrigin:true,configure(proxy){proxy.on('proxyReq',request=>request.setHeader('Origin','http://localhost:5173'))}}}}:{})},
    plugins:[react(),{
      name:'publication-static-routes',
      async closeBundle(){
        const html=await readFile(resolve(output,'index.html'),'utf8');
        for(const route of ['access','contributor-access','reading-room','archive','publications','studio','about','read']){
          await mkdir(resolve(output,route),{recursive:true});
          await writeFile(resolve(output,route,'index.html'),html);
          await writeFile(resolve(output,route+'.html'),html);
        }
      },
    }],
  };
});
