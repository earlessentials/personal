import React from 'react';
import {createRoot} from 'react-dom/client';
import {Home,AccessScreen} from '../app/publication';
import Room from '../app/reading-room/page';
import Archive from '../app/archive/page';
import Publications from '../app/publications/page';
import Studio from '../app/studio/page';
import About from '../app/about/page';
import NotFound from '../app/not-found';
import {Reader} from '../app/reader';
import '../app/globals.css';

const path=window.location.pathname.replace(/^\/privatematter\/?/,'').replace(/\/$/,'').replace(/\.html$/,'');
const routes:Record<string,React.ReactNode>={
  '':<Home/>,index:<Home/>,access:<AccessScreen/>,
  'contributor-access':<AccessScreen contributor/>,
  'reading-room':<Room/>,archive:<Archive/>,publications:<Publications/>,studio:<Studio/>,about:<About/>,
  read:<Reader id={new URLSearchParams(window.location.search).get('id')||''}/>,
};
createRoot(document.getElementById('root')!).render(routes[path]||<NotFound/>);
