# GitHub frontend with a private backend

This builds the full reading and contributor interface as static files, with the
same editorial design and existing contributor studio. The backend is deployed and verified in the owner’s Supabase Free project
`cdyzpgvamzeweiwyfzcm`.

The frontend belongs at `public/privatematter/` in `earlessentials/personal`.
Only that folder is replaced. GitHub's existing workflow, homepage and domain
configuration remain unchanged. Article links use `/privatematter/read/?id=...`
so refreshes and direct links work on Pages without a site-wide 404 rewrite.

## Connection contract

`PRIVATE_MATTER_API_URL` must be the owner's deployed Supabase Edge Function URL
ending in `/functions/v1/private-matter`. The build rejects an absent or invalid
connection. No access codes, code hashes, database credentials or service keys
belong in frontend configuration.

The service implements the existing `/session`, `/stories`, `/studio`, `/settings`,
`/media` and `/videos` API contract. Login returns independent, random, revocable
`tokens.reader` and/or `tokens.contributor` values. The browser stores these only
for its current tab, never the submitted code. Each request carries the tokens
in `X-PM-reader` and `X-PM-contributor`; the server must check them against its
session database for every private read and mutation. No browser flag grants
permissions. The server must allow CORS only for the owner's site origins.

Pearling’s existing code remains the dual-role administrator in the server’s secret configuration;
the actual values of all codes are deliberately absent from this source.

## Local preview

Start the existing local application on port 5173, then run
`npm run dev:github-app`. The preview proxies only the local API and preserves
the server's own access checks. This proxy is never shipped in the static build.

Production: set `PRIVATE_MATTER_API_URL`, then run `npm run build:github-app`.
The implementation and migrations are in `supabase/`. Nine local PostgreSQL
test groups pass. The initial 115 hosted checks cover access and publishing;
47 additional hosted checks passed on 27 September 2026 for admin-only deletion,
editable bylines, dates and ownership. Protected images and videos resolve their canonical media
IDs through an authenticated request for a short-lived URL. The production frontend requires the verified function endpoint above.
