import type {ComponentProps} from 'react';
import {sitePath} from '../lib/paths';

export function useRouter(){return{push:(path:string)=>window.location.assign(sitePath(path)),replace:(path:string)=>window.location.replace(sitePath(path))}}
export default function Link({href,...props}:ComponentProps<'a'>&{href:string}){return <a href={sitePath(href)} {...props}/>}
