# PRIVATE MATTER

An independent editorial publication at https://pearlinglim.com/privatematter/.
The frontend is hosted on GitHub Pages in `earlessentials/personal`; access,
publishing, sessions and private uploads run in the owner’s Supabase Free project.
The publication starts empty, ready for Pearling’s own writing and videos.

## Production architecture

- `github-app/` builds the full React reading experience and contributor studio.
- `supabase/` contains the PostgreSQL migrations and `private-matter` Edge Function.
- Supabase project: `cdyzpgvamzeweiwyfzcm` in Pearl’s Cove.
- API: `https://cdyzpgvamzeweiwyfzcm.supabase.co/functions/v1/private-matter`.
- GitHub deployment changes only `public/privatematter/` and this source archive.
  The main website, workflow and domain configuration remain unchanged.

The existing ten reader and five contributor codes are retained as server-side
hashes. Pearling’s administrator identity opens both gates. The other four
contributor identities remain unnamed. No codes, hashes, service keys or database
passwords belong in this archive or the frontend bundle.

Readers and contributors use independent, revocable sessions in the current
browser tab. Public matters can be read without a code; private matters require
reader access; excerpt matters share only the designated introduction publicly.
Contributors can draft, preview, publish and revise their own matters. Pearling
can manage the publication and assign contributor names.

## Development and deployment

Use the package lock and Node 22 or later. Install with `npm ci`.

```sh
npm --prefix tests ci
npm run test:backend
PRIVATE_MATTER_API_URL=https://cdyzpgvamzeweiwyfzcm.supabase.co/functions/v1/private-matter npm run build:github-app
```

The static output is `dist/github-app/`. Direct article links use
`/privatematter/read/?id=...`, with route folders for GitHub Pages refreshes.
See `supabase/README.md` and `github-app/README.md` for setup and verification.
Keep runtime secrets in ignored configuration; never copy them into the build.

## Images and video

The studio accepts JPEG, PNG and WebP images up to 8 MB, MP4/WebM videos up to
25 MiB, and YouTube links. YouTube links become privacy-enhanced in-page players.
Arbitrary HTML embeds remain disabled. YouTube’s own visibility rules still apply.
Uploaded media is stored in a private Supabase bucket. The API checks article
visibility and ownership before issuing a fifteen-minute URL for one object.
Previously issued URLs remain valid until expiry. Video seeking uses byte ranges.

## Verification

Eight local PostgreSQL test groups and 115 hosted integration checks passed on
24 September 2026, covering all original codes, admin dual access, ownership,
public/private/excerpt publishing, revisions, private uploads, video byte ranges,
CORS and session revocation. All temporary articles and upload files were removed.
The database has six RLS-protected tables; browser roles cannot query them or
invoke the privileged API function. No paid Supabase plan was activated.

## Historical implementations

The original Vinext/Worker runtime and `github-pages/` empty HTML edition are
preserved as references. They are not the production backend. Cloudflare
hosting and R2 activation were declined; current hosting uses GitHub and Supabase.
