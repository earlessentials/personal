# PRIVATE MATTER

A private digital publication with a public threshold, code-based reading, a searchable archive and contributor publishing.

## Runtime

The site runs on Vinext and a Cloudflare Worker. D1 stores sessions, drafts, published matters, permanent publication numbers, contributor identity assignments and settings. R2 stores editorial images.

Access-code hashes are held in the secret FOLIO_CODES_JSON runtime value. They are never shipped in browser code. Reader and contributor sessions use independent HttpOnly cookies. The existing curator identity has administrator permission for both portals. Unassigned contributor identities remain unassigned until the curator assigns a name.

FOLIO_PAYMENT_URL is the default external payment destination. The curator can override it in the writing room settings. Payments and delivery of reader codes happen externally.

## Development

Use the package lock and Node 22 or later. npm run dev starts the site. npm run build creates the Worker and public assets. npm run db:generate creates append-only schema migrations. Apply pending migrations to the local D1 database before testing; Sites applies production migrations during publication. Keep secrets in ignored .dev.vars and .env files.

Existing Matter numbers, authors, publication dates and URLs survive revisions. Draft deletion does not reuse numbers. Private article bodies and search results require reader authorization; contributors may view their own work and the curator may manage all work.

## Video publications

The editor’s Video button inserts a standalone Markdown video link between paragraphs: `[Caption](https://www.youtube.com/watch?v=VIDEO_ID "video")`. YouTube watch, share, Shorts and live links are normalized to privacy-enhanced embeds. Only recognized YouTube origins and site-owned media URLs can create players; arbitrary HTML embeds remain disabled.

MP4 and WebM uploads are limited to 25 MiB and stored in R2. Media requests enforce publication visibility and ownership, including byte-range requests for playback and seeking. A private publication cannot make the original YouTube video private.
