# PRIVATE MATTER

An independent editorial publication at https://pearlinglim.com/privatematter/.
The frontend is hosted on GitHub Pages in `earlessentials/personal`; access,
publishing, sessions and private uploads run in the owner’s Cloudflare account.
See `OWN_HOSTING.md` for the current deployment and migration details.

## Production architecture

- `github-app/` builds the full React reading experience and contributor studio.
- `cloudflare/` contains the Worker, D1 adapter and database schema.
- `supabase/` retains the shared HTTP handler and original backend for rollback.
- API: `https://private-matter-api.pearling-private-matter.workers.dev/private-matter`.
- GitHub deployment changes only `public/privatematter/` and this source archive.
  The main website, workflow and domain configuration remain unchanged.

The existing ten reader and five contributor codes are retained as server-side
hashes. Pearling’s administrator identity opens both gates. The other four
contributor identities remain unnamed. No codes, hashes, service keys or database
passwords belong in this archive or the frontend bundle.

Readers and contributors use independent, revocable sessions in the current
browser tab. Public matters can be read without a code; private matters require
reader access; excerpt matters share only the designated introduction publicly.
Contributors can draft, preview, publish and revise their own matters. Pearling
can manage the publication and assign contributor names. Only Pearling can delete
drafts or published matters. Writers can set a byline on each draft without
changing its owner or permissions. Publication dates use Jakarta time and retain
the original date when a matter is revised.

## Development and deployment

Use the package lock and Node 22 or later. Install with `npm ci`.

```sh
npm --prefix tests ci
npm run test:backend
PRIVATE_MATTER_API_URL=https://private-matter-api.pearling-private-matter.workers.dev/private-matter npm run build:github-app
```

The static output is `dist/github-app/`. Direct article links use
`/privatematter/read/?id=...`, with route folders for GitHub Pages refreshes.
See `supabase/README.md` and `github-app/README.md` for setup and verification.
Keep runtime secrets in ignored configuration; never copy them into the build.

## Images and video

The studio accepts JPEG, PNG and WebP images up to 8 MB, MP4/WebM videos up to
25 MiB, and YouTube links. YouTube links become privacy-enhanced in-page players.
Arbitrary HTML embeds remain disabled. YouTube’s own visibility rules still apply.
Uploaded media is stored in a private Cloudflare R2 bucket. The API checks article
visibility and ownership before issuing a fifteen-minute URL for one object.
Previously issued URLs remain valid until expiry. Video seeking uses byte ranges.

## Original Supabase verification (historical)

Ten local PostgreSQL test groups, TypeScript and the production build pass.
On 27 September 2026, 47 additional live checks verified admin-only deletion,
editable bylines, original publication dates, ownership boundaries and cleanup.
The initial 115 hosted integration checks covered all original codes, admin dual access, ownership,
public/private/excerpt publishing, revisions, private uploads, video byte ranges,
CORS and session revocation. All temporary articles and upload files were removed.
The database has six RLS-protected tables; browser roles cannot query them or
invoke the privileged API function. No paid Supabase plan was activated.

## Historical implementations

The original Vinext/Worker runtime and `github-pages/` empty HTML edition are
preserved as references. They are not the production backend. Cloudflare
hosting and R2 activation were declined; current hosting uses GitHub and Supabase.

## Regional checkout

Acquire Access suggests Lynk for Indonesian IP addresses and Gumroad for other
recognised addresses. The access link remains visible while the location is loading. A region
switch remains available for travelling readers or VPN users; existing codes
and reading/publishing permissions are independent of checkout region.
The live URLs are https://lynk.id/pearling/xemxp2kpjool/checkout and
https://heypearling.gumroad.com/l/privatematter. Country lookup uses a bundled
DB-IP Lite snapshot inside Supabase, with no third-party visitor lookup request.
See `supabase/COUNTRY-DATA.md` for attribution and refreshing the data.
