import {createHandler} from '../supabase/functions/private-matter/handler.mjs';
import {createRpc} from './database.mjs';
const origins=['https://pearlinglim.com','https://www.pearlinglim.com'];
const prefix='/storage/v1/object/sign/private-matter/';
const hex=b=>Array.from(new Uint8Array(b),v=>v.toString(16).padStart(2,'0')).join('');
async function key(secret){return crypto.subtle.importKey('raw',new TextEncoder().encode(secret),{name:'HMAC',hash:'SHA-256'},false,['sign','verify'])}
export async function signedUrl(origin,id,seconds,secret){const expires=Math.floor(Date.now()/1000)+seconds;const signature=hex(await crypto.subtle.sign('HMAC',await key(secret),new TextEncoder().encode(id+':'+expires)));return `${origin}${prefix}${id}?expires=${expires}&signature=${signature}`}
export async function serveMedia(request,env){
 const url=new URL(request.url),id=url.pathname.slice(prefix.length),expiry=url.searchParams.get('expires'),signature=url.searchParams.get('signature')||'';
 const headers=new Headers({'Cache-Control':'private, no-store','X-Content-Type-Options':'nosniff','X-Robots-Tag':'noindex, noarchive','Referrer-Policy':'no-referrer','Accept-Ranges':'bytes'});
 const origin=request.headers.get('origin');if(origin&&origins.includes(origin)){headers.set('Access-Control-Allow-Origin',origin);headers.set('Vary','Origin');headers.set('Access-Control-Expose-Headers','Content-Length, Content-Range, Accept-Ranges')}
 if(!['GET','HEAD'].includes(request.method))return new Response(null,{status:405,headers});
 if(!/^[a-f0-9-]{36}$/.test(id)||!/^\d{10,12}$/.test(expiry||'')||Number(expiry)<=Date.now()/1000||Number(expiry)>Date.now()/1000+901||!/^([a-f0-9]{2}){32}$/.test(signature))return new Response(null,{status:403,headers});
 const valid=await crypto.subtle.verify('HMAC',await key(env.MEDIA_SIGNING_SECRET),Uint8Array.from(signature.match(/../g),v=>parseInt(v,16)),new TextEncoder().encode(id+':'+expiry));
 if(!valid)return new Response(null,{status:403,headers});
 const meta=await env.BUCKET.head(id);if(!meta)return new Response(null,{status:404,headers});
 let range=null;const requested=request.headers.get('range');
 if(requested){const match=/^bytes=(\d*)-(\d*)$/.exec(requested);if(!match||!match[1]&&!match[2])return new Response(null,{status:416,headers});let start=match[1]?Number(match[1]):Math.max(0,meta.size-Number(match[2]));let end=match[1]?(match[2]?Math.min(Number(match[2]),meta.size-1):meta.size-1):meta.size-1;
  if(!Number.isSafeInteger(start)||!Number.isSafeInteger(end)||start>end||start>=meta.size){headers.set('Content-Range',`bytes */${meta.size}`);return new Response(null,{status:416,headers})}range={offset:start,length:end-start+1};headers.set('Content-Range',`bytes ${start}-${end}/${meta.size}`)}
 headers.set('Content-Type',meta.httpMetadata?.contentType||'application/octet-stream');headers.set('Content-Length',String(range?range.length:meta.size));
 if(request.method==='HEAD')return new Response(null,{status:range?206:200,headers});
 const object=await env.BUCKET.get(id,range?{range}:undefined);return new Response(object?.body||null,{status:object?(range?206:200):404,headers});
}
export default {async fetch(request,env){
 try{
  const url=new URL(request.url);if(url.pathname.startsWith(prefix))return await serveMedia(request,env);
  if(!url.pathname.startsWith('/private-matter/')&&!url.pathname.startsWith('/functions/v1/private-matter/'))return new Response('Not found',{status:404});
  const headers=new Headers(request.headers);headers.set('x-forwarded-for',request.headers.get('cf-connecting-ip')||'unknown');
  return await createHandler({rpc:createRpc(env.DB),codes:JSON.parse(env.FOLIO_CODES_JSON),origins,
   paymentUrl:'https://lynk.id/pearling/xemxp2kpjool/checkout',internationalPaymentUrl:'https://heypearling.gumroad.com/l/privatematter',
   resolveCheckoutRegion:()=>request.cf?.country==='ID'?'indonesia':request.cf?.country&&!['XX','T1'].includes(request.cf.country)?'international':null,
   storage:{upload:(id,bytes,type)=>env.BUCKET.put(id,bytes,{httpMetadata:{contentType:type}}),remove:id=>env.BUCKET.delete(id),sign:(id,seconds)=>signedUrl(url.origin,id,seconds,env.MEDIA_SIGNING_SECRET)}
  })(new Request(request,{headers}));
 }catch{console.error('PRIVATE MATTER service failed');return Response.json({error:'The room is temporarily unavailable. Please try again.'},{status:503,headers:{'Cache-Control':'no-store'}})}
}};
