// Intentionally empty by default.
// Add Drizzle tables here when the site actually needs a database.
// See examples/d1/db/schema.ts for an opt-in example.
import { integer, sqliteTable, text, index } from 'drizzle-orm/sqlite-core';
export const sessions=sqliteTable('sessions',{tokenHash:text('token_hash').primaryKey(),accessId:text('access_id').notNull(),expiresAt:integer('expires_at').notNull(),scope:text('scope').notNull().default('reader')},t=>[index('idx_sessions_expiry').on(t.expiresAt)]);
export const attempts=sqliteTable('attempts',{key:text('key').primaryKey(),hits:integer('hits').notNull(),expiresAt:integer('expires_at').notNull()},t=>[index('idx_attempts_expiry').on(t.expiresAt)]);
export const posts=sqliteTable('posts',{id:text('id').primaryKey(),slug:text('slug').notNull().unique(),title:text('title').notNull(),subtitle:text('subtitle').notNull(),category:text('category').notNull(),body:text('body').notNull(),author:text('author').notNull(),accessId:text('access_id').notNull(),createdAt:text('created_at').notNull(),updatedAt:text('updated_at'),publishedAt:text('published_at'),status:text('status').notNull().default('published'),matterNumber:integer('matter_number'),tags:text('tags').notNull().default('[]'),cover:text('cover').notNull().default(''),caption:text('caption').notNull().default(''),imageAlt:text('image_alt').notNull().default(''),imageMode:text('image_mode').notNull().default('wide'),references:text('references_text').notNull().default(''),seoDescription:text('seo_description').notNull().default(''),visibility:text('visibility').notNull().default('private'),excerpt:text('excerpt').notNull().default('')},t=>[index('idx_posts_created').on(t.createdAt)]);

export const publications=sqliteTable('publications',{number:integer('number').primaryKey({autoIncrement:true}),postId:text('post_id').notNull().unique()});
export const settings=sqliteTable('settings',{key:text('key').primaryKey(),value:text('value').notNull()});
export const profiles=sqliteTable('contributor_profiles',{accessId:text('access_id').primaryKey(),name:text('name')});
