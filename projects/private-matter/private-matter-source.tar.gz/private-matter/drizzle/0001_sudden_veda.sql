CREATE TABLE `contributor_profiles` (
	`access_id` text PRIMARY KEY NOT NULL,
	`name` text
);
--> statement-breakpoint
CREATE TABLE `publications` (
	`number` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`post_id` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `publications_post_id_unique` ON `publications` (`post_id`);--> statement-breakpoint
CREATE TABLE `settings` (
	`key` text PRIMARY KEY NOT NULL,
	`value` text NOT NULL
);
--> statement-breakpoint
ALTER TABLE `posts` ADD `updated_at` text;--> statement-breakpoint
ALTER TABLE `posts` ADD `published_at` text;--> statement-breakpoint
ALTER TABLE `posts` ADD `status` text DEFAULT 'published' NOT NULL;--> statement-breakpoint
ALTER TABLE `posts` ADD `matter_number` integer;--> statement-breakpoint
ALTER TABLE `posts` ADD `tags` text DEFAULT '[]' NOT NULL;--> statement-breakpoint
ALTER TABLE `posts` ADD `cover` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `posts` ADD `caption` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `posts` ADD `image_alt` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `posts` ADD `image_mode` text DEFAULT 'wide' NOT NULL;--> statement-breakpoint
ALTER TABLE `posts` ADD `references_text` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `posts` ADD `seo_description` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `posts` ADD `visibility` text DEFAULT 'private' NOT NULL;--> statement-breakpoint
ALTER TABLE `posts` ADD `excerpt` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `sessions` ADD `scope` text DEFAULT 'reader' NOT NULL;