# PRIVATE MATTER on pearlinglim.com

This app supports a standalone Cloudflare deployment at `/privatematter`. The
frontend, access checks, article database, images and uploaded videos run in the
owner's Cloudflare account. It does not redirect to or call a ChatGPT site.

The existing Pearl's Cove website remains on GitHub Pages. Only these four Worker
routes are configured:

- `pearlinglim.com/privatematter`
- `pearlinglim.com/privatematter/*`
- `www.pearlinglim.com/privatematter`
- `www.pearlinglim.com/privatematter/*`

No homepage, navigation, GitHub Pages build, CNAME, or existing page needs editing.
The Worker routes require the domain to be active on Cloudflare with the two web
DNS records proxied. Preserve all existing DNS records, including mail records,
and their existing origin targets when connecting the zone. Do not point the
entire domain at this Worker or replace the GitHub Pages origin.

## Build and preview

Use Node 22.13 or later and the included package lock:

```sh
npm ci
npm run dev:owned
npm run build:owned
```

The owned build sets `/privatematter` as the framework base path. Links, fonts,
API requests, uploaded media and HttpOnly session cookies stay within that path.
The normal `build` command retains compatibility with the original deployment;
use `build:owned` and `deploy:owned` for the owner's domain.

## Provision in the owner's Cloudflare account

Authenticate Wrangler in that account, then create a D1 database named
`private-matter` and an R2 bucket named `private-matter-media`. Supply the actual
D1 identifier as `PRIVATE_MATTER_DATABASE_ID` when building or deploying. The
all-zero identifier in the preview config is a local placeholder, not a resource
that can be used for production.

Apply the two SQL files in `drizzle/` in order to the new database before launch.
For a migration, securely transfer existing publication records, settings,
contributor profiles and R2 objects with their ownership metadata. Do not migrate
sessions or rate-limit attempts. Do not commit database exports or access codes.

Store the existing `FOLIO_CODES_JSON` value as a Worker secret in the owner's
account. It contains the ten reader and five contributor identities, including
the curator's dual access. It is intentionally absent from this source package.
The configured payment URL is preserved and remains editable by the curator.

After the resources and secret are ready:

```sh
npm run deploy:owned
```

Verify the domain route, all ten reader codes, contributor access, the curator's
dual access, saving and publishing, private media, and video playback. Verify
the homepage and existing page URLs still serve their unchanged GitHub Pages
content. No production launch is complete until these checks pass at the custom
domain.

## Current migration status

The path-aware application and deployment configuration are prepared and tested
locally. The custom-domain deployment still requires access to the owner's
hosting account and domain configuration. The source package alone does not
activate `/privatematter` on GitHub Pages.
