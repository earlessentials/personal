import {test} from 'node:test';
import assert from 'node:assert/strict';
import {formatEmphasis} from '../lib/emphasis.ts';
import React from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import Markdown from 'react-markdown';
const html=body=>renderToStaticMarkup(React.createElement(Markdown,null,body));
for (const kind of ['bold','italic']) {
  const tag=kind==='bold'?'strong':'em';
  test(`${kind}: selection with whitespace renders and preserves surrounding writing`,()=>{
    const r=formatEmphasis('Before   selected words  after',7,25,kind);
    assert.match(html(r.body),new RegExp(`<${tag}>selected words</${tag}>`));
    assert.equal(r.body.slice(r.start,r.end),'selected words');
    assert.equal(formatEmphasis(r.body,r.start,r.end,kind).body,'Before   selected words  after');
  });
  test(`${kind}: empty cursor inserts editable placeholder`,()=>{
    const r=formatEmphasis('Before after',7,7,kind);
    assert.equal(r.body.slice(r.start,r.end),'text');
    assert.match(html(r.body),new RegExp(`<${tag}>text</${tag}>`));
  });
  test(`${kind}: paragraphs render without literal delimiters`,()=>{
    const body='One paragraph\n\nTwo paragraphs';
    const r=formatEmphasis(body,0,body.length,kind);
    assert.equal((html(r.body).match(new RegExp(`<${tag}>`,'g'))||[]).length,2);
    assert.ok(!html(r.body).includes('*'));
    assert.equal(formatEmphasis(r.body,r.start,r.end,kind).body,body);
  });
}
test('bold and italic combine, and each can be removed independently',()=>{
  let r=formatEmphasis('Both',0,4,'bold');
  r=formatEmphasis(r.body,r.start,r.end,'italic');
  assert.equal(html(r.body),'<p><em><strong>Both</strong></em></p>');
  const boldOnly=formatEmphasis(r.body,r.start,r.end,'italic');
  assert.equal(html(boldOnly.body),'<p><strong>Both</strong></p>');
  const italicOnly=formatEmphasis(r.body,r.start,r.end,'bold');
  assert.equal(html(italicOnly.body),'<p><em>Both</em></p>');
});
